package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;

public class ApplicationSummary implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private TicketDetails ticketDetails;
	private ThematicAnalysisDetail thematicAnalysisDetail;
	private ResourceWiseLPIDetail resourceWiseLPIDetail;
	private CountryWiseLPIDetail countryWiseLPIDetail;

	public TicketDetails getTicketDetails() {
		return ticketDetails;
	}

	public ThematicAnalysisDetail getThematicAnalysisDetail() {
		return thematicAnalysisDetail;
	}

	public ResourceWiseLPIDetail getResourceWiseLPIDetail() {
		return resourceWiseLPIDetail;
	}

	public CountryWiseLPIDetail getCountryWiseLPIDetail() {
		return countryWiseLPIDetail;
	}

	public void setTicketDetails(TicketDetails ticketDetails) {
		this.ticketDetails = ticketDetails;
	}

	public void setThematicAnalysisDetail(ThematicAnalysisDetail thematicAnalysisDetail) {
		this.thematicAnalysisDetail = thematicAnalysisDetail;
	}

	public void setResourceWiseLPIDetail(ResourceWiseLPIDetail resourceWiseLPIDetail) {
		this.resourceWiseLPIDetail = resourceWiseLPIDetail;
	}

	public void setCountryWiseLPIDetail(CountryWiseLPIDetail countryWiseLPIDetail) {
		this.countryWiseLPIDetail = countryWiseLPIDetail;
	}

}
