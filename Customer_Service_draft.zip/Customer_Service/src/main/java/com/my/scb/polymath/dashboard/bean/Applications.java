package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;
import java.util.List;

public class Applications implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<String> applicationList;

	public List<String> getApplicationList() {
		return applicationList;
	}

	public void setApplicationList(List<String> applicationList) {
		this.applicationList = applicationList;
	}

}
