package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;
import java.util.List;

public class CountryWiseLPIDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<CountryWiseLPI> countryWiseLPIList;

	public List<CountryWiseLPI> getCountryWiseLPIList() {
		return countryWiseLPIList;
	}

	public void setCountryWiseLPIList(List<CountryWiseLPI> countryWiseLPIList) {
		this.countryWiseLPIList = countryWiseLPIList;
	}

}
