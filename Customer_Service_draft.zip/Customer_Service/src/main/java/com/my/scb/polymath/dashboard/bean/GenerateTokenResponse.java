package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GenerateTokenResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("token")
	@Size(max = 500)
	private String token;

	@JsonProperty("error")
	@Size(max = 500)
	private String error;

	public GenerateTokenResponse() {

	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
}
