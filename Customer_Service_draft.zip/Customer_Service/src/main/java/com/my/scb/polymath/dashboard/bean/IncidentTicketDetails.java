package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;
import java.util.List;

public class IncidentTicketDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long numberOfRecord;
	private List<IncidentTicketDetail> incidentTicketDetailList;

	public Long getNumberOfRecord() {
		return numberOfRecord;
	}

	public List<IncidentTicketDetail> getIncidentTicketDetailList() {
		return incidentTicketDetailList;
	}

	public void setNumberOfRecord(Long numberOfRecord) {
		this.numberOfRecord = numberOfRecord;
	}

	public void setIncidentTicketDetailList(List<IncidentTicketDetail> incidentTicketDetailList) {
		this.incidentTicketDetailList = incidentTicketDetailList;
	}

}
