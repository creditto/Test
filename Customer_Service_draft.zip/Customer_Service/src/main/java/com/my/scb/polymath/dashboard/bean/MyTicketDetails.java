package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;

public class MyTicketDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long open;
	private Long potential;
	private Long aging;

	public Long getOpen() {
		return open;
	}

	public Long getPotential() {
		return potential;
	}

	public Long getAging() {
		return aging;
	}

	public void setOpen(Long open) {
		this.open = open;
	}

	public void setPotential(Long potential) {
		this.potential = potential;
	}

	public void setAging(Long aging) {
		this.aging = aging;
	}

}
