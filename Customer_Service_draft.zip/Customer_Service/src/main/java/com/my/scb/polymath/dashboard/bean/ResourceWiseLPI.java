package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;

public class ResourceWiseLPI implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String resourceName;
	private Long total = 0l;
	private Long slaMet = 0l;
	private Long slaNotMet = 0l;

	public String getResourceName() {
		return resourceName;
	}

	public Long getTotal() {
		return total;
	}

	public Long getSlaMet() {
		return slaMet;
	}

	public Long getSlaNotMet() {
		return slaNotMet;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public void setSlaMet(Long slaMet) {
		this.slaMet = slaMet;
	}

	public void setSlaNotMet(Long slaNotMet) {
		this.slaNotMet = slaNotMet;
	}
}
