package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;
import java.util.List;

public class ResourceWiseLPIDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<ResourceWiseLPI> resourceWiseLPIList;

	public List<ResourceWiseLPI> getResourceWiseLPIList() {
		return resourceWiseLPIList;
	}

	public void setResourceWiseLPIList(List<ResourceWiseLPI> resourceWiseLPIList) {
		this.resourceWiseLPIList = resourceWiseLPIList;
	}

}
