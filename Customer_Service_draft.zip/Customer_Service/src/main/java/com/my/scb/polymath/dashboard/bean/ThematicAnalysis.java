package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;

public class ThematicAnalysis implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;
	private Long count = 0l;

	public String getName() {
		return name;
	}

	public Long getCount() {
		return count;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCount(Long count) {
		this.count = count;
	}

}
