package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;
import java.util.List;

public class ThematicAnalysisDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<ThematicAnalysis> thematicAnalysisList;

	public List<ThematicAnalysis> getThematicAnalysisList() {
		return thematicAnalysisList;
	}

	public void setThematicAnalysisList(List<ThematicAnalysis> thematicAnalysisList) {
		this.thematicAnalysisList = thematicAnalysisList;
	}

}
