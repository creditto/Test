package com.my.scb.polymath.dashboard.bean;

import java.io.Serializable;

public class TicketDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long total;
	private Long slaMet;
	private Long slaNotMet;

	public Long getTotal() {
		return total;
	}

	public Long getSlaMet() {
		return slaMet;
	}

	public Long getSlaNotMet() {
		return slaNotMet;
	}

	public void setTotal(Long total) {
		this.total = total;
	}

	public void setSlaMet(Long slaMet) {
		this.slaMet = slaMet;
	}

	public void setSlaNotMet(Long slaNotMet) {
		this.slaNotMet = slaNotMet;
	}

}
