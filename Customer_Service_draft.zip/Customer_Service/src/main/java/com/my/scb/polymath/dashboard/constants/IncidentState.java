package com.my.scb.polymath.dashboard.constants;

public enum IncidentState {

	OPEN, POTENTIAL, AGING, SLAMET, SLANOTMET, TOTAL;
}
