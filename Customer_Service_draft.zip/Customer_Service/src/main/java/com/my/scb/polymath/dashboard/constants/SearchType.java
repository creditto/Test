package com.my.scb.polymath.dashboard.constants;

public enum SearchType {

	OPEN, POTENTIAL, AGING, SLAMET, SLANOTMET, TOTAL;
}
