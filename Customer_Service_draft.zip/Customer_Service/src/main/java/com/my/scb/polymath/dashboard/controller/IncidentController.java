package com.my.scb.polymath.dashboard.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.my.scb.polymath.dashboard.bean.ApplicationSummary;
import com.my.scb.polymath.dashboard.bean.Applications;
import com.my.scb.polymath.dashboard.bean.IncidentTicketDetails;
import com.my.scb.polymath.dashboard.bean.MyTicketDetails;
import com.my.scb.polymath.dashboard.exception.PortalCoreException;
import com.my.scb.polymath.dashboard.services.IncidentTicketService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@CrossOrigin()
public class IncidentController {

	@Autowired
	private IncidentTicketService incidentTicketService;

	@ApiOperation("Get the my ticket details")
	@ApiResponses(@ApiResponse(code = 200, message = "Get the my ticket details"))
	@GetMapping("/myTicketDetails")
	public ResponseEntity<MyTicketDetails> getMyTicketDetails(@RequestHeader("name") String name)
			throws PortalCoreException {

		if (StringUtils.isNotBlank(name)) {
			return ResponseEntity.ok(incidentTicketService.getMyTicketDetails(name));
		} else {
			throw new PortalCoreException("E03", "Input Params is not empty");
		}
	}

	@ApiOperation("Retrieve the application details")
	@ApiResponses(@ApiResponse(code = 200, message = "Retrieve the application details"))
	@GetMapping("/applciationDetails")
	public ResponseEntity<Applications> getApplicationDetails() throws PortalCoreException {

		return ResponseEntity.ok(incidentTicketService.getApplicationDetails());
	}

	@ApiOperation("Retrieve the Application Summary details")
	@ApiResponses(@ApiResponse(code = 200, message = "Retrieve the Application Summary details"))
	@GetMapping("/applicationSummary")
	public ResponseEntity<ApplicationSummary> retrieveApplicationSummary(
			@RequestParam(name = "applicationName", required = true) String applicationName)
			throws PortalCoreException {

		if (StringUtils.isNotBlank(applicationName)) {
			return ResponseEntity.ok(incidentTicketService.retrieveApplicationSummary(applicationName));
		} else {
			throw new PortalCoreException("E03", "Input Params is not empty");
		}
	}

	@ApiOperation("Retrieve the incident ticket details")
	@ApiResponses(@ApiResponse(code = 200, message = "Retrieve the incident ticket details"))
	@GetMapping("/ticketDetail")
	public ResponseEntity<IncidentTicketDetails> retrieveTicketDetails(
			@RequestParam(name = "searchType", required = false) String searchType,
			@RequestParam(name = "countryName", required = false) String countryName,
			@RequestParam(name = "resourceName", required = false) String resourceName,
			@RequestParam(name = "reportName", required = false) String reportName,
			@RequestParam(name = "applicationName", required = false) String applicationName,
			@RequestParam(name = "pageNo", required = true) Integer pageNo,
			@RequestParam(name = "pageSize", required = true) Integer pageSize, @RequestHeader("name") String name) throws PortalCoreException {

		return ResponseEntity.ok(incidentTicketService.retrieveTicketDetails(searchType, countryName, resourceName,
				reportName, applicationName, pageNo, pageSize, name));
	}
}
