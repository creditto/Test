package com.my.scb.polymath.dashboard.dao;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import com.my.scb.polymath.dashboard.dto.IncidentDetailTO;

public interface IncidentDetailsDao {

	void save(List<IncidentDetailTO> incidentDetailTOList);
	void save();

	BigInteger countByAssignedTo(String resourceName);

	BigInteger countByPotential(String resourceName);

	BigInteger countByAging(String resourceName);

	List<String> getApplicationNameList();

	BigInteger countByAssignedGroup(String applicationName);

	BigInteger getApplicationWiseSLAMet(String applicationName);

	BigInteger getApplicationWiseNotSLAMet(String applicationName);

	List<Object[]> getResourceWiseTotalCount(String applicationName);

	List<Object[]> getResourceWiseSLAMetCount(String applicationName);

	List<Object[]> getResourceWiseSLANotMetCount(String applicationName);

	List<Object[]> getCountryWiseTotalCount(String applicationName);

	List<Object[]> getCountryWiseSLAMetCount(String applicationName);

	List<Object[]> getCountryWiseSLANotMetCount(String applicationName);

	List<Object[]> getThematicAnalysisDetails(String applicationName);

	/**
	 * 
	 */

	BigInteger getApplicationResourceWiseTotalCount(String applicationName, String resourceName);

	BigInteger getApplicationResourceWiseSLAMetCount(String applicationName, String resourceName);

	BigInteger getApplicationResourceWiseSLANotMetCount(String applicationName, String resourceName);

	BigInteger getApplicationCountryWiseTotalCount(String applicationName, String country);

	BigInteger getApplicationCountryWiseSLAMetCount(String applicationName, String country);

	BigInteger getApplicationCountryWiseSLANotMetCount(String applicationName, String country);

	BigInteger getApplicationThematicAnalysisCount(String applicationName, String reportName);
	
	/**
	 * 
	 */
	
	public Page<Object[]> getOpenTicketDetails(String userName, Pageable pageable);

}
