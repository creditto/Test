package com.my.scb.polymath.dashboard.dao.impl;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.my.scb.polymath.dashboard.dao.IncidentDetailsDao;
import com.my.scb.polymath.dashboard.dto.IncidentDetailTO;
import com.my.scb.polymath.dashboard.entity.ApplicationNames;
import com.my.scb.polymath.dashboard.entity.IncidentDetails;
import com.my.scb.polymath.dashboard.repository.ApplicationNameRepository;
import com.my.scb.polymath.dashboard.repository.IncidentDetailRepository;

@Service
@Transactional
public class IncidentDetailsDaoImpl implements IncidentDetailsDao {

	@Autowired
	private IncidentDetailRepository incidentDetailRepository;

	@Autowired
	private ApplicationNameRepository applicationNameRepository;

	@Override
	public void save(List<IncidentDetailTO> incidentDetailTOList) {

		for (@SuppressWarnings("rawtypes")
		Iterator iterator = incidentDetailTOList.iterator(); iterator.hasNext();) {

			save((IncidentDetailTO) iterator.next());
		}
		
		save();
	}
	
	@Override
	public void save() {
		
		applicationNameRepository.save(new ApplicationNames("MEGELLAN OTP PROD TSO SUP"));
		applicationNameRepository.save(new ApplicationNames("MEGELLAN LTP PROD TSO SUP"));
	}

	public IncidentDetails save(IncidentDetailTO incidentDetailTO) {
		return incidentDetailRepository.save(new IncidentDetails(incidentDetailTO.getIncidentNumber(),
				incidentDetailTO.getOpened(), incidentDetailTO.getClosed(), incidentDetailTO.getShort_desc(),
				incidentDetailTO.getCaller(), incidentDetailTO.getCountry(), incidentDetailTO.getPriority(),
				incidentDetailTO.getState(), incidentDetailTO.getAssignedGroup(), incidentDetailTO.getAssignedTo(),
				incidentDetailTO.getUpdated(), incidentDetailTO.getCreated(), incidentDetailTO.getDescription()));
	}

	public BigInteger countByAssignedTo(String resourceName) {
		return incidentDetailRepository.countByTotal(resourceName);
	}

	public BigInteger countByPotential(String resourceName) {
		return incidentDetailRepository.countByPotential(resourceName);
	}

	public BigInteger countByAging(String resourceName) {
		return incidentDetailRepository.countByAging(resourceName);
	}

	public BigInteger countByAssignedGroup(String applicationName) {
		return incidentDetailRepository.countByAssignedGroup(applicationName);
	}

	public BigInteger getApplicationWiseSLAMet(String applicationName) {
		return incidentDetailRepository.getApplicationWiseSLAMet(applicationName);
	}

	public BigInteger getApplicationWiseNotSLAMet(String applicationName) {
		return incidentDetailRepository.getApplicationWiseNotSLAMet(applicationName);
	}

	public List<String> getApplicationNameList() {
		return applicationNameRepository.getApplicationNameList();

	}

	public List<Object[]> getResourceWiseTotalCount(String applicationName) {
		return incidentDetailRepository.getResourceWiseTotalCount(applicationName);
	}

	public List<Object[]> getResourceWiseSLAMetCount(String applicationName) {
		return incidentDetailRepository.getResourceWiseSLAMetCount(applicationName);
	}

	public List<Object[]> getResourceWiseSLANotMetCount(String applicationName) {
		return incidentDetailRepository.getResourceWiseSLANotMetCount(applicationName);
	}

	public List<Object[]> getCountryWiseTotalCount(String applicationName) {
		return incidentDetailRepository.getCountryWiseTotalCount(applicationName);
	}

	public List<Object[]> getCountryWiseSLAMetCount(String applicationName) {
		return incidentDetailRepository.getCountryWiseSLAMetCount(applicationName);
	}

	public List<Object[]> getCountryWiseSLANotMetCount(String applicationName) {
		return incidentDetailRepository.getCountryWiseSLANotMetCount(applicationName);
	}

	public List<Object[]> getThematicAnalysisDetails(String applicationName) {

		return incidentDetailRepository.getThematicAnalysisDetails(applicationName);
	}

	public BigInteger getApplicationResourceWiseTotalCount(String applicationName, String resourceName) {

		return incidentDetailRepository.getApplicationResourceWiseTotalCount(applicationName, resourceName);
	}

	public BigInteger getApplicationResourceWiseSLAMetCount(String applicationName, String resourceName) {
		return incidentDetailRepository.getApplicationResourceWiseSLAMetCount(applicationName, resourceName);
	}

	public BigInteger getApplicationResourceWiseSLANotMetCount(String applicationName, String resourceName) {
		return incidentDetailRepository.getApplicationResourceWiseSLANotMetCount(applicationName, resourceName);
	}

	public BigInteger getApplicationCountryWiseTotalCount(String applicationName, String countryName) {
		return incidentDetailRepository.getApplicationCountryWiseTotalCount(applicationName, countryName);
	}

	public BigInteger getApplicationCountryWiseSLAMetCount(String applicationName, String countryName) {
		return incidentDetailRepository.getApplicationCountryWiseSLAMetCount(applicationName, countryName);
	}

	public BigInteger getApplicationCountryWiseSLANotMetCount(String applicationName, String countryName) {
		return incidentDetailRepository.getApplicationCountryWiseSLANotMetCount(applicationName, countryName);
	}

	public BigInteger getApplicationThematicAnalysisCount(String applicationName, String reportName) {
		return incidentDetailRepository.getApplicationThematicAnalysisCount(applicationName, reportName);
	}

	public Page<Object[]> getOpenTicketDetails(String userName, Pageable pageable) {
		return incidentDetailRepository.getOpenTicketDetails(userName, pageable);
	}
}
