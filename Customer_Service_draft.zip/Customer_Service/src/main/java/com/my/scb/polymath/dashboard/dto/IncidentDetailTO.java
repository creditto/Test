package com.my.scb.polymath.dashboard.dto;

import java.util.Date;

public class IncidentDetailTO {

	private String incidentNumber;
	private Date opened;
	private Date closed;
	private String short_desc;
	private String caller;
	private String country;
	private String priority;
	private String state;
	private String assignedGroup;
	private String assignedTo;
	private Date updated;
	private Date created;
	private String description;

	public IncidentDetailTO() {
	}

	public IncidentDetailTO(String incidentNumber, Date opened, Date closed, String short_desc, String caller, String country,
			String priority, String state, String assignedGroup, String assignedTo, Date updated, Date created,
			String description) {

		this.incidentNumber = incidentNumber;
		this.opened = opened;
		this.closed = closed;
		this.short_desc = short_desc;
		this.caller = caller;
		this.country = country;
		this.priority = priority;
		this.state = state;
		this.assignedGroup = assignedGroup;
		this.assignedTo = assignedTo;
		this.updated = updated;
		this.created = created;
		this.description = description;
	}

	public Date getOpened() {
		return opened;
	}

	public Date getClosed() {
		return closed;
	}

	public String getShort_desc() {
		return short_desc;
	}

	public String getCaller() {
		return caller;
	}

	public String getCountry() {
		return country;
	}

	public String getPriority() {
		return priority;
	}

	public String getState() {
		return state;
	}

	public String getAssignedGroup() {
		return assignedGroup;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public Date getUpdated() {
		return updated;
	}

	public Date getCreated() {
		return created;
	}

	public String getDescription() {
		return description;
	}

	public void setOpened(Date opened) {
		this.opened = opened;
	}

	public void setClosed(Date closed) {
		this.closed = closed;
	}

	public void setShort_desc(String short_desc) {
		this.short_desc = short_desc;
	}

	public void setCaller(String caller) {
		this.caller = caller;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getIncidentNumber() {
		return incidentNumber;
	}

	public void setIncidentNumber(String incidentNumber) {
		this.incidentNumber = incidentNumber;
	}
}
