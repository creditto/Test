package com.my.scb.polymath.dashboard.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

@Entity
@Table(name = "INCIDENTDETAILS")
public class IncidentDetails {

	@Id
	@Column(name = "NUMBER")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long number;
	
	@Column(name = "INCIDENTNUMBER")
	private String incidentNumber;

	@Column(name = "OPENED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date opened;

	@Column(name = "CLOSED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date closed;

	@Size(max = 100)
	@Column(name = "SHORT_DESC")
	private String short_desc;

	@Size(max = 100)
	@Column(name = "CALLER")
	private String caller;

	@Size(max = 20)
	@Column(name = "COUNTRY")
	private String country;

	@Size(max = 5)
	@Column(name = "PRIORITY")
	private String priority;

	public Long getNumber() {
		return number;
	}

	public Date getOpened() {
		return opened;
	}

	public Date getClosed() {
		return closed;
	}

	public String getShort_desc() {
		return short_desc;
	}

	public String getCaller() {
		return caller;
	}

	public String getCountry() {
		return country;
	}

	public String getPriority() {
		return priority;
	}

	public String getState() {
		return state;
	}

	public String getAssignedGroup() {
		return assignedGroup;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public Date getUpdated() {
		return updated;
	}

	public Date getCreated() {
		return created;
	}

	public String getDescription() {
		return description;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public void setOpened(Date opened) {
		this.opened = opened;
	}

	public void setClosed(Date closed) {
		this.closed = closed;
	}

	public void setShort_desc(String short_desc) {
		this.short_desc = short_desc;
	}

	public void setCaller(String caller) {
		this.caller = caller;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public void setUpdated(Date updated) {
		this.updated = updated;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Size(max = 20)
	@Column(name = "STATE")
	private String state;

	@Size(max = 50)
	@Column(name = "ASSIGNED_GROUP")
	private String assignedGroup;

	@Size(max = 50)
	@Column(name = "ASSIGNED_TO")
	private String assignedTo;

	@Column(name = "UPDATED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updated;

	@Column(name = "CREATED")
	@Temporal(TemporalType.TIMESTAMP)
	private Date created;

	@Size(max = 1000)
	@Column(name = "DESCRIPTION")
	private String description;

	public IncidentDetails() {
	}

	public IncidentDetails(String incidentNumber,Date opened, Date closed, String short_desc, String caller, String country,
			String priority, String state, String assignedGroup, String assignedTo, Date updated,
			Date created, String description) {

		this.incidentNumber = incidentNumber;
		this.opened = opened;
		this.closed = closed;
		this.short_desc = short_desc;
		this.caller = caller;
		this.country = country;
		this.priority = priority;
		this.state = state;
		this.assignedGroup = assignedGroup;
		this.assignedTo = assignedTo;
		this.updated = updated;
		this.created = created;
		this.description = description;
	}
}
