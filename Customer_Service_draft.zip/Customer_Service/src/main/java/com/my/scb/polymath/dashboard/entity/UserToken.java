package com.my.scb.polymath.dashboard.entity;

import java.time.LocalDateTime;

import javax.persistence.*;
import javax.validation.constraints.Size;

@Entity
@Table(name = "USER_TOKEN ", uniqueConstraints = { @UniqueConstraint(columnNames = "token") })
public class UserToken {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Size(max = 20)
	private String username;

	@Size(max = 1)
	private String is_valid;

	@Size(max = 500)
	private String token;

	@Column(name = "DATE_CREATED")
	private LocalDateTime dateCreated;

	@Column(name = "DATE_INVALIDATED")
	private LocalDateTime dateInvalidate;

	public UserToken() {
	}

	public UserToken(String userName, String token) {
		this.token = token;
		this.is_valid = "1";
		this.dateCreated = LocalDateTime.now();

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getIs_valid() {
		return is_valid;
	}

	public void setIs_valid(String is_valid) {
		this.is_valid = is_valid;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public LocalDateTime getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDateTime dateCreated) {
		this.dateCreated = dateCreated;
	}

	public LocalDateTime getDateInvalidate() {
		return dateInvalidate;
	}

	public void setDateInvalidate(LocalDateTime dateInvalidate) {
		this.dateInvalidate = dateInvalidate;
	}

}
