package com.my.scb.polymath.dashboard.exception;

public class ServicefaultDetail {

	private MainBasedBean error;

	public MainBasedBean getError() {
		return error;
	}

	public void setError(MainBasedBean error) {
		this.error = error;
	}

}
