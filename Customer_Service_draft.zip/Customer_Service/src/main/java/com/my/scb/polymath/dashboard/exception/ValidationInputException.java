package com.my.scb.polymath.dashboard.exception;

import org.springframework.validation.Errors;

public class ValidationInputException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final Errors errors;

	public ValidationInputException(String message, Errors errors) {
		super(message);
		this.errors = errors;
	}

	public ValidationInputException(Errors errors) {
		this("Input validation failes. Check your entries", errors);
	}

	public Errors getErrors() {
		return errors;
	}
}
