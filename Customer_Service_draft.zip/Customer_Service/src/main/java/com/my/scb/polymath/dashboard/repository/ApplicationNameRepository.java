package com.my.scb.polymath.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.my.scb.polymath.dashboard.entity.ApplicationNames;

@Repository
public interface ApplicationNameRepository extends CrudRepository<ApplicationNames, Long> {

	@Query("SELECT t.applicationName FROM ApplicationNames t")
	List<String> getApplicationNameList();
}
