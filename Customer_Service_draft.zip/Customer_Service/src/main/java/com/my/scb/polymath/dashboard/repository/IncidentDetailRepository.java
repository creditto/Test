package com.my.scb.polymath.dashboard.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.my.scb.polymath.dashboard.entity.IncidentDetails;

@Repository
public interface IncidentDetailRepository extends CrudRepository<IncidentDetails, Long> {

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_TO = ?1")
	BigInteger countByTotal(String resourceName);

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_TO = ?1 AND "
			+ "(TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) < 72")
	BigInteger countByPotential(String resourceName);

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_TO = ?1 "
			+ "AND (TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) > 72")
	BigInteger countByAging(String resourceName);

	/**
	 * 
	 * 
	 */

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1")
	BigInteger countByAssignedGroup(String applicationName);

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 AND "
			+ "(TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) < 72")
	BigInteger getApplicationWiseSLAMet(String applicationName);

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 "
			+ "AND (TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) > 72")
	BigInteger getApplicationWiseNotSLAMet(String applicationName);

	/**
	 * 
	 */

	@Query("SELECT t.assignedTo,COUNT(t.number) FROM IncidentDetails t WHERE t.assignedGroup = ?1 GROUP BY t.assignedTo")
	List<Object[]> getResourceWiseTotalCount(String applicationName);

	@Query(nativeQuery = true, value = "SELECT t.ASSIGNED_TO,COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 AND "
			+ "(TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) < 72 GROUP BY t.ASSIGNED_TO")
	List<Object[]> getResourceWiseSLAMetCount(String applicationName);

	@Query(nativeQuery = true, value = "SELECT t.ASSIGNED_TO,COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 "
			+ "AND (TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) > 72 GROUP BY t.ASSIGNED_TO")
	List<Object[]> getResourceWiseSLANotMetCount(String applicationName);

	/**
	 * 
	 */

	@Query("SELECT t.country,COUNT(t.number) FROM IncidentDetails t WHERE t.assignedGroup = ?1 GROUP BY t.assignedGroup")
	List<Object[]> getCountryWiseTotalCount(String applicationName);

	@Query(nativeQuery = true, value = "SELECT t.COUNTRY,COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 AND "
			+ "(TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) < 72 GROUP BY t.COUNTRY")
	List<Object[]> getCountryWiseSLAMetCount(String applicationName);

	@Query(nativeQuery = true, value = "SELECT t.COUNTRY,COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 "
			+ "AND (TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) > 72 GROUP BY t.COUNTRY")
	List<Object[]> getCountryWiseSLANotMetCount(String applicationName);

	/**
	 * 
	 */

	@Query(nativeQuery = true, value = "SELECT t.SHORT_DESC,COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 AND "
			+ "(TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) > 72 GROUP BY t.SHORT_DESC")
	List<Object[]> getThematicAnalysisDetails(String applicationName);

	/**
	 * 
	 */

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 "
			+ "AND t.ASSIGNED_TO = ?2")
	BigInteger getApplicationResourceWiseTotalCount(String applicationName, String resourceName);

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 AND "
			+ "(TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) < 72 AND t.ASSIGNED_TO = ?2")
	BigInteger getApplicationResourceWiseSLAMetCount(String applicationName, String resourceName);

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 "
			+ "AND (TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) > 72 AND t.ASSIGNED_TO = ?2")
	BigInteger getApplicationResourceWiseSLANotMetCount(String applicationName, String resourceName);

	/**
	 * 
	 */

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 "
			+ "AND t.COUNTRY = ?2")
	BigInteger getApplicationCountryWiseTotalCount(String applicationName, String country);

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 AND "
			+ "(TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) < 72 AND t.COUNTRY = ?2")
	BigInteger getApplicationCountryWiseSLAMetCount(String applicationName, String country);

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 "
			+ "AND (TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) > 72 GROUP BY t.COUNTRY = ?2")
	BigInteger getApplicationCountryWiseSLANotMetCount(String applicationName, String country);

	/**
	 * 
	 */

	@Query(nativeQuery = true, value = "SELECT COUNT(1) FROM INCIDENTDETAILS t WHERE t.ASSIGNED_GROUP = ?1 AND "
			+ "(TIMESTAMPDIFF(SECOND, OPENED, CLOSED)/ 3600) < 72 AND t.SHORT_DESC = ?2")
	BigInteger getApplicationThematicAnalysisCount(String applicationName, String reportName);

	@Query(nativeQuery = true, value = "SELECT t.INCIDENTNUMBER,t.OPENED,t.CLOSED,t.SHORT_DESC,t.CALLER,"
			+ "t.COUNTRY,t.PRIORITY,t.STATE,t.ASSIGNED_GROUP,t.ASSIGNED_TO,t.UPDATED,t.CREATED," + "t.DESCRIPTION\r\n"
			+ " FROM INCIDENTDETAILS t WHERE t.ASSIGNED_TO = ?1")
	Page<Object[]> getOpenTicketDetails(String userName, Pageable pageable);

}
