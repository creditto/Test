package com.my.scb.polymath.dashboard.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.my.scb.polymath.dashboard.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {

	@Query("SELECT t FROM User t WHERE t.userName = ?1 AND t.deleted = 0")
	Optional<User> findByUserName(String token);

}
