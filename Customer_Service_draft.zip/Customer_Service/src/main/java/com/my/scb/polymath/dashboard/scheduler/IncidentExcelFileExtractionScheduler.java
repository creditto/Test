package com.my.scb.polymath.dashboard.scheduler;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.my.scb.polymath.dashboard.services.IncidentTicketService;

@Component
@ConditionalOnProperty(value = "incident.file.extraction.scheduler.enable", havingValue = "1")
public class IncidentExcelFileExtractionScheduler {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private IncidentTicketService incidentTicketService;

	@Scheduled(cron = "${incident.file.extraction.scheduler.cronExpression}")
	public void extractFlatFile() {

		logger.info("Started extractIncidentExcelFile ", new Date());

		try {
			incidentTicketService.extractIncidentTicketFile();
		} catch (Exception e) {
			logger.info("Exception occur while extract the excel file");
		}
		logger.info("End extractIncidentExcelFile ", new Date());
	}
}
