package com.my.scb.polymath.dashboard.services;

import com.my.scb.polymath.dashboard.bean.ApplicationSummary;
import com.my.scb.polymath.dashboard.bean.Applications;
import com.my.scb.polymath.dashboard.bean.IncidentTicketDetails;
import com.my.scb.polymath.dashboard.bean.MyTicketDetails;
import com.my.scb.polymath.dashboard.exception.PortalCoreException;

public interface IncidentTicketService {

	void extractIncidentTicketFile();

	MyTicketDetails getMyTicketDetails(String name);

	Applications getApplicationDetails();

	ApplicationSummary retrieveApplicationSummary(String applicationName);

	IncidentTicketDetails retrieveTicketDetails(String searchType, String countryName, String resourceName,
			String reportName, String applicationName, Integer pageNo, Integer pageSize, String userName) throws PortalCoreException;

}
