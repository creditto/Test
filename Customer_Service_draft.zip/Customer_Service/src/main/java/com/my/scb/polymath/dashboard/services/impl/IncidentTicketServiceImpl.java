package com.my.scb.polymath.dashboard.services.impl;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.my.scb.polymath.dashboard.bean.ApplicationSummary;
import com.my.scb.polymath.dashboard.bean.Applications;
import com.my.scb.polymath.dashboard.bean.CountryWiseLPI;
import com.my.scb.polymath.dashboard.bean.CountryWiseLPIDetail;
import com.my.scb.polymath.dashboard.bean.IncidentTicketDetail;
import com.my.scb.polymath.dashboard.bean.IncidentTicketDetails;
import com.my.scb.polymath.dashboard.bean.MyTicketDetails;
import com.my.scb.polymath.dashboard.bean.ResourceWiseLPI;
import com.my.scb.polymath.dashboard.bean.ResourceWiseLPIDetail;
import com.my.scb.polymath.dashboard.bean.ThematicAnalysis;
import com.my.scb.polymath.dashboard.bean.ThematicAnalysisDetail;
import com.my.scb.polymath.dashboard.bean.TicketDetails;
import com.my.scb.polymath.dashboard.constants.SearchType;
import com.my.scb.polymath.dashboard.dao.IncidentDetailsDao;
import com.my.scb.polymath.dashboard.dto.IncidentDetailTO;
import com.my.scb.polymath.dashboard.exception.PortalCoreException;
import com.my.scb.polymath.dashboard.services.IncidentTicketService;
import com.my.scb.polymath.dashboard.util.DateUtil;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@Service
public class IncidentTicketServiceImpl implements IncidentTicketService {

	private final Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private IncidentDetailsDao incidentDetailsDao;

	@Value("${incident.file.location}")
	private String location;

	@Value("${incident.file.name}")
	private String fileName;

	@Value("${incident.file.processed}")
	private String processed;

	@Override
	public void extractIncidentTicketFile() {

		Path file = Paths.get(location + File.separator + fileName);

		if (file.toFile().exists()) {

			try {
				List<IncidentDetailTO> incidentDetailTOList = getIncidentDetailTOList(file.toFile());

				incidentDetailsDao.save(incidentDetailTOList);

				File processedFolderPath = new File(processed);

				if (!processedFolderPath.exists()) {
					processedFolderPath.mkdir();
				}

				File destinationFile = new File(
						processedFolderPath + File.separator + FilenameUtils.removeExtension(fileName) + "_"
								+ DateUtil.getFormattedDate(new Date(), "ddMMyyyyHHmmss") + ".xlsx");

				FileUtils.moveFile(file.toFile(), destinationFile);

				log.info("File : " + file.toFile().getName() + " move to processed folder");

			} catch (IOException e) {
				log.info("Exception occur while read the flat file");
			}

		} else {
			log.info("Flat file is does not exist");
		}

		log.info("Ended extractCustomerFlatFile ", new Date());
	}

	private List<IncidentDetailTO> getIncidentDetailTOList(File excelFile) {

		List<IncidentDetailTO> IncidentDetailTOList = new ArrayList<IncidentDetailTO>();

		try {

			IncidentDetailTO detailTO = null;
			@SuppressWarnings("resource")
			XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
			XSSFSheet sheet = workbook.getSheetAt(0);

			for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
				XSSFRow row = sheet.getRow(i);

				detailTO = new IncidentDetailTO();
				detailTO.setIncidentNumber(row.getCell(0).getStringCellValue());
				detailTO.setOpened(row.getCell(1).getDateCellValue());
				detailTO.setClosed(row.getCell(2).getDateCellValue());
				detailTO.setShort_desc(row.getCell(3).getStringCellValue());
				detailTO.setCaller(row.getCell(4).getStringCellValue());
				detailTO.setCountry(row.getCell(5).getStringCellValue());
				detailTO.setPriority(Integer.toString((int) row.getCell(6).getNumericCellValue()));
				detailTO.setState(row.getCell(7).getStringCellValue());
				detailTO.setAssignedGroup(row.getCell(8).getStringCellValue());
				detailTO.setAssignedTo(row.getCell(9).getStringCellValue());
				detailTO.setCreated(row.getCell(10).getDateCellValue());
				detailTO.setUpdated(row.getCell(11).getDateCellValue());
				detailTO.setDescription(row.getCell(12).getStringCellValue());
				IncidentDetailTOList.add(detailTO);

			}

		} catch (IOException e) {
			e.printStackTrace();

		} catch (InvalidFormatException e) {
			e.printStackTrace();
		}
		return IncidentDetailTOList;
	}

	public MyTicketDetails getMyTicketDetails(String name) {

		MyTicketDetails myTicketDetails = new MyTicketDetails();
		myTicketDetails.setOpen(incidentDetailsDao.countByAssignedTo(name).longValue());
		myTicketDetails.setPotential(incidentDetailsDao.countByPotential(name).longValue());
		myTicketDetails.setAging(incidentDetailsDao.countByAging(name).longValue());
		return myTicketDetails;
	}

	public Applications getApplicationDetails() {

		Applications applications = new Applications();
		applications.setApplicationList(incidentDetailsDao.getApplicationNameList());
		return applications;
	}

	public ApplicationSummary retrieveApplicationSummary(String applicationName) {

		ApplicationSummary applicationSummary = new ApplicationSummary();
		applicationSummary.setTicketDetails(getTicketDetails(applicationName));
		applicationSummary.setThematicAnalysisDetail((getThematicAnalysisDetail(applicationName)));
		applicationSummary.setResourceWiseLPIDetail(getResourceWiseLPIDetail(applicationName));
		applicationSummary.setCountryWiseLPIDetail(getCountryWiseLPIDetail(applicationName));

		return applicationSummary;
	}

	public IncidentTicketDetails retrieveTicketDetails(String searchType, String countryName, String resourceName,
			String reportName, String applicationName, Integer pageNo, Integer pageSize, String userName)
			throws PortalCoreException {

//		System.out.println("userName :" + userName);
//		System.out.println("countryName :" + countryName);
//		System.out.println("resourceName :" + resourceName);
//		System.out.println("reportName :" + reportName);
//		System.out.println("applicationName :" + applicationName);
//		System.out.println("pageNo :" + pageNo);
//		System.out.println("pageSize :" + pageSize);
//
		IncidentTicketDetails incidentTicketDetails = new IncidentTicketDetails();
//
//		Long numberOfRecord = getNumberOfRecord(searchType, countryName, resourceName, reportName, applicationName,
//				userName);
//
//		System.out.println("numberOfRecord :" + numberOfRecord);
		incidentTicketDetails.setNumberOfRecord(20l);

		incidentTicketDetails.setIncidentTicketDetailList(getIncidentTicketDetailList(searchType, countryName,
				resourceName, reportName, applicationName, userName, pageNo, pageSize));
		return incidentTicketDetails;

	}

	private TicketDetails getTicketDetails(String applicationName) {
		TicketDetails ticketDetails = new TicketDetails();
		ticketDetails.setTotal(incidentDetailsDao.countByAssignedGroup(applicationName).longValue());
		ticketDetails.setSlaMet(incidentDetailsDao.getApplicationWiseSLAMet(applicationName).longValue());
		ticketDetails.setSlaNotMet(incidentDetailsDao.getApplicationWiseNotSLAMet(applicationName).longValue());
		return ticketDetails;
	}

	private ThematicAnalysisDetail getThematicAnalysisDetail(String applicationName) {
		ThematicAnalysisDetail thematicAnalysisDetail = new ThematicAnalysisDetail();
		thematicAnalysisDetail.setThematicAnalysisList(getThematicAnalysisList(applicationName));
		return thematicAnalysisDetail;
	}

	private ResourceWiseLPIDetail getResourceWiseLPIDetail(String applicationName) {

		ResourceWiseLPIDetail resourceWiseLPIDetail = new ResourceWiseLPIDetail();
		resourceWiseLPIDetail.setResourceWiseLPIList(getResourceWiseLPIList(applicationName));
		return resourceWiseLPIDetail;
	}

	private CountryWiseLPIDetail getCountryWiseLPIDetail(String applicationName) {

		CountryWiseLPIDetail countryWiseLPIDetail = new CountryWiseLPIDetail();
		countryWiseLPIDetail.setCountryWiseLPIList(getCountryWiseLPIList(applicationName));
		return countryWiseLPIDetail;
	}

	private List<ThematicAnalysis> getThematicAnalysisList(String applicationName) {

		List<ThematicAnalysis> thematicAnalysisList = new ArrayList<ThematicAnalysis>();
		List<Object[]> objectList = incidentDetailsDao.getThematicAnalysisDetails(applicationName);
		if (objectList != null && !objectList.isEmpty()) {
			for (Iterator iterator = objectList.iterator(); iterator.hasNext();) {
				Object[] object = (Object[]) iterator.next();

				ThematicAnalysis thematicAnalysis = new ThematicAnalysis();
				thematicAnalysis.setName((String) object[0]);
				thematicAnalysis.setCount(((BigInteger) object[1]).longValue());
				thematicAnalysisList.add(thematicAnalysis);
			}
		}

		return thematicAnalysisList;
	}

	private List<ResourceWiseLPI> getResourceWiseLPIList(String applicationName) {

		List<ResourceWiseLPI> resourceWiseLPIList = new ArrayList<ResourceWiseLPI>();

		List<Object[]> objectArrayList = incidentDetailsDao.getResourceWiseTotalCount(applicationName);
		if (objectArrayList != null && !objectArrayList.isEmpty()) {

			Map<String, Long> resourceWiseMap = getTotalMap(objectArrayList);

			if (resourceWiseMap != null && !resourceWiseMap.isEmpty()) {

				Map<String, Long> resourceWiseSLAMetMap = new HashMap<String, Long>();

				Map<String, Long> resourceWiseSLANotMetMap = new HashMap<String, Long>();

				List<Object[]> SlaMetList = incidentDetailsDao.getResourceWiseSLAMetCount(applicationName);

				List<Object[]> SlaNotMetList = incidentDetailsDao.getResourceWiseSLANotMetCount(applicationName);

				if (SlaMetList != null && !SlaMetList.isEmpty()) {

					getSlaMetMap(objectArrayList, resourceWiseSLAMetMap);

				}

				if (SlaNotMetList != null && !SlaNotMetList.isEmpty()) {

					getSlaNotMetMap(objectArrayList, resourceWiseSLANotMetMap);

				}

				for (Map.Entry<String, Long> entry : resourceWiseMap.entrySet()) {

					ResourceWiseLPI resourceWiseLPI = new ResourceWiseLPI();
					resourceWiseLPI.setResourceName(entry.getKey());
					resourceWiseLPI.setTotal(entry.getValue());
					resourceWiseLPI.setSlaMet(resourceWiseSLAMetMap.get(entry.getKey()) != null
							? resourceWiseSLAMetMap.get(entry.getKey())
							: 0l);
					resourceWiseLPI.setSlaNotMet(resourceWiseSLANotMetMap.get(entry.getKey()) != null
							? resourceWiseSLANotMetMap.get(entry.getKey())
							: 0l);
					resourceWiseLPIList.add(resourceWiseLPI);
				}
			}
		}
		return resourceWiseLPIList;
	}

	private Map<String, Long> getTotalMap(List<Object[]> objectArrayList) {
		Map<String, Long> resourceWiseMap = new HashMap<String, Long>();

		for (Iterator iterator = objectArrayList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();

			resourceWiseMap.put((String) object[0], (Long) object[1]);
		}
		return resourceWiseMap;
	}

	private Map<String, Long> getSlaMetMap(List<Object[]> objectArrayList, Map<String, Long> slaMetMap) {

		for (Iterator iterator = objectArrayList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();

			slaMetMap.put((String) object[0], (Long) object[1]);
		}
		return slaMetMap;
	}

	private Map<String, Long> getSlaNotMetMap(List<Object[]> objectArrayList, Map<String, Long> slaNotMetMap) {

		for (Iterator iterator = objectArrayList.iterator(); iterator.hasNext();) {
			Object[] object = (Object[]) iterator.next();

			slaNotMetMap.put((String) object[0], (Long) object[1]);
		}
		return slaNotMetMap;
	}

	private List<CountryWiseLPI> getCountryWiseLPIList(String applicationName) {

		List<CountryWiseLPI> countryWiseLPIList = new ArrayList<CountryWiseLPI>();
		List<Object[]> objectArrayList = incidentDetailsDao.getCountryWiseTotalCount(applicationName);
		if (objectArrayList != null && !objectArrayList.isEmpty()) {

			Map<String, Long> countryWiseMap = getTotalMap(objectArrayList);

			if (countryWiseMap != null && !countryWiseMap.isEmpty()) {

				Map<String, Long> countryWiseSLAMetMap = new HashMap<String, Long>();

				Map<String, Long> countryWiseSLANotMetMap = new HashMap<String, Long>();

				List<Object[]> SlaMetList = incidentDetailsDao.getCountryWiseSLAMetCount(applicationName);

				List<Object[]> SlaNotMetList = incidentDetailsDao.getCountryWiseSLANotMetCount(applicationName);

				if (SlaMetList != null && !SlaMetList.isEmpty()) {

					getSlaMetMap(objectArrayList, countryWiseSLAMetMap);

				}

				if (SlaNotMetList != null && !SlaNotMetList.isEmpty()) {

					getSlaNotMetMap(objectArrayList, countryWiseSLANotMetMap);

				}

				for (Map.Entry<String, Long> entry : countryWiseMap.entrySet()) {

					CountryWiseLPI countryWiseLPI = new CountryWiseLPI();
					countryWiseLPI.setCountryName(entry.getKey());
					countryWiseLPI.setTotal(entry.getValue());
					countryWiseLPI.setSlaMet(
							countryWiseSLAMetMap.get(entry.getKey()) != null ? countryWiseSLAMetMap.get(entry.getKey())
									: 0l);
					countryWiseLPI.setSlaNotMet(countryWiseSLANotMetMap.get(entry.getKey()) != null
							? countryWiseSLANotMetMap.get(entry.getKey())
							: 0l);
					countryWiseLPIList.add(countryWiseLPI);
				}
			}
		}
		return countryWiseLPIList;
	}

	private Long getNumberOfRecord(String searchType, String countryName, String resourceName, String reportName,
			String applicationName, String userName) {

		Long numberOfRecord = 0l;
		if (searchType.equalsIgnoreCase(SearchType.OPEN.name())) {
			numberOfRecord = incidentDetailsDao.countByAssignedTo(userName).longValue();
		} else if (searchType.equalsIgnoreCase(SearchType.POTENTIAL.name())) {

			numberOfRecord = incidentDetailsDao.countByPotential(userName).longValue();
		} else if (searchType.equalsIgnoreCase(SearchType.AGING.name())) {

			numberOfRecord = incidentDetailsDao.countByAging(userName).longValue();
		} else if ((StringUtils.isNotBlank(reportName) || StringUtils.isNotBlank(resourceName)
				|| StringUtils.isNotBlank(countryName)) && StringUtils.isNotBlank(applicationName)) {

			if (StringUtils.isNotBlank(reportName)) {
				numberOfRecord = incidentDetailsDao.getApplicationThematicAnalysisCount(applicationName, reportName)
						.longValue();
			} else if (StringUtils.isNotBlank(resourceName)) {
				if (searchType.equals(SearchType.TOTAL.name())) {
					numberOfRecord = incidentDetailsDao
							.getApplicationResourceWiseTotalCount(applicationName, resourceName).longValue();
				} else if (searchType.equalsIgnoreCase(SearchType.SLAMET.name())) {
					numberOfRecord = incidentDetailsDao
							.getApplicationResourceWiseSLAMetCount(applicationName, resourceName).longValue();
				} else if (searchType.equalsIgnoreCase(SearchType.SLANOTMET.name())) {
					numberOfRecord = incidentDetailsDao
							.getApplicationResourceWiseSLANotMetCount(applicationName, resourceName).longValue();
				}

			} else if (StringUtils.isNotBlank(countryName)) {
				if (searchType.equals(SearchType.TOTAL.name())) {
					numberOfRecord = incidentDetailsDao
							.getApplicationCountryWiseTotalCount(applicationName, countryName).longValue();
				} else if (searchType.equalsIgnoreCase(SearchType.SLAMET.name())) {
					numberOfRecord = incidentDetailsDao
							.getApplicationCountryWiseTotalCount(applicationName, countryName).longValue();
				} else if (searchType.equalsIgnoreCase(SearchType.SLANOTMET.name())) {
					numberOfRecord = incidentDetailsDao
							.getApplicationCountryWiseTotalCount(applicationName, countryName).longValue();
				}
			} else {
				if (searchType.equals(SearchType.TOTAL.name())) {

					numberOfRecord = incidentDetailsDao.countByAssignedGroup(applicationName).longValue();
				} else if (searchType.equalsIgnoreCase(SearchType.SLAMET.name())) {

					numberOfRecord = incidentDetailsDao.getApplicationWiseSLAMet(applicationName).longValue();
				} else if (searchType.equalsIgnoreCase(SearchType.SLANOTMET.name())) {

					numberOfRecord = incidentDetailsDao.getApplicationWiseNotSLAMet(applicationName).longValue();
				}
			}
		}
		return numberOfRecord;

	}

	private List<IncidentTicketDetail> getIncidentTicketDetailList(String searchType, String countryName,
			String resourceName, String reportName, String applicationName, String userName, Integer pageNo,
			Integer pageSize) throws PortalCoreException {

		List<IncidentTicketDetail> incidentTicketDetailsList = new ArrayList<IncidentTicketDetail>();

//		Page<Object[]> pageObjectArrayList = null;
//
//		Pageable paging = PageRequest.of(pageNo, pageSize);
//
//		if (searchType.equalsIgnoreCase(SearchType.OPEN.name())) {
//			pageObjectArrayList = incidentDetailsDao.getOpenTicketDetails(searchType, paging);
//		} else {
//			throw new PortalCoreException("E04", "Invalid Search By option");
//		}
//
//		if (pageObjectArrayList == null || pageObjectArrayList.isEmpty()) {
//			throw new PortalCoreException("E05", "No Data");
//		}
//
//		List<Object[]> objectArrayList = pageObjectArrayList.getContent();
//
//		for (Iterator iterator = objectArrayList.iterator(); iterator.hasNext();) {
//			Object[] objectArray = (Object[]) iterator.next();
//
//			incidentTicketDetailsList.add(null);
//		}
		
		for (int i = 0; i < 10; i++) {
			IncidentTicketDetail bean = new IncidentTicketDetail();
	        bean.setIncidentNumber("INC0958282");
	        bean.setOpened("03/07/2023 17:10:02");
	        bean.setClosed("03/07/2023 17:10:02");
	        bean.setShort_desc("Other - Technical Issues");
	        bean.setCaller("Sung Ka Chiu");
	        bean.setCountry("Hong Kong");
	        bean.setPriority("5");
	        bean.setState("In Progress");
	        bean.setAssignedGroup("MEGELLAN OTP PROD TSO SUP");
	        bean.setAssignedTo("Laskshmi Saranu");
	        bean.setUpdated("07/07/2023 14:33:00");
	       
	        bean.setCreated("07/07/2023 17:10:02");
	        bean.setDescription("Application URL: N/A Affected User: N/A Please provide a datails explanation (limit to 8 0 characters) : RM unable to approve txn TF315R0067 Please attach a screenshot of the error encountered affected country : HK");
	        incidentTicketDetailsList.add(bean);
		}

		return incidentTicketDetailsList;

	}
}
