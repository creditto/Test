//package com.my.scb.polymath.dashboard.services.impl;
//
//import java.util.ArrayList;
//import java.util.Optional;
//
//import javax.transaction.Transactional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//
//import com.my.scb.polymath.dashboard.repository.UserRepository;
//
//@Service
//@Transactional
//public class JwtUserDetailsService implements UserDetailsService {
//
//	@Autowired
//	private UserRepository userRepository;
//
//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//
////		Optional<com.my.maybank.customer.entity.User> user = userRepository.findByUserName(username);
//		
//		com.my.scb.polymath.dashboard.entity.User user1 =  new com.my.scb.polymath.dashboard.entity.User();
//
////		if (user.isPresent()) {
//
//			if ("root".equals(username)) {
//
//				return new User(username, "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJyb290IiwiZXhwIjoxNjg5MjY1NTU2LCJpYXQiOjE2ODkyNDc1NTZ9.p8ZMSganeBgi0SeGa3dwMSZJQaKDCmbMMNryoxvp7fibh3AXCKiGhM-Z7A4-8qvgE0BvOmuc0z73jvUlCoRSqA", new ArrayList<>());
//			} else {
//				throw new UsernameNotFoundException("User not found with username: " + username);
//			}
////		} else {
////			throw new UsernameNotFoundException("User not found with username: " + username);
////		}
//	}
//
//}