package com.my.scb.polymath.dashboard.util;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtil {

	private final static String yyyyMMddHHmmss = "yyyy-MM-dd HH:mm:ss";

	public static String getFormattedDate(Date date, String format) {

		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}

	public static LocalDateTime getFormattedDate(String date) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(yyyyMMddHHmmss);
		return LocalDateTime.parse(date, formatter);
	}

}
