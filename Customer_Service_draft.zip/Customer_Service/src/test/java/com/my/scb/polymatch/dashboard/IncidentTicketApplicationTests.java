package com.my.scb.polymatch.dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncidentTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
