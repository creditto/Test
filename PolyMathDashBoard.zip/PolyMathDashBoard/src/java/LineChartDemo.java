
import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author promoth
 */
@Named("LineChartDemo")
@SessionScoped
public class LineChartDemo implements Serializable
{

    private String name;
    private boolean nameTextBoxRendered;
    private final Logger log = Logger.getLogger(getClass());

    public LineChartDemo()
    {
        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
    }

    public void addAction()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        builder.append("'Africa',");
        builder.append("'America',");
        builder.append("'Asia',");
        builder.append("'Europe'");
        builder.append("]");

        String category = builder.toString();
        log.debug("continet" + category);

        builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 1990'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(631);
        builder.append(",");
        builder.append(727);
        builder.append(",");
        builder.append(3202);
        builder.append(",");
        builder.append(721);
        builder.append("]");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 2000'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(345);
        builder.append(",");
        builder.append(644);
        builder.append(",");
        builder.append(7457);
        builder.append(",");
        builder.append(345);
        builder.append("]");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 2002'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(755);
        builder.append(",");
        builder.append(474);
        builder.append(",");
        builder.append(4774);
        builder.append(",");
        builder.append(757);
        builder.append("]");
        builder.append("}");
        builder.append("]");

        String data = builder.toString();
        log.debug("Data" + data);

        builder = new StringBuilder();
        builder.append("generateLineChart(");
        builder.append(category);
        builder.append(",");
        builder.append(data);
        builder.append(");");

//        createComplaintByNatureChart(['AMBAN'],[{name:'PS', data:[0]},{name:'CC', data:[2]}],'Ageing Claims By Nature')
        log.debug("builder:" + builder.toString());
        PrimeFaces.current().executeScript(builder.toString());
    }
}
