
import com.training.pmex.HandPumpBean;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author promoth
 */
@Named("TestRange")
@SessionScoped
public class TestRange implements Serializable
{

    private String overShoot;
    private List<HandPumpBean> handPumpBeanList = null;

    public void handPumpBean()
    {
        handPumpBeanList = new ArrayList<>();

        for (int i = 0; i < 10; i++)
        {
            HandPumpBean handPumpBean = new HandPumpBean();
            handPumpBean.setTestRangeName(null);
            handPumpBeanList.add(handPumpBean);
        }

    }

    public void pageLoad()
    {
        handPumpBean();

    }

    /**
     * @return the overShoot
     */
    public String getOverShoot()
    {
        return overShoot;
    }

    /**
     * @param overShoot the overShoot to set
     */
    public void setOverShoot(String overShoot)
    {
        this.overShoot = overShoot;
    }

    /**
     * @return the handPumpBeanList
     */
    public List<HandPumpBean> getHandPumpBeanList()
    {
        return handPumpBeanList;
    }

    /**
     * @param handPumpBeanList the handPumpBeanList to set
     */
    public void setHandPumpBeanList(List<HandPumpBean> handPumpBeanList)
    {
        this.handPumpBeanList = handPumpBeanList;
    }

}
