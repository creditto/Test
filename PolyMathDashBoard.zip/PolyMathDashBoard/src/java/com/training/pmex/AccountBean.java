/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

/**
 *
 * @author promoth
 */
public class AccountBean
{

    private Double amount;
    private String amountError;
    
    
    

    /**
     * @return the amount
     */
    public Double getAmount()
    {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(Double amount)
    {
        this.amount = amount;
    }

    /**
     * @return the amountError
     */
    public String getAmountError()
    {
        return amountError;
    }

    /**
     * @param amountError the amountError to set
     */
    public void setAmountError(String amountError)
    {
        this.amountError = amountError;
    }
   
}
