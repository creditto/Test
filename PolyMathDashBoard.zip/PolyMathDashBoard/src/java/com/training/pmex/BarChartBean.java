/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

/**
 *
 * @author promoth
 */
public class BarChartBean
{

    private String category;
    private String year;
    private int dataOne;
    private int dataTwo;
    private int dataThree;
    private int dataFour;

    /**
     * @return the category
     */
    public String getCategory()
    {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category)
    {
        this.category = category;
    }

    /**
     * @return the year
     */
    public String getYear()
    {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(String year)
    {
        this.year = year;
    }

    /**
     * @return the dataOne
     */
    public int getDataOne()
    {
        return dataOne;
    }

    /**
     * @param dataOne the dataOne to set
     */
    public void setDataOne(int dataOne)
    {
        this.dataOne = dataOne;
    }

    /**
     * @return the dataTwo
     */
    public int getDataTwo()
    {
        return dataTwo;
    }

    /**
     * @param dataTwo the dataTwo to set
     */
    public void setDataTwo(int dataTwo)
    {
        this.dataTwo = dataTwo;
    }

    /**
     * @return the dataThree
     */
    public int getDataThree()
    {
        return dataThree;
    }

    /**
     * @param dataThree the dataThree to set
     */
    public void setDataThree(int dataThree)
    {
        this.dataThree = dataThree;
    }

    /**
     * @return the dataFourF
     */
    public int getDataFour()
    {
        return dataFour;
    }

    /**
     * @param dataFourF the dataFourF to set
     */
    public void setDataFour(int dataFour)
    {
        this.dataFour = dataFour;
    }

}
