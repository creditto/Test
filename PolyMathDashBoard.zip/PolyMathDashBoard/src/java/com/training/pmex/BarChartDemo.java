/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/**
 *
 * @author promoth
 */
@Named("BarChartDemo")
@SessionScoped
public class BarChartDemo implements Serializable
{

    private boolean timerRendered;
    private boolean tableRendered;
    private String name;
    private String incidentNumber;
    private boolean nameTextBoxRendered;
    private final Logger log = Logger.getLogger(getClass());
    
    
    private List<String> nameList=new ArrayList<String>();

    public BarChartDemo()
    {
        timerRendered = false;
        PropertyConfigurator.configure("/home/santhanam/Desktop/log4j.properties");
    }
    
    public String getticketAction()
    {
        log.debug("getticketAction..");
        
        
        return null;
        
    }

    public void scriptAction()
    {

        log.debug("print promoth");
    }

    public void addAction()
    {
        log.debug("Inside the add actin");
        
        tableRendered = true;
        
       

        StringBuilder builder = new StringBuilder();
        builder.append("[");
        builder.append("'Africa',");
        builder.append("'America',");
        builder.append("'Asia',");
        builder.append("'Europe'");
        builder.append("]");

        String category = builder.toString();
        log.debug("continet" + category);

        builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 1990'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(631);
        builder.append(",");
        builder.append(727);
        builder.append(",");
        builder.append(3202);
        builder.append(",");
        builder.append(721);
        builder.append("]");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 2000'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(345);
        builder.append(",");
        builder.append(644);
        builder.append(",");
        builder.append(7457);
        builder.append(",");
        builder.append(345);
        builder.append("]");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 2002'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(755);
        builder.append(",");
        builder.append(474);
        builder.append(",");
        builder.append(4774);
        builder.append(",");
        builder.append(757);
        builder.append("]");
        builder.append("}");
        builder.append("]");

        String data = builder.toString();
        log.debug("Data" + data);

        builder = new StringBuilder();
        builder.append("generateBarChart(");
        builder.append(category);
        builder.append(",");
        builder.append(data);
        builder.append(");");

        log.debug("builder:" + builder.toString());
        //   PrimeFaces.current().executeScript(builder.toString());

        FacesContext.getCurrentInstance().getPartialViewContext().getEvalScripts().add(builder.toString());

        builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("name");
        
        
        
        builder.append(":");
        builder.append("'Brands'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("{");
        builder.append("name:");
        builder.append("'Chrome'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(70.67);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'Mozilla'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(54.63);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'Opera'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(3.63);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'UC Browser'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(16.63);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'QQ'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(7.63);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'Internet Explorer'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(37.4);
        builder.append("}");

        builder.append("]");
        builder.append("}");
        builder.append("]");

        String dataOne = builder.toString();
        log.debug("builder" + builder.toString());
        builder = new StringBuilder();
        builder.append("generatePieChart(");
        builder.append(dataOne);
        builder.append(");");

        log.debug("Output" + builder.toString());

//        PrimeFaces.current().executeScript(builder.toString());
        FacesContext.getCurrentInstance().getPartialViewContext().getEvalScripts().add(builder.toString());

        builder = new StringBuilder();
        builder.append("[");
        builder.append("'Africa',");
        builder.append("'America',");
        builder.append("'Asia',");
        builder.append("'Europe'");
        builder.append("]");

        String categoryOne = builder.toString();
        log.debug("continet" + categoryOne);

        builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 1990'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(631);
        builder.append(",");
        builder.append(727);
        builder.append(",");
        builder.append(1673);
        builder.append(",");
        builder.append(721);
        builder.append("]");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 2000'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(345);
        builder.append(",");
        builder.append(644);
        builder.append(",");
        builder.append(457);
        builder.append(",");
        builder.append(1345);
        builder.append("]");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Year 2002'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append(755);
        builder.append(",");
        builder.append(784);
        builder.append(",");
        builder.append(1774);
        builder.append(",");
        builder.append(757);
        builder.append("]");
        builder.append("}");
        builder.append("]");

        String dataTwo = builder.toString();
        log.debug("Data" + data);

        builder = new StringBuilder();
        builder.append("generateLineChart(");
        builder.append(categoryOne);
        builder.append(",");
        builder.append(dataTwo);
        builder.append(");");

        log.debug("builder:" + builder.toString());
//        PrimeFaces.current().executeScript(builder.toString());
        FacesContext.getCurrentInstance().getPartialViewContext().getEvalScripts().add(builder.toString());

        List<DonutPieChartBean> donutPieChartBeanList = new ArrayList<>();
        DonutPieChartBean donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Chrome");
        donutPieChartBeanList.add(donutPieChartBean);

        donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Safari");
        donutPieChartBeanList.add(donutPieChartBean);

        donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Edge");
        donutPieChartBeanList.add(donutPieChartBean);

        donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Firefox");
        donutPieChartBeanList.add(donutPieChartBean);

        donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Other");
        donutPieChartBeanList.add(donutPieChartBean);

        List<DonutPieChartBean> donutPieChartChildBeanList = new ArrayList<>();
        for (DonutPieChartBean donutPieChartBean1 : donutPieChartBeanList)
        {
            DonutPieChartBean pieChartBean = new DonutPieChartBean();

            switch (donutPieChartBean1.getCategory())
            {
                case "Chrome":
                    pieChartBean.setyValue(61.04);
                    pieChartBean.setColorValue(2);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> chromeMap = new LinkedHashMap<>();
                    chromeMap.put("Chrome v97.0", 36.89);
                    chromeMap.put("Chrome v96.0", 6.89);
                    chromeMap.put("Chrome v95.0", 35.89);
                    chromeMap.put("Chrome v94.0", 44.89);
                    chromeMap.put("Chrome v93.0", 27.89);
                    chromeMap.put("Chrome v92.0", 16.89);
                    pieChartBean.setCategoryData(chromeMap);
                    break;
                case "Safari":
                    pieChartBean.setyValue(9.47);
                    pieChartBean.setColorValue(3);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> safariMap = new LinkedHashMap<>();
                    safariMap.put("Safari v15.2", 0.1);
                    safariMap.put("Safari v15.2", 4.3);
                    safariMap.put("Chrome v95.0", 7.3);
                    pieChartBean.setCategoryData(safariMap);
                    break;
                case "Edge":
                    pieChartBean.setyValue(9.32);
                    pieChartBean.setColorValue(5);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> edgeMap = new LinkedHashMap<>();
                    edgeMap.put("edge v15.2", 0.1);
                    edgeMap.put("edge v15.2", 4.3);
                    edgeMap.put("edge v95.0", 7.3);
                    pieChartBean.setCategoryData(edgeMap);
                    break;
                case "Firefox":
                    pieChartBean.setyValue(8.15);
                    pieChartBean.setColorValue(1);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> firefoxMap = new LinkedHashMap<>();
                    firefoxMap.put("fox v15.2", 0.1);
                    firefoxMap.put("fox v15.2", 4.3);
                    firefoxMap.put("fox v95.0", 7.3);
                    pieChartBean.setCategoryData(firefoxMap);
                    break;
                default:
                    pieChartBean.setyValue(11.02);
                    pieChartBean.setColorValue(6);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> OtherMap = new LinkedHashMap<>();
                    OtherMap.put("Other", 0.1);
                    pieChartBean.setCategoryData(OtherMap);
                    break;
            }
            donutPieChartChildBeanList.add(pieChartBean);
        }

        builder = new StringBuilder();
        builder.append("[");
        int lastSize = donutPieChartBeanList.size() - 1;
        for (int i = 0; i < donutPieChartBeanList.size(); i++)
        {
            builder.append("'");
            builder.append(donutPieChartBeanList.get(i).getCategory());
            builder.append("'");
            if (i != lastSize)
            {
                builder.append(",");
            }
        }
        builder.append("]");

        String categorys = builder.toString();

        builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("y:");
        builder.append("61.04");
        builder.append(",");
        builder.append("color:");
        builder.append("'#00e272'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Chrome'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Chrome v97.0'");
        builder.append(",");
        builder.append("'Chrome v96.0'");
        builder.append(",");
        builder.append("'Chrome v95.0'");
        builder.append(",");
        builder.append("'Chrome v94.0'");
        builder.append(",");
        builder.append("'Chrome v92.0'");
        builder.append(",");
        builder.append("'Chrome v90.0'");
        builder.append(",");
        builder.append("'Chrome v89.0'");
        builder.append(",");
        builder.append("'Chrome v70.0'");
        builder.append(",");
        builder.append("'Chrome v69.0'");
        builder.append(",");
        builder.append("'Chrome v50.0'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("36.89");
        builder.append(",");
        builder.append("18.16");
        builder.append(",");
        builder.append("4.57");
        builder.append(",");
        builder.append("17.4");
        builder.append(",");
        builder.append("25.6");
        builder.append(",");
        builder.append("5.8");
        builder.append(",");
        builder.append("14");
        builder.append(",");
        builder.append("6");
        builder.append(",");
        builder.append("22.1");
        builder.append(",");
        builder.append("9");
        builder.append("]");
        builder.append("}");
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("y:");
        builder.append("9.47");
        builder.append(",");
        builder.append("color:");
        builder.append("'#fe6a35'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Safari'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Safari v15.7'");
        builder.append(",");
        builder.append("'Safari v14.3'");
        builder.append(",");
        builder.append("'Safari v13.5'");
        builder.append(",");
        builder.append("'Safari v12.2'");
        builder.append(",");
        builder.append("'Safari v11.7'");
        builder.append(",");
        builder.append("'Safari v10.4'");
        builder.append(",");
        builder.append("'Safari v9.6'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("0.1");
        builder.append(",");
        builder.append("5.5");
        builder.append(",");
        builder.append("6");
        builder.append(",");
        builder.append("7.3");
        builder.append(",");
        builder.append("4.1");
        builder.append(",");
        builder.append("3.2");
        builder.append(",");
        builder.append("2.5");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("y:");
        builder.append("9.32");
        builder.append(",");
        builder.append("color:");
        builder.append("'#d568fb'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Edge'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Edge v97'");
        builder.append(",");
        builder.append("'Edge v96'");
        builder.append(",");
        builder.append("'Edge v95'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("6.62");
        builder.append(",");
        builder.append("7.4");
        builder.append(",");
        builder.append("4.9");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("y:");
        builder.append("8.15");
        builder.append(",");
        builder.append("color:");
        builder.append("'#544fc5'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Firefox'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Firefox v96.0'");
        builder.append(",");
        builder.append("'Firefox v97.0'");
        builder.append(",");
        builder.append("'Firefox v93.0'");
        builder.append(",");
        builder.append("'Firefox v90.0'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("4.65");
        builder.append(",");
        builder.append("7.57");
        builder.append(",");
        builder.append("2.5");
        builder.append(",");
        builder.append("8");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("y:");
        builder.append("11.02");
        builder.append(",");
        builder.append("color:");
        builder.append("'#2ee0ca'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Other'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Other'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("11.02");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        builder.append("]");

        String datas = builder.toString();

        builder = new StringBuilder();

        builder.append("generatedDonutPieChart(");
        builder.append(categorys);
        builder.append(",");
        builder.append(datas);
        builder.append(");");

//        PrimeFaces.current().executeScript(builder.toString());
        FacesContext.getCurrentInstance().getPartialViewContext().getEvalScripts().add(builder.toString());

        builder = new StringBuilder();
        builder.append("[");
        builder.append("'Jet fuel'");
        builder.append(",");
        builder.append("'Duty-free diesel'");
        builder.append(",");
        builder.append("'Petrol'");
        builder.append(",");
        builder.append("'Diesel'");
        builder.append(",");
        builder.append("'Gas oil'");
        builder.append("]");
        String categoryFour = builder.toString();

        builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("type:");
        builder.append("'column'");
        builder.append(",");
        builder.append("name:");
        builder.append("'2020'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("59");
        builder.append(",");
        builder.append("83");
        builder.append(",");
        builder.append("65");
        builder.append(",");
        builder.append("228");
        builder.append(",");
        builder.append("184");
        builder.append("]");
        builder.append("}");
        builder.append(",");

        builder.append("{");
        builder.append("type:");
        builder.append("'column'");
        builder.append(",");
        builder.append("name:");
        builder.append("'2021'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("24");
        builder.append(",");
        builder.append("79");
        builder.append(",");
        builder.append("72");
        builder.append(",");
        builder.append("240");
        builder.append(",");
        builder.append("167");
        builder.append("]");
        builder.append("}");
        builder.append(",");

        builder.append("{");
        builder.append("type:");
        builder.append("'column'");
        builder.append(",");
        builder.append("name:");
        builder.append("'2022'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("58");
        builder.append(",");
        builder.append("88");
        builder.append(",");
        builder.append("75");
        builder.append(",");
        builder.append("250");
        builder.append(",");
        builder.append("176");
        builder.append("]");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("type:");
        builder.append("'spline'");
        builder.append(",");
        builder.append("name:");
        builder.append("'Average'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("47");
        builder.append(",");
        builder.append("83.33");
        builder.append(",");
        builder.append("70.66");
        builder.append(",");
        builder.append("239.33");
        builder.append(",");
        builder.append("175.66");
        builder.append("]");
        builder.append(",");
        builder.append("marker:");
        builder.append("{");
        builder.append("lineWidth:");
        builder.append("2");
        builder.append(",");
        builder.append("lineColor:");
        builder.append("'#fe6a35'");
        builder.append(",");
        builder.append("fillColor:");
        builder.append("'white'");
        builder.append("}");
        builder.append("}");
        builder.append(",");

        builder.append("{");
        builder.append("type:");
        builder.append("'pie'");
        builder.append(",");
        builder.append("name:");
        builder.append("'Total'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("{");
        builder.append("name:");
        builder.append("'2020'");
        builder.append(",");
        builder.append("y:");
        builder.append("619");
        builder.append(",");
        builder.append("color:");
        builder.append("'#2caffe'");
        builder.append(",");
        builder.append("dataLabels:");
        builder.append("{");
        builder.append("enabled:");
        builder.append("true");
        builder.append(",");
        builder.append("distance:");
        builder.append("-50");
        builder.append(",");
        builder.append("format:");
        builder.append("'{point.total} M'");
        builder.append(",");
        builder.append("style:");
        builder.append("{");
        builder.append("fontSize:");
        builder.append("'15px'");
        builder.append("}");
        builder.append("}");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'2021'");
        builder.append(",");
        builder.append("y:");
        builder.append("586");
        builder.append(",");
        builder.append("color:");
        builder.append("'#544fc5'");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'2022'");
        builder.append(",");
        builder.append("y:");
        builder.append("647");
        builder.append(",");
        builder.append("color:");
        builder.append("'#00e272'");
        builder.append("}");
        builder.append("]");
        builder.append(",");
        builder.append("center:");
        builder.append("[");
        builder.append("75");
        builder.append(",");
        builder.append("65");
        builder.append("]");
        builder.append(",");
        builder.append("size:");
        builder.append("100");
        builder.append(",");
        builder.append("innerSize:");
        builder.append("'70%'");
        builder.append(",");
        builder.append("showInLegend:");
        builder.append("false");
        builder.append(",");
        builder.append("dataLabels:");
        builder.append("{");
        builder.append("enabled:");
        builder.append("false");
        builder.append("}");
        builder.append("}");
        builder.append("]");

        String datafour = builder.toString();

        builder = new StringBuilder();

        builder.append("generatepieWithLineChart(");
        builder.append(categoryFour);
        builder.append(",");
        builder.append(datafour);
        builder.append(");");

//        PrimeFaces.current().executeScript(builder.toString());
        FacesContext.getCurrentInstance().getPartialViewContext().getEvalScripts().add(builder.toString());

        int i = 0;

        if (i == 0)
        {
            builder = new StringBuilder();
            builder.append("(");
            builder.append("0.20");
            builder.append("*");
            builder.append("60");
            builder.append(")");

            String timeData = builder.toString();

            builder = new StringBuilder();
            builder.append("startTimer");
            builder.append("(");
            builder.append(timeData);
            builder.append(");");

//            PrimeFaces.current().executeScript(builder.toString());
            PrimeFaces.current().executeScript("startInterval()");

        }
        i++;
    }

    public void pageLoad()
    {
        nameTextBoxRendered = false;
        name = "promoth";
        
         nameList.add("Test1000");
        nameList.add("Test1000");
        nameList.add("Test1000");
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return the nameTextBoxRendered
     */
    public boolean isNameTextBoxRendered()
    {
        return nameTextBoxRendered;
    }

    /**
     * @param nameTextBoxRendered the nameTextBoxRendered to set
     */
    public void setNameTextBoxRendered(boolean nameTextBoxRendered)
    {
        this.nameTextBoxRendered = nameTextBoxRendered;
    }

    /**
     * @return the timerRendered
     */
    public boolean isTimerRendered()
    {
        return timerRendered;
    }

    /**
     * @param timerRendered the timerRendered to set
     */
    public void setTimerRendered(boolean timerRendered)
    {
        this.timerRendered = timerRendered;
    }

    /**
     * @return the nameList
     */
    public List<String> getNameList()
    {
        return nameList;
    }

    /**
     * @param nameList the nameList to set
     */
    public void setNameList(List<String> nameList)
    {
        this.nameList = nameList;
    }

    /**
     * @return the tableRendered
     */
    public boolean isTableRendered()
    {
        return tableRendered;
    }

    /**
     * @param tableRendered the tableRendered to set
     */
    public void setTableRendered(boolean tableRendered)
    {
        this.tableRendered = tableRendered;
    }

    /**
     * @return the incidentNumber
     */
    public String getIncidentNumber()
    {
        return incidentNumber;
    }

    /**
     * @param incidentNumber the incidentNumber to set
     */
    public void setIncidentNumber(String incidentNumber)
    {
        this.incidentNumber = incidentNumber;
    }

}
