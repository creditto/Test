/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/**
 *
 * @author promoth
 */
@Named("BarChartDynamic")
@SessionScoped
public class BarChartDynamic implements Serializable
{

    private String name;
    private boolean nameTextBoxRendered;
    private final Logger log = Logger.getLogger(getClass());

    public BarChartDynamic()
    {
        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
    }
    
    public void pageLoad()
    {
        
    }

    public void addAction()
    {
        List<BarChartBean> barBeanList = new ArrayList<>();

        BarChartBean barChartBean = new BarChartBean();
        barChartBean.setCategory("America");
        barChartBean.setYear("Year 1990");
        barChartBean.setDataOne(435);
        barChartBean.setDataTwo(436);
        barChartBean.setDataThree(633);
        barChartBean.setDataFour(463);
        barBeanList.add(barChartBean);

        barChartBean = new BarChartBean();
        barChartBean.setCategory("America");
        barChartBean.setYear("Year 1990");
        barChartBean.setDataOne(435);
        barChartBean.setDataTwo(436);
        barChartBean.setDataThree(7446);
        barChartBean.setDataFour(463);
        barBeanList.add(barChartBean);

        barChartBean = new BarChartBean();
        barChartBean.setCategory("London");
        barChartBean.setYear("Year 2002");
        barChartBean.setDataOne(856);
        barChartBean.setDataTwo(8585);
        barChartBean.setDataThree(685);
        barChartBean.setDataFour(685);
        barBeanList.add(barChartBean);

        StringBuilder builder = new StringBuilder();
        builder.append("[");
        for (int i = 0; i < barBeanList.size(); i++)
        {

            builder.append("'");
            builder.append(barBeanList.get(i).getCategory());
            builder.append("'");

            int lastSize = barBeanList.size() - 1;

            if (i != lastSize)
            {
                builder.append(",");
            }

        }

        builder.append("]");
        String category = builder.toString();

        log.debug("Category" + category);

        int lastSize = barBeanList.size() - 1;
        builder = new StringBuilder();
        builder.append("[");

        for (int i = 0; i < barBeanList.size(); i++)
        {
            builder.append("{");

            builder.append("name");
            builder.append(":");
            builder.append("'");
            builder.append(barBeanList.get(i).getYear());
            builder.append("'");
            builder.append(",");
            builder.append("data:");
            builder.append("[");
            builder.append(barBeanList.get(i).getDataOne());
            builder.append(",");
            builder.append(barBeanList.get(i).getDataTwo());
            builder.append(",");
            builder.append(barBeanList.get(i).getDataThree());
            builder.append(",");
            builder.append(barBeanList.get(i).getDataFour());
            builder.append("]");
            builder.append("}");

            if (i != lastSize)
            {
                builder.append(",");

            }

        }
        builder.append("]");

        String data = builder.toString();
        log.debug("data" + data);

        builder = new StringBuilder();
        builder.append("generateBarChart(");
        builder.append(category);
        builder.append(",");
        builder.append(data);
        builder.append(");");

        log.debug("Builder" + builder.toString());

        PrimeFaces.current().executeScript(builder.toString());
    }

}
