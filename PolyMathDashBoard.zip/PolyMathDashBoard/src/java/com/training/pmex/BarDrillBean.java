/*
* BarDrillBean.java
* Created on Jul 3, 2023 6:52:31 PM
*
* Copyright © 2015 InfoMindz R&D, SDN BHD.
* All Rights Reserved.
*
* This software is the confidential and proprietary information of
* InfoMindz R&D, SDN BHD.("Confidential Information"). You shall
* not disclose such Confidential Information and shall use it only
* in accordance with the terms of the license agreement you entered
* into with InfoMindz.
 */
package com.training.pmex;

import java.util.Map;

/**
 *
 * @author promoth
 */
public class BarDrillBean
{

    private String category;
    private Integer yaxis;
    private String drillDown;

    private Map<String, Integer> data;

    /**
     * @return the category
     */
    public String getCategory()
    {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category)
    {
        this.category = category;
    }

    /**
     * @return the yaxis
     */
    public Integer getYaxis()
    {
        return yaxis;
    }

    /**
     * @param yaxis the yaxis to set
     */
    public void setYaxis(Integer yaxis)
    {
        this.yaxis = yaxis;
    }

    /**
     * @return the drillDown
     */
    public String getDrillDown()
    {
        return drillDown;
    }

    /**
     * @param drillDown the drillDown to set
     */
    public void setDrillDown(String drillDown)
    {
        this.drillDown = drillDown;
    }

    /**
     * @return the data
     */
    public Map<String, Integer> getData()
    {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(Map<String, Integer> data)
    {
        this.data = data;
    }

}
