/*
* BarDrillDown.java
* Created on Jul 3, 2023 5:47:24 PM
*
* Copyright © 2015 InfoMindz R&D, SDN BHD.
* All Rights Reserved.
*
* This software is the confidential and proprietary information of
* InfoMindz R&D, SDN BHD.("Confidential Information"). You shall
* not disclose such Confidential Information and shall use it only
* in accordance with the terms of the license agreement you entered
* into with InfoMindz.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/**
 *
 * @author promoth
 */
@Named("BarDrillDown")
@SessionScoped
public class BarDrillDown implements Serializable
{

    private final Logger logger = Logger.getLogger(getClass());

    public void pageLoad()
    {
        PropertyConfigurator.configure("C:/training/PmTraining/web/config/log4j.properties");
    }

    public void addAction()
    {
        List<BarDrillBean> barDrillBeanList = new ArrayList<>();
        BarDrillBean barDrillBean = new BarDrillBean();
        barDrillBean.setCategory("Animals");
        barDrillBean.setYaxis(5);
        barDrillBean.setDrillDown("animals");
        barDrillBeanList.add(barDrillBean);

        barDrillBean = new BarDrillBean();
        barDrillBean.setCategory("Fruits");
        barDrillBean.setYaxis(2);
        barDrillBean.setDrillDown("fruits");
        barDrillBeanList.add(barDrillBean);

        barDrillBean = new BarDrillBean();
        barDrillBean.setCategory("Cars");
        barDrillBean.setYaxis(4);
        barDrillBean.setDrillDown("cars");
        barDrillBeanList.add(barDrillBean);

        List<BarDrillBean> barDataChildBeanList = new ArrayList<>();

        for (BarDrillBean barDrillBean1 : barDrillBeanList)
        {
            BarDrillBean barDataChildBean = new BarDrillBean();

            switch (barDrillBean1.getDrillDown())
            {
                case "animals":
                    Map<String, Integer> anmialMap = new LinkedHashMap<>();
                    anmialMap.put("Cats", 4);
                    anmialMap.put("Dogs", 6);
                    anmialMap.put("Cows", 2);
                    anmialMap.put("Sheeps", 1);
                    anmialMap.put("Pigs", 3);
                    anmialMap.put("Horse", 5);
                    anmialMap.put("Parrot", 8);
                    anmialMap.put("Python", 7);
                    anmialMap.put("Goat", 5);
                    anmialMap.put("Love Birds", 4);
                    anmialMap.put("Fish", 10);
                    barDataChildBean.setData(anmialMap);
                    break;
                case "fruits":
                    Map<String, Integer> fruitsMap = new LinkedHashMap<>();
                    fruitsMap.put("Grapes", 6);
                    fruitsMap.put("BlueBerry", 3);
                    fruitsMap.put("StrawBerry", 7);
                    fruitsMap.put("Orange", 4);
                    fruitsMap.put("Pinapple", 6);
                    fruitsMap.put("Gooseberry", 2);
                    fruitsMap.put("WaterMelon", 5);
                    fruitsMap.put("Apple", 9);
                    fruitsMap.put("Peach", 4);
                    fruitsMap.put("Bannana", 1);
                    fruitsMap.put("Pomegranate", 4);
                    fruitsMap.put("Rambutan", 7);
                    barDataChildBean.setData(fruitsMap);
                    break;
                default:
                    Map<String, Integer> carMap = new LinkedHashMap<>();
                    carMap.put("Honda", 5);
                    carMap.put("Cooper", 3);
                    carMap.put("Volkswagen", 6);
                    carMap.put("Toyota", 1);
                    carMap.put("Benz", 6);
                    carMap.put("BMW", 7);
                    carMap.put("Lambo", 10);
                    carMap.put("Masurandii", 6);
                    carMap.put("Royce", 9);
                    carMap.put("Datsun", 8);
                    carMap.put("Hyundai", 2);
                    barDataChildBean.setData(carMap);
                    break;
            }

            barDataChildBean.setCategory(barDrillBean1.getDrillDown());
            barDataChildBeanList.add(barDataChildBean);
        }

        StringBuilder builder = new StringBuilder();

        builder.append("[");
        builder.append("{");
        builder.append("name:");
        builder.append("'Things'");
        builder.append(",");
        builder.append("colorByPoint:");
        builder.append("true");
        builder.append(",");
        builder.append("data:");
        builder.append("[");

        int lastSize = barDrillBeanList.size() - 1;
        for (int i = 0; i < barDrillBeanList.size(); i++)
        {
            builder.append("{");
            builder.append("name:");
            builder.append("'");
            builder.append(barDrillBeanList.get(i).getCategory());
            builder.append("'");
            builder.append(",");
            builder.append("y:");
            builder.append(barDrillBeanList.get(i).getYaxis());
            builder.append(",");
            builder.append("drilldown:");
            builder.append("'");
            builder.append(barDrillBeanList.get(i).getDrillDown());
            builder.append("'");
            builder.append("}");

            if (i != lastSize)
            {
                builder.append(",");
            }
        }

        builder.append("]");
        builder.append("}");
        builder.append("]");

        String category = builder.toString();

        logger.debug("category" + category);

        builder = new StringBuilder();

        for (BarDrillBean barDataChildBean1 : barDataChildBeanList)
        {
            logger.debug("barDataChildBean1 category" + barDataChildBean1.getCategory());
            Map<String, Integer> map = barDataChildBean1.getData();

            for (Map.Entry<String, Integer> entry : map.entrySet())
            {
                logger.debug("name" + entry.getKey());
                logger.debug("value" + entry.getValue());
            }
        }

        builder.append("{");
        builder.append("series:");
        builder.append("[");
        for (BarDrillBean barDataChildBean : barDataChildBeanList)
        {
            builder.append("{");
            builder.append("id:");
            builder.append("'");
            builder.append(barDataChildBean.getCategory());
            builder.append("'");
            builder.append(",");
            builder.append("data:");
            builder.append("[");

            Map<String, Integer> map = barDataChildBean.getData();
            int lastIndex = map.size() - 1;
            int i = 0;
            int j = 0;
            for (Map.Entry<String, Integer> entry : map.entrySet())
            {
                builder.append("[");
                builder.append("'");
                builder.append(entry.getKey());
                builder.append("'");
                builder.append(",");
                builder.append(entry.getValue());
                builder.append("]");

                if (i != lastIndex)
                {
                    builder.append(",");
                }
                i++;
            }
            builder.append("]");
            builder.append("}");
            if (j != lastIndex)
            {
                builder.append(",");
            }
            j++;

        }
        builder.append("]");
        builder.append("}");

        String data = builder.toString();

        logger.debug("data" + data);

        builder = new StringBuilder();

        builder.append("generateBarChart(");
        builder.append(category);
        builder.append(",");
        builder.append(data);
        builder.append(");");

        PrimeFaces.current().executeScript(builder.toString());
    }
}
