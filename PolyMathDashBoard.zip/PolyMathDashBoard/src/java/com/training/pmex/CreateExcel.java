/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author promoth
 */
public class CreateExcel
{


    private XSSFCellStyle commonTableHeader;
    List<TableBean> tableBeanList = new ArrayList<>();
    String newExcel = "/home/promoth/Desktop/ResumeList.xlsx";

    private void populateResumeDetails()
    {
        TableBean bean = new TableBean();
        bean.setFirstName("Promth");
        bean.setLastName("kumar");
        bean.setOrganization("Axis");
        bean.setRegion("Ooty");
        bean.setBranch("kallar");
        bean.setDepartment("IT");
        bean.setDesignation("Developer");
        tableBeanList.add(bean);

        bean.setFirstName("shilpa");
        bean.setLastName("mon");
        bean.setOrganization("Axis");
        bean.setRegion("Ooty");
        bean.setBranch("kallar");
        bean.setDepartment("IT");
        bean.setDesignation("Developer");
        tableBeanList.add(bean);

    }

    private void createCells() throws FileNotFoundException, IOException
    {
        populateResumeDetails();

        XSSFWorkbook workbook = new XSSFWorkbook();

        Style(workbook);

        XSSFSheet sheet = workbook.createSheet("characters");

        XSSFRow rowhead1 = sheet.createRow((short) 1);
        XSSFCell tableHeaderCell1 = rowhead1.createCell(0);

        tableHeaderCell1.setCellStyle(commonTableHeader);

        int cellIndex1 = 0;
        XSSFRow rowhead = sheet.createRow((short) 3);

       
        sheet.setDefaultRowHeight((short) 300);
        rowhead.setHeight((short) 500);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("First Name"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Last Name"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Organization"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Region"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Branch"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Department"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Designation"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        int rowIndex = 4;

        for (TableBean tableBean : tableBeanList)
        {

            XSSFRow row = sheet.createRow(rowIndex);

            int cellIndex = 0;
            XSSFCell cell = row.createCell(cellIndex++);

            cell.setCellValue(tableBean.getFirstName());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getLastName());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getOrganization());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getRegion());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getBranch());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getDepartment());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getDesignation());
            cell = row.createCell(cellIndex++);

            rowIndex++;
        }
        FileOutputStream fileOut = new FileOutputStream(newExcel);
        workbook.write(fileOut);
        fileOut.close();

    }

    public static void main(String[] args) throws IOException
    {
        CreateExcel excel = new CreateExcel();
        excel.populateResumeDetails();
        excel.createCells();
    }

    private void Style(XSSFWorkbook workbook)
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
