/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author promoth
 */
public class DataTable
{

    private List<TableBean> tableBean = new ArrayList<>();

    private void list()
    {
        TableBean bean = new TableBean();
        bean.setFirstName("Promoth");
        bean.setLastName("Kumar");
        
        tableBean.add(bean);

        bean = new TableBean();
        bean.setFirstName("Joel");
        bean.setLastName("saju");
       
        tableBean.add(bean);

        bean = new TableBean();
        bean.setFirstName("Eva");
        bean.setLastName("flora");
       

    }
}
