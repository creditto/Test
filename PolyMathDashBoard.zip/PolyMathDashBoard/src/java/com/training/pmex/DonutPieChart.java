/*
* DonutPieChart.java
* Created on Jul 4, 2023 11:02:40 AM
*
* Copyright © 2015 InfoMindz R&D, SDN BHD.
* All Rights Reserved.
*
* This software is the confidential and proprietary information of
* InfoMindz R&D, SDN BHD.("Confidential Information"). You shall
* not disclose such Confidential Information and shall use it only
* in accordance with the terms of the license agreement you entered
* into with InfoMindz.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/**
 *
 * @author promoth
 */
@Named("DonutPieChart")
@SessionScoped
public class DonutPieChart implements Serializable
{

    private final Logger logger = Logger.getLogger(getClass());

    public void pageLoad()
    {
        PropertyConfigurator.configure("C:/training/PmTraining/web/config/log4j.properties");
    }

    public void addAction()
    {
        List<DonutPieChartBean> donutPieChartBeanList = new ArrayList<>();
        DonutPieChartBean donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Chrome");
        donutPieChartBeanList.add(donutPieChartBean);

        donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Safari");
        donutPieChartBeanList.add(donutPieChartBean);

        donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Edge");
        donutPieChartBeanList.add(donutPieChartBean);

        donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Firefox");
        donutPieChartBeanList.add(donutPieChartBean);

        donutPieChartBean = new DonutPieChartBean();
        donutPieChartBean.setCategory("Other");
        donutPieChartBeanList.add(donutPieChartBean);

        List<DonutPieChartBean> donutPieChartChildBeanList = new ArrayList<>();
        for (DonutPieChartBean donutPieChartBean1 : donutPieChartBeanList)
        {
            DonutPieChartBean pieChartBean = new DonutPieChartBean();

            switch (donutPieChartBean1.getCategory())
            {
                case "Chrome":
                    pieChartBean.setyValue(61.04);
                    pieChartBean.setColorValue(2);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> chromeMap = new LinkedHashMap<>();
                    chromeMap.put("Chrome v97.0", 36.89);
                    chromeMap.put("Chrome v96.0", 6.89);
                    chromeMap.put("Chrome v95.0", 35.89);
                    chromeMap.put("Chrome v94.0", 44.89);
                    chromeMap.put("Chrome v93.0", 27.89);
                    chromeMap.put("Chrome v92.0", 16.89);
                    pieChartBean.setCategoryData(chromeMap);
                    break;
                case "Safari":
                    pieChartBean.setyValue(9.47);
                    pieChartBean.setColorValue(3);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> safariMap = new LinkedHashMap<>();
                    safariMap.put("Safari v15.2", 0.1);
                    safariMap.put("Safari v15.2", 4.3);
                    safariMap.put("Chrome v95.0", 7.3);
                    pieChartBean.setCategoryData(safariMap);
                    break;
                case "Edge":
                    pieChartBean.setyValue(9.32);
                    pieChartBean.setColorValue(5);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> edgeMap = new LinkedHashMap<>();
                    edgeMap.put("edge v15.2", 0.1);
                    edgeMap.put("edge v15.2", 4.3);
                    edgeMap.put("edge v95.0", 7.3);
                    pieChartBean.setCategoryData(edgeMap);
                    break;
                case "Firefox":
                    pieChartBean.setyValue(8.15);
                    pieChartBean.setColorValue(1);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> firefoxMap = new LinkedHashMap<>();
                    firefoxMap.put("fox v15.2", 0.1);
                    firefoxMap.put("fox v15.2", 4.3);
                    firefoxMap.put("fox v95.0", 7.3);
                    pieChartBean.setCategoryData(firefoxMap);
                    break;
                default:
                    pieChartBean.setyValue(11.02);
                    pieChartBean.setColorValue(6);
                    pieChartBean.setCategory(donutPieChartBean1.getCategory());
                    Map<String, Double> OtherMap = new LinkedHashMap<>();
                    OtherMap.put("Other", 0.1);
                    pieChartBean.setCategoryData(OtherMap);
                    break;
            }
            donutPieChartChildBeanList.add(pieChartBean);
        }

        for (DonutPieChartBean donutPieChartBean1 : donutPieChartChildBeanList)
        {
            logger.debug("Category!!!" + donutPieChartBean1.getCategory());
            logger.debug("color!!" + donutPieChartBean1.getColorValue());
            logger.debug("y value!!!!" + donutPieChartBean1.getyValue());

            Map<String, Double> categoryData = donutPieChartBean1.getCategoryData();

            for (Map.Entry<String, Double> entry : categoryData.entrySet())
            {
                logger.debug("entry" + entry.getKey());
                logger.debug("value" + entry.getValue());
            }
        }

        StringBuilder builder = new StringBuilder();
        builder.append("[");
        int lastSize = donutPieChartBeanList.size() - 1;
        for (int i = 0; i < donutPieChartBeanList.size(); i++)
        {
            builder.append("'");
            builder.append(donutPieChartBeanList.get(i).getCategory());
            builder.append("'");
            if (i != lastSize)
            {
                builder.append(",");
            }
        }
        builder.append("]");

        String category = builder.toString();
        logger.debug("category" + category);

        
        
        builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("y:");
        builder.append("61.04");
        builder.append(",");
        builder.append("color:");
        builder.append("'#00e272'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Chrome'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Chrome v97.0'");
        builder.append(",");
        builder.append("'Chrome v96.0'");
        builder.append(",");
        builder.append("'Chrome v95.0'");
        builder.append(",");
        builder.append("'Chrome v94.0'");
        builder.append(",");
        builder.append("'Chrome v92.0'");
        builder.append(",");
        builder.append("'Chrome v90.0'");
        builder.append(",");
        builder.append("'Chrome v89.0'");
        builder.append(",");
        builder.append("'Chrome v70.0'");
        builder.append(",");
        builder.append("'Chrome v69.0'");
        builder.append(",");
        builder.append("'Chrome v50.0'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("36.89");
        builder.append(",");
        builder.append("18.16");
        builder.append(",");
        builder.append("4.57");
        builder.append(",");
        builder.append("17.4");
        builder.append(",");
        builder.append("25.6");
        builder.append(",");
        builder.append("5.8");
        builder.append(",");
        builder.append("14");
        builder.append(",");
        builder.append("6");
        builder.append(",");
        builder.append("22.1");
        builder.append(",");
        builder.append("9");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        
        builder.append(",");
        builder.append("{");
        builder.append("y:");
        builder.append("9.47");
        builder.append(",");
        builder.append("color:");
        builder.append("'#fe6a35'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Safari'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Safari v15.7'");
        builder.append(",");
        builder.append("'Safari v14.3'");
        builder.append(",");
        builder.append("'Safari v13.5'");
        builder.append(",");
        builder.append("'Safari v12.2'");
        builder.append(",");
        builder.append("'Safari v11.7'");
        builder.append(",");
        builder.append("'Safari v10.4'");
        builder.append(",");
        builder.append("'Safari v9.6'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("0.1");
        builder.append(",");
        builder.append("5.5");
        builder.append(",");
        builder.append("6");
        builder.append(",");
        builder.append("7.3");
        builder.append(",");
        builder.append("4.1");
        builder.append(",");
        builder.append("3.2");
        builder.append(",");
        builder.append("2.5");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("y:");
        builder.append("9.32");
        builder.append(",");
        builder.append("color:");
        builder.append("'#d568fb'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Edge'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Edge v97'");
        builder.append(",");
        builder.append("'Edge v96'");
        builder.append(",");
        builder.append("'Edge v95'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("6.62");
        builder.append(",");
        builder.append("7.4");
        builder.append(",");
        builder.append("4.9");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("y:");
        builder.append("8.15");
        builder.append(",");
        builder.append("color:");
        builder.append("'#544fc5'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Firefox'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Firefox v96.0'");
        builder.append(",");
        builder.append("'Firefox v97.0'");
        builder.append(",");
        builder.append("'Firefox v93.0'");
        builder.append(",");
        builder.append("'Firefox v90.0'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("4.65");
        builder.append(",");
        builder.append("7.57");
        builder.append(",");
        builder.append("2.5");
        builder.append(",");
        builder.append("8");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("y:");
        builder.append("11.02");
        builder.append(",");
        builder.append("color:");
        builder.append("'#2ee0ca'");
        builder.append(",");
        builder.append("drilldown:");
        builder.append("{");
        builder.append("name:");
        builder.append("'Other'");
        builder.append(",");
        builder.append("categories:");
        builder.append("[");
        builder.append("'Other'");
        builder.append("]");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("11.02");
        builder.append("]");
        builder.append("}");
        builder.append("}");
        builder.append("]");
        
        String data=builder.toString();
        logger.debug("data"+data);
        

        builder = new StringBuilder();

        builder.append("generatedDonutPieChart(");
        builder.append(category);
        builder.append(",");
        builder.append(data);
        builder.append(");");

        PrimeFaces.current().executeScript(builder.toString());
    }
}
