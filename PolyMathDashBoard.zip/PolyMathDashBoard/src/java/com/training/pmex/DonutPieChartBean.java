/*
* DonutPieChartBean.java
* Created on Jul 4, 2023 11:22:34 AM
*
* Copyright © 2015 InfoMindz R&D, SDN BHD.
* All Rights Reserved.
*
* This software is the confidential and proprietary information of
* InfoMindz R&D, SDN BHD.("Confidential Information"). You shall
* not disclose such Confidential Information and shall use it only
* in accordance with the terms of the license agreement you entered
* into with InfoMindz.
 */
package com.training.pmex;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author promoth
 */
public class DonutPieChartBean
{

    private String category;
    private Double yValue;
    private Integer colorValue;
    private Map<String,Double> categoryData=new LinkedHashMap<>();
    private List<String> categoryValues = new ArrayList<>();
    private List<Double> dataValues = new ArrayList<>();

    /**
     * @return the category
     */
    public String getCategory()
    {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category)
    {
        this.category = category;
    }

    /**
     * @return the yValue
     */
    public Double getyValue()
    {
        return yValue;
    }

    /**
     * @param yValue the yValue to set
     */
    public void setyValue(Double yValue)
    {
        this.yValue = yValue;
    }

    /**
     * @return the colorValue
     */
    public Integer getColorValue()
    {
        return colorValue;
    }

    /**
     * @param colorValue the colorValue to set
     */
    public void setColorValue(Integer colorValue)
    {
        this.colorValue = colorValue;
    }

    /**
     * @return the categoryValues
     */
    public List<String> getCategoryValues()
    {
        return categoryValues;
    }

    /**
     * @param categoryValues the categoryValues to set
     */
    public void setCategoryValues(List<String> categoryValues)
    {
        this.categoryValues = categoryValues;
    }

    /**
     * @return the dataValues
     */
    public List<Double> getDataValues()
    {
        return dataValues;
    }

    /**
     * @param dataValues the dataValues to set
     */
    public void setDataValues(List<Double> dataValues)
    {
        this.dataValues = dataValues;
    }

    /**
     * @return the categoryData
     */
    public Map<String,Double> getCategoryData()
    {
        return categoryData;
    }

    /**
     * @param categoryData the categoryData to set
     */
    public void setCategoryData(Map<String,Double> categoryData)
    {
        this.categoryData = categoryData;
    }

}
