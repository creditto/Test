/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.logging.Level;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 *
 * @author promoth
 */
@Named("DownloadExcel")
@SessionScoped
public class DonwloadExcel implements Serializable
{

    private StreamedContent file;

    public String fileDownloadView() throws FileNotFoundException, IOException
    {

        String filePath = "/home/promoth/Downloads/FlowComputer.xlsx";
        FileOutputStream fileOut;

        FileOutputStream fileOutput;
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFCellStyle pageHeaderCellStyle = excelSheetPageHeaderCellStyle(workbook);
        XSSFCellStyle labelCellStyle = labelCellStyle(workbook);
        XSSFCellStyle labelCenterCellStyle = labelCenterCellStyle(workbook);
        XSSFCellStyle centerRedColorCellStyle = centerRedColorCellStyle(workbook);
        XSSFCellStyle centerGreenColorCellStyle = centerGreenColorCellStyle(workbook);
        XSSFCellStyle labelCenterBoldCellStyle = labelCenterBoldCellStyle(workbook);
        XSSFCellStyle valueCellStyle = valueCellStyle(workbook);
        XSSFCellStyle remarksValueCellStyle = remarksValueCellStyle(workbook);
        XSSFCellStyle tableHeaderCellStyle = tableHeaderCellStyle(workbook);

        int sheetIndex = 1;

        int rowIndex = 0;
        XSSFSheet workSheet = workbook.createSheet("Flow Computer" + " " + sheetIndex);
        for (int j = 0; j < 30; j++)
        {
            if (j == 1 || j == 3 || j == 5)
            {
                workSheet.setColumnWidth(j, 2000);
            }
            else
            {
                workSheet.setColumnWidth(j, 3500);
            }
        }

        XSSFRow xSSFRow = workSheet.createRow(rowIndex);

        XSSFCell createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Instrument Validation");
        createCell.setCellStyle(pageHeaderCellStyle);
        CellRangeAddress address = new CellRangeAddress(0, 0, 0, 2);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(5);
        createCell.setCellValue("validation Status (1)");
        createCell.setCellStyle(pageHeaderCellStyle);
        address = new CellRangeAddress(0, 0, 5, 6);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        String statusTwo = "";
        createCell = xSSFRow.createCell(7);
        createCell.setCellValue("As-Found/As-Left");
        createCell.setCellStyle(pageHeaderCellStyle);
        address = new CellRangeAddress(0, 0, 7, 8);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Pressure Transmitter");
        createCell.setCellStyle(pageHeaderCellStyle);
        address = new CellRangeAddress(1, 1, 0, 2);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        rowIndex += 2;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Client Label");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(2);
        createCell.setCellValue("Test Client");
        createCell.setCellStyle(valueCellStyle);

        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Instrument Tag");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(6);
        createCell.setCellValue("2356");
        createCell.setCellStyle(valueCellStyle);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Session Number");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(2);
        createCell.setCellValue("SN435");
        createCell.setCellStyle(valueCellStyle);

        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Flow Computer Tag");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(6);
        createCell.setCellValue("Flow Computer Tag_1");
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 6, 7);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        rowIndex++;
        String date = "21/02/2023";

        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Test Date");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(2);
        createCell.setCellValue(date);
        createCell.setCellStyle(valueCellStyle);

        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Manufacturer");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(6);
        createCell.setCellValue("Test Manufacturer");
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 6, 7);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        rowIndex++;

        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Location");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(2);
        createCell.setCellValue("Denkil");
        createCell.setCellStyle(valueCellStyle);

        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Model-Name");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(6);
        createCell.setCellValue("Manu Model Test 1");
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 6, 8);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        rowIndex++;

        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Facility");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(2);
        createCell.setCellValue("Acrylic");
        createCell.setCellStyle(valueCellStyle);

        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Serial No");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(6);
        createCell.setCellValue("2114");
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 6, 8);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("acceptance Limit Label(+/-)");
        createCell.setCellStyle(labelCellStyle);

        String acceptanceLimit = "324";
        createCell = xSSFRow.createCell(2);
        createCell.setCellValue(acceptanceLimit);
        createCell.setCellStyle(valueCellStyle);

        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Lrv Label");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(6);
        createCell.setCellValue("21");
        createCell.setCellStyle(valueCellStyle);

        createCell = xSSFRow.createCell(7);
        createCell.setCellValue("KiloPascal");
        createCell.setCellStyle(valueCellStyle);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Acceptance Limit");
        createCell.setCellStyle(labelCellStyle);

        String acceptanceCriteria = "% Error of reading";
        createCell = xSSFRow.createCell(2);
        createCell.setCellValue(acceptanceCriteria);
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 2, 3);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Urv Label");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(6);
        createCell.setCellValue("14");
        createCell.setCellStyle(valueCellStyle);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Span");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(6);
        createCell.setCellValue("7");
        createCell.setCellStyle(valueCellStyle);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Local Gravity Correction Factor");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(7);
        createCell.setCellValue("9.7436346463446");
        createCell.setCellStyle(valueCellStyle);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(4);
        createCell.setCellValue("Temperature Correction Factor");
        createCell.setCellStyle(labelCellStyle);

        createCell = xSSFRow.createCell(7);
        createCell.setCellValue("4.34637373463");
        createCell.setCellStyle(valueCellStyle);

        rowIndex += 2;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Test Equipment");
        createCell.setCellStyle(tableHeaderCellStyle);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Number");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 0, 0);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(1);
        createCell.setCellValue("Description");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 1, 2);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(3);
        createCell.setCellValue("File Serial Number");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 3, 4);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(5);
        createCell.setCellValue("Manufacturer");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 5, 6);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(7);
        createCell.setCellValue("Certificate Number");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 7, 8);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(9);
        createCell.setCellValue("Due Date");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 9, 9);
        setBoderCell(address, workSheet, workbook);

        rowIndex++;
        int serialNumber = 1;

        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue(serialNumber);
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 0, 0);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(1);
        createCell.setCellValue("Equipment Five");
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 1, 2);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(3);
        createCell.setCellValue("SR/Number/03");
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 3, 4);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(5);
        createCell.setCellValue("Test1");
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 5, 6);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(7);
        createCell.setCellValue("2114");
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 7, 8);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        String certDate = "";
        certDate = "14/08/2023";
        createCell = xSSFRow.createCell(9);
        createCell.setCellValue(certDate);
        createCell.setCellStyle(valueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 9, 9);
        setBoderCell(address, workSheet, workbook);

        rowIndex += 2;
        int tableOne = rowIndex;
        int cellIndex = 0;
        int startingCellIndex = 0;
        int secondColumnIndex = 0;
        int footerStartIndex = 0;

        int iterationIndex = 0;
        boolean isFirstRow = iterationIndex == 0;

        xSSFRow = isFirstRow ? workSheet.createRow(tableOne) : workSheet.getRow(tableOne);
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Validation Result(1)");
        createCell.setCellStyle(tableHeaderCellStyle);
        tableOne++;

        xSSFRow = isFirstRow ? workSheet.createRow(tableOne) : workSheet.getRow(tableOne);
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Input");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex + 6);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        cellIndex += 7;
        secondColumnIndex += 7;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("As-Found/As-Left");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex + 4);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        secondColumnIndex += 6;

        tableOne++;

        cellIndex = startingCellIndex;
        xSSFRow = isFirstRow ? workSheet.createRow(tableOne) : workSheet.getRow(tableOne);
        xSSFRow.setHeight((short) 750);
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Nominal Input Pascal");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Nominal Pressure Pascal");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        cellIndex += 2;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Corrected Nominal Pressure Pascal");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        cellIndex += 2;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Indicated Pressure Pascal");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        cellIndex += 2;
        footerStartIndex = cellIndex;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("% error of reading");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("% error of span");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Error of reading");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Error of reading (abs)");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Status");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        tableOne++;

        cellIndex = startingCellIndex;
        xSSFRow = isFirstRow ? workSheet.createRow(tableOne) : workSheet.getRow(tableOne);
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("5.00");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("1");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        cellIndex += 2;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("-0.014");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        cellIndex += 2;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("99834");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        cellIndex += 2;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("-6.063");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("-43.433435");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("-345.346334");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("-34535.34636");
        createCell.setCellStyle(labelCenterCellStyle);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        cellIndex++;

        String s = "Pass";
        String p = "Fail";

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellStyle(s.equals(p)
                ? centerGreenColorCellStyle : centerRedColorCellStyle);
        createCell.setCellValue(p);
        address = new CellRangeAddress(tableOne, tableOne, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);

        xSSFRow = isFirstRow ? workSheet.createRow(tableOne) : workSheet.getRow(tableOne);
        createCell = xSSFRow.createCell(footerStartIndex);
        String largeValue = ("Largest % Error of Reading 0.0");
        createCell.setCellValue(largeValue);
        address = new CellRangeAddress(tableOne, tableOne, footerStartIndex, footerStartIndex + 4);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        tableOne = rowIndex;
        startingCellIndex = secondColumnIndex;
        cellIndex = secondColumnIndex;
        iterationIndex++;

        rowIndex += 4;

        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Remarks and Notes");
        createCell.setCellStyle(tableHeaderCellStyle);

        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        xSSFRow.setHeight((short) 1200);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("Completed");
        createCell.setCellStyle(remarksValueCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 0, 9);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        rowIndex += 5;

        int witnessCount = 3;

        xSSFRow = workSheet.createRow(rowIndex);
        createCell = xSSFRow.createCell(0);
        createCell.setCellValue("");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 0, 0);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(1);
        createCell.setCellValue("Performed By");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 1, 2);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        createCell = xSSFRow.createCell(3);
        createCell.setCellValue("Witness By");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, 3, 2 + (witnessCount * 2));
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);

        cellIndex = 0;
        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        xSSFRow.setHeight((short) 650);
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Organisation");
        createCell.setCellStyle(tableHeaderCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);
        cellIndex++;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex = +2;

        cellIndex = 0;
        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        xSSFRow.setHeight((short) 650);
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Initial/Stamp");
        createCell.setCellStyle(tableHeaderCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);
        cellIndex++;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        cellIndex = 0;
        rowIndex++;
        xSSFRow = workSheet.createRow(rowIndex);
        xSSFRow.setHeight((short) 650);
        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue("Date");
        createCell.setCellStyle(tableHeaderCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex);
        setBoderCell(address, workSheet, workbook);
        cellIndex++;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        createCell = xSSFRow.createCell(cellIndex);
        createCell.setCellValue(" ");
        createCell.setCellStyle(labelCenterBoldCellStyle);
        address = new CellRangeAddress(rowIndex, rowIndex, cellIndex, cellIndex + 1);
        workSheet.addMergedRegion(address);
        setBoderCell(address, workSheet, workbook);
        cellIndex += 2;

        File excelFile = new File(filePath);

        fileOut = new FileOutputStream(excelFile);
        workbook.write(fileOut);
        fileOut.close();

        if (excelFile.exists())
        {
            return excelFile.getAbsolutePath();
        }
        
        try
        {
            InputStream inputStream = new FileInputStream("/home/promoth/Desktop/ResumeList1.xlsx");
            file = new DefaultStreamedContent(inputStream, "application1/xlsx", "ResumeList1.xlsx");
        }
        catch (FileNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(UserDetail.class.getName()).log(Level.SEVERE, null, ex);
        }
        

        return null;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle excelSheetPageHeaderCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(new XSSFColor(new java.awt.Color(0, 143, 179)));
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        pageTitleFont.setFontName("Calibri");

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        style.setFont(pageTitleFont);
        style.setWrapText(false);
        style.setHidden(false);
        return style;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle tableHeaderCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(IndexedColors.BLACK.getIndex());
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        pageTitleFont.setFontName("Calibri");

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        style.setFont(pageTitleFont);
        style.setWrapText(false);
        style.setHidden(false);
        return style;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle labelCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(IndexedColors.BLACK.getIndex());
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setFontName("Calibri");

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setFont(pageTitleFont);
        style.setWrapText(false);
        style.setHidden(false);
        return style;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle labelCenterCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(IndexedColors.BLACK.getIndex());
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setFontName("Calibri");

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(XSSFCellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        style.setFont(pageTitleFont);
        style.setWrapText(true);
        style.setHidden(false);
        return style;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle centerRedColorCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(IndexedColors.BLACK.getIndex());
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setFontName("Calibri");
        pageTitleFont.setColor(IndexedColors.RED.getIndex());

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(XSSFCellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        style.setFont(pageTitleFont);
        style.setWrapText(true);
        style.setHidden(false);
        return style;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle centerGreenColorCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(IndexedColors.BLACK.getIndex());
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setFontName("Calibri");
        pageTitleFont.setColor(IndexedColors.GREEN.getIndex());

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(XSSFCellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        style.setFont(pageTitleFont);
        style.setWrapText(true);
        style.setHidden(false);
        return style;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle labelCenterBoldCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(IndexedColors.BLACK.getIndex());
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setFontName("Calibri");
        pageTitleFont.setBold(true);

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(XSSFCellStyle.ALIGN_CENTER);
        style.setFont(pageTitleFont);
        style.setWrapText(true);
        style.setHidden(false);
        return style;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle valueCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(IndexedColors.BLACK.getIndex());
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setFontName("Calibri");

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setFont(pageTitleFont);
        style.setBorderRight(XSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
        style.setBorderTop(XSSFCellStyle.BORDER_THIN);
        style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
        style.setWrapText(false);
        style.setHidden(false);

        return style;
    }

    /**
     * style for excel sheet header
     *
     * @param unitWorkbook
     * @return
     */
    private XSSFCellStyle remarksValueCellStyle(XSSFWorkbook unitWorkbook)
    {
        XSSFFont pageTitleFont = unitWorkbook.createFont();
        pageTitleFont.setColor(IndexedColors.BLACK.getIndex());
        pageTitleFont.setFontHeightInPoints((short) 10);
        pageTitleFont.setFontName("Calibri");

        XSSFCellStyle style = unitWorkbook.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_LEFT);
        style.setVerticalAlignment(XSSFCellStyle.VERTICAL_TOP);
        style.setFont(pageTitleFont);
        style.setBorderRight(XSSFCellStyle.BORDER_THIN);
        style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
        style.setBorderTop(XSSFCellStyle.BORDER_THIN);
        style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
        style.setWrapText(false);
        style.setHidden(false);

        return style;
    }

    /**
     *
     * @param cellRangeAddress
     * @param worksheet
     * @param workbook
     */
    private void setBoderCell(CellRangeAddress cellRangeAddress, XSSFSheet worksheet, XSSFWorkbook workbook)
    {
        RegionUtil.setBorderTop(CellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
        RegionUtil.setBorderLeft(CellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
        RegionUtil.setBorderRight(CellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
        RegionUtil.setBorderBottom(CellStyle.BORDER_THIN, cellRangeAddress, worksheet, workbook);
    }

    public void initialPageAttributes()
    {

    }

    /**
     * @return the file
     */
    public StreamedContent getFile()
    {
        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(StreamedContent file)
    {
        this.file = file;
    }

}
