/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.jboss.weld.context.RequestContext;
import org.primefaces.PrimeFaces;
import org.primefaces.context.PrimeFacesContext;

/**
 *
 * @author promoth
 */
@Named("GridEx")
@SessionScoped
public class GridEx implements Serializable
{

    private String firstname;
    private String lastname;
    private String password1;
    private boolean firstnamerender;
    private String list_value;
//    private Double password1;
    private boolean switch_value;
    private boolean switch_value1;

    private Date date1;

    private Logger log = Logger.getLogger(GridEx.class.getSimpleName());

    private List<String> menu_list = new ArrayList<>();
    private Double input = new Double(0);
    private Double input1 = new Double(0);
    
   

    public GridEx()
    {
        log.info("Method is call here");

    }

    public void initalPage()
    {
        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
        firstname = "promoth";

        lastname = "";
        log.info("Method is call in initalPage");

        input = 0d;
        input1 = 0d;

        list_value = "Avator";

        movielist();
//        show();

    }

    public void show()
    {
        PrimeFaces.current().executeScript("excetueTestClick();");
        log.info("after click submit button the value is print here");
        log.info(firstname);
        firstnamerender = true;
        log.info(lastname);
        log.info(list_value);
        log.info(date1);
    }

    private void movielist()
    {
        menu_list.add("Terminator");
        menu_list.add("Kaithi");
        menu_list.add("Avator");
        menu_list.add("Titanic");

    }

    /**
     * @return the firstname
     */
    public String getFirstname()
    {
        return firstname;
    }

    /**
     * @param firstname the firstname to set
     */
    public void setFirstname(String firstname)
    {
        this.firstname = firstname;
    }

    /**
     * @return the lastname
     */
    public String getLastname()
    {
        return lastname;
    }

    /**
     * @param lastname the lastname to set
     */
    public void setLastname(String lastname)
    {
        this.lastname = lastname;
    }

    /**
     * @return the password1
     */
    public String getPassword1()
    {
        return password1;
    }

    /**
     * @param password1 the password1 to set
     */
    public void setPassword1(String password1)
    {
        this.password1 = password1;
    }

    /**
     * @return the firstnamerender
     */
    public boolean isFirstnamerender()
    {
        return firstnamerender;
    }

    /**
     * @param firstnamerender the firstnamerender to set
     */
    public void setFirstnamerender(boolean firstnamerender)
    {
        this.firstnamerender = firstnamerender;
    }

    /**
     * @return the list_value
     */
    public String getList_value()
    {
        return list_value;
    }

    /**
     * @param list_value the list_value to set
     */
    public void setList_value(String list_value)
    {
        this.list_value = list_value;
    }

    /**
     * @return the menu_list
     */
    public List<String> getMenu_list()
    {
        return menu_list;
    }

    /**
     * @param menu_list the menu_list to set
     */
    public void setMenu_list(List<String> menu_list)
    {
        this.menu_list = menu_list;
    }

    /**
     * @return the input
     */
    public Double getInput()
    {
        return input;
    }

    /**
     * @param input the input to set
     */
    public void setInput(Double input)
    {
        this.input = input;
    }

    /**
     * @return the input1
     */
    public Double getInput1()
    {
        return input1;
    }

    /**
     * @param input1 the input1 to set
     */
    public void setInput1(Double input1)
    {
        this.input1 = input1;
    }

    /**
     * @return the switch_value
     */
    public boolean isSwitch_value()
    {
        return switch_value;
    }

    /**
     * @param switch_value the switch_value to set
     */
    public void setSwitch_value(boolean switch_value)
    {
        this.switch_value = switch_value;
    }

    /**
     * @return the switch_value1
     */
    public boolean isSwitch_value1()
    {
        return switch_value1;
    }

    /**
     * @param switch_value1 the switch_value1 to set
     */
    public void setSwitch_value1(boolean switch_value1)
    {
        this.switch_value1 = switch_value1;
    }

    public Date getDate1()
    {
        return date1;
    }

    public void setDate1(Date date1)
    {
        this.date1 = date1;
    }
    /**
     * @return the input
     */
}
