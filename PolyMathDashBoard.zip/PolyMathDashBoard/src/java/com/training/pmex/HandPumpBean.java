/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

/**
 *
 * @author promoth
 */
public class HandPumpBean
{

    private Double testRangeName;
    private boolean testRangeUpperDifference;

    /**
     * @return the testRangeUpperDifference
     */
    public boolean isTestRangeUpperDifference()
    {
        return testRangeUpperDifference;
    }

    /**
     * @param testRangeUpperDifference the testRangeUpperDifference to set
     */
    public void setTestRangeUpperDifference(boolean testRangeUpperDifference)
    {
        this.testRangeUpperDifference = testRangeUpperDifference;
    }

    /**
     * @return the testRangeName
     */
    public Double getTestRangeName()
    {
        return testRangeName;
    }

    /**
     * @param testRangeName the testRangeName to set
     */
    public void setTestRangeName(Double testRangeName)
    {
        this.testRangeName = testRangeName;
    }

}
