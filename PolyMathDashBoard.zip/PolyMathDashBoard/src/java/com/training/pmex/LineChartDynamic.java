/*
* LineChartDynamic.java
* Created on Jul 3, 2023 4:26:50 PM
*
* Copyright © 2015 InfoMindz R&D, SDN BHD.
* All Rights Reserved.
*
* This software is the confidential and proprietary information of
* InfoMindz R&D, SDN BHD.("Confidential Information"). You shall
* not disclose such Confidential Information and shall use it only
* in accordance with the terms of the license agreement you entered
* into with InfoMindz.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/**
 *
 * @author promoth
 */
@Named("LineChartDynamic")
@SessionScoped
public class LineChartDynamic implements Serializable
{

    private String name;
    private boolean nameTextBoxRendered;
    private final Logger log = Logger.getLogger(getClass());

    public LineChartDynamic()
    {
        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
    }

    public void pageLoad()
    {

    }

    public void addAction()
    {
        List<BarChartBean> barBeanList = new ArrayList<>();

        BarChartBean barChartBean = new BarChartBean();
        barChartBean.setCategory("America");
        barChartBean.setYear("Year 1990");
        barChartBean.setDataOne(4574);
        barChartBean.setDataTwo(7457);
        barChartBean.setDataThree(7457);
        barChartBean.setDataFour(6346);
        barBeanList.add(barChartBean);

        barChartBean = new BarChartBean();
        barChartBean.setCategory("Edinberg");
        barChartBean.setYear("Year 2000");
        barChartBean.setDataOne(6373);
        barChartBean.setDataTwo(7374);
        barChartBean.setDataThree(7446);
        barChartBean.setDataFour(9665);
        barBeanList.add(barChartBean);

        barChartBean = new BarChartBean();
        barChartBean.setCategory("London");
        barChartBean.setYear("Year 2002");
        barChartBean.setDataOne(5985);
        barChartBean.setDataTwo(7585);
        barChartBean.setDataThree(4757);
        barChartBean.setDataFour(7474);
        barBeanList.add(barChartBean);

        StringBuilder builder = new StringBuilder();
        builder.append("[");
        for (int i = 0; i < barBeanList.size(); i++)
        {

            builder.append("'");
            builder.append(barBeanList.get(i).getCategory());
            builder.append("'");

            int lastSize = barBeanList.size() - 1;

            if (i != lastSize)
            {
                builder.append(",");
            }
        }

        builder.append("]");
        String category = builder.toString();

        log.debug("Category" + category);

        int lastSize = barBeanList.size() - 1;
        builder = new StringBuilder();
        builder.append("[");

        for (int i = 0; i < barBeanList.size(); i++)
        {
            builder.append("{");

            builder.append("name");
            builder.append(":");
            builder.append("'");
            builder.append(barBeanList.get(i).getYear());
            builder.append("'");
            builder.append(",");
            builder.append("data:");
            builder.append("[");
            builder.append(barBeanList.get(i).getDataOne());
            builder.append(",");
            builder.append(barBeanList.get(i).getDataTwo());
            builder.append(",");
            builder.append(barBeanList.get(i).getDataThree());
            builder.append(",");
            builder.append(barBeanList.get(i).getDataFour());
            builder.append("]");
            builder.append("}");

            if (i != lastSize)
            {
                builder.append(",");

            }

        }
        builder.append("]");

        String data = builder.toString();
        log.debug("data" + data);

        builder = new StringBuilder();
        builder.append("generateBarChart(");
        builder.append(category);
        builder.append(",");
        builder.append(data);
        builder.append(");");

        log.debug("Builder" + builder.toString());

        PrimeFaces.current().executeScript(builder.toString());
    }
}
