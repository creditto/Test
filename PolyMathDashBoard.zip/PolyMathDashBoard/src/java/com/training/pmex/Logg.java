/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author promoth
 */
public class Logg
{
//
//    private final Logger log = Logger.getLogger(Logg.class.getSimpleName());
//
//    public Logg()
//    {
//        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
//    }
//
//    public void bug()
//    {
//        for (long i = 0; i < 1000000000; i++)
//        {
//            log.debug("debug");
//            log.info("info");
//            log.warn("warn");
//            log.error("error");
//            log.fatal("fatal");
//            log.trace("trace");
//        }
//
//    }
//
//    public static void main(String[] args)
//    {
//        Logg logg = new Logg();
//        logg.bug();
//    }

}
