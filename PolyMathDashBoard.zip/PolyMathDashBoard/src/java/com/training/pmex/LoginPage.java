/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author promoth
 */
@Named("Loginpage")
@SessionScoped
public class LoginPage implements Serializable
{

    private String member;
    private String pathName;
    private List<String> memberList = null;

    /**
     * 
     */
    public void pageLoad()
    {
        populateOrganizaitonList();
    }

    /**
     * 
     */
    public void save()
    {

    }

    /**
     * populate organization
     */
    private void populateOrganizaitonList()
    {
        memberList = new ArrayList<>(1);
        memberList.add("Anush");
        memberList.add("Yaswanth");
        memberList.add("Venkat");

    }

    /**
     * @return the member
     */
    public String getMember()
    {
        return member;
    }

    /**
     * @param member the member to set
     */
    public void setMember(String member)
    {
        this.member = member;
    }

    /**
     * @return the pathName
     */
    public String getPathName()
    {
        return pathName;
    }

    /**
     * @param pathName the pathName to set
     */
    public void setPathName(String pathName)
    {
        this.pathName = pathName;
    }

    /**
     * @return the memberList
     */
    public List<String> getMemberList()
    {
        return memberList;
    }

    /**
     * @param memberList the memberList to set
     */
    public void setMemberList(List<String> memberList)
    {
        this.memberList = memberList;
    }
}
