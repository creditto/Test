/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/**
 *
 * @author promoth
 */
@Named("PieChartDemo")
@SessionScoped
public class PieChartDemo implements Serializable
{

    private String name;
    private boolean nameTextBoxRendered;
    private final Logger log = Logger.getLogger(getClass());

    public PieChartDemo()
    {
        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
    }

    public void addAction()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Brands'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("{");
        builder.append("name:");
        builder.append("'Chrome'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(70.67);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'Mozilla'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(54.63);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'Opera'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(3.63);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'UC Browser'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(16.63);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'QQ'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(7.63);
        builder.append("}");

        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'Internet Explorer'");
        builder.append(",");
        builder.append("y");
        builder.append(":");
        builder.append(37.4);
        builder.append("}");

        builder.append("]");
        builder.append("}");
        builder.append("]");

        String data = builder.toString();
        log.debug("builder" + builder.toString());
        builder = new StringBuilder();
        builder.append("generatePieChart(");
        builder.append(data);
        builder.append(");");

        log.debug("Output" + builder.toString());

        PrimeFaces.current().executeScript(builder.toString());
    }

}
