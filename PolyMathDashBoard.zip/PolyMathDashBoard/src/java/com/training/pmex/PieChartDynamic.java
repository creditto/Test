/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/**
 *
 * @author promoth
 */
@Named("PieChartDynamic")
@SessionScoped
public class PieChartDynamic implements Serializable
{

    private String name;
    private boolean nameTextBoxRendered;
    private final Logger log = Logger.getLogger(getClass());

    public PieChartDynamic()
    {
        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
    }
    
    public void pageLoad()
    {
        
    }

    public void addAction()
    {
        List<ChartBean> chartBeanList = new ArrayList<>();
        ChartBean chartBean = new ChartBean();
        chartBean.setName("Chrome");
        chartBean.setyAxis("70.79");
        chartBeanList.add(chartBean);

        chartBean = new ChartBean();
        chartBean.setName("Mozilla");
        chartBean.setyAxis("54.63");
        chartBeanList.add(chartBean);

        chartBean = new ChartBean();
        chartBean.setName("Opera");
        chartBean.setyAxis("3.63");
        chartBeanList.add(chartBean);

        chartBean = new ChartBean();
        chartBean.setName("UC Browser");
        chartBean.setyAxis("16.63");
        chartBeanList.add(chartBean);

        chartBean = new ChartBean();
        chartBean.setName("QQ");
        chartBean.setyAxis("43.3");
        chartBeanList.add(chartBean);

        StringBuilder builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("name");
        builder.append(":");
        builder.append("'Brands'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");

        int lastSize = chartBeanList.size() - 1;

        for (int i = 0; i < chartBeanList.size(); i++)
        {
            builder.append("{");
            builder.append("name:");
            builder.append("'");
            builder.append(chartBeanList.get(i).getName());
            builder.append("'");
            builder.append(",");
            builder.append("y");
            builder.append(":");
            builder.append(chartBeanList.get(i).getyAxis());
            builder.append("}");

            if (i != lastSize)
            {
                builder.append(",");

            }

            log.debug("chartBeanList.size()" + chartBeanList.size());

        }
        builder.append("]");
        builder.append("}");
        builder.append("]");

        String data = builder.toString();
        log.debug("@@@@@@@@@@@@" + builder.toString());
        builder = new StringBuilder();
        builder.append("generatePieChart(");
        builder.append(data);
        builder.append(");");

        log.debug("$$$$$$$$$$$$$" + builder.toString());

        PrimeFaces.current().executeScript(builder.toString());
    }

}
