/*
* PieWithLine.java
* Created on Jul 4, 2023 7:15:58 PM
*
* Copyright © 2015 InfoMindz R&D, SDN BHD.
* All Rights Reserved.
*
* This software is the confidential and proprietary information of
* InfoMindz R&D, SDN BHD.("Confidential Information"). You shall
* not disclose such Confidential Information and shall use it only
* in accordance with the terms of the license agreement you entered
* into with InfoMindz.
 */
package com.training.pmex;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.PrimeFaces;

/**
 *
 * @author promoth
 */
@Named("PieWithLine")
@SessionScoped
public class PieWithLine implements Serializable
{

    private final Logger logger = Logger.getLogger(getClass());

    public void pageLoad()
    {
        PropertyConfigurator.configure("C:/training/PmTraining/web/config/log4j.properties");
    }

    public void addAction()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        builder.append("'Jet fuel'");
        builder.append(",");
        builder.append("'Duty-free diesel'");
        builder.append(",");
        builder.append("'Petrol'");
        builder.append(",");
        builder.append("'Diesel'");
        builder.append(",");
        builder.append("'Gas oil'");
        builder.append("]");
        String category = builder.toString();

        builder = new StringBuilder();
        builder.append("[");
        builder.append("{");
        builder.append("type:");
        builder.append("'column'");
        builder.append(",");
        builder.append("name:");
        builder.append("'2020'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("59");
        builder.append(",");
        builder.append("83");
        builder.append(",");
        builder.append("65");
        builder.append(",");
        builder.append("228");
        builder.append(",");
        builder.append("184");
        builder.append("]");
        builder.append("}");
        builder.append(",");

        builder.append("{");
        builder.append("type:");
        builder.append("'column'");
        builder.append(",");
        builder.append("name:");
        builder.append("'2021'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("24");
        builder.append(",");
        builder.append("79");
        builder.append(",");
        builder.append("72");
        builder.append(",");
        builder.append("240");
        builder.append(",");
        builder.append("167");
        builder.append("]");
        builder.append("}");
        builder.append(",");

        builder.append("{");
        builder.append("type:");
        builder.append("'column'");
        builder.append(",");
        builder.append("name:");
        builder.append("'2022'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("58");
        builder.append(",");
        builder.append("88");
        builder.append(",");
        builder.append("75");
        builder.append(",");
        builder.append("250");
        builder.append(",");
        builder.append("176");
        builder.append("]");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("type:");
        builder.append("'spline'");
        builder.append(",");
        builder.append("name:");
        builder.append("'Average'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("47");
        builder.append(",");
        builder.append("83.33");
        builder.append(",");
        builder.append("70.66");
        builder.append(",");
        builder.append("239.33");
        builder.append(",");
        builder.append("175.66");
        builder.append("]");
        builder.append(",");
        builder.append("marker:");
        builder.append("{");
        builder.append("lineWidth:");
        builder.append("2");
        builder.append(",");
        builder.append("lineColor:");
        builder.append("'#fe6a35'");
        builder.append(",");
        builder.append("fillColor:");
        builder.append("'white'");
        builder.append("}");
        builder.append("}");
        builder.append(",");

        builder.append("{");
        builder.append("type:");
        builder.append("'pie'");
        builder.append(",");
        builder.append("name:");
        builder.append("'Total'");
        builder.append(",");
        builder.append("data:");
        builder.append("[");
        builder.append("{");
        builder.append("name:");
        builder.append("'2020'");
        builder.append(",");
        builder.append("y:");
        builder.append("619");
        builder.append(",");
        builder.append("color:");
        builder.append("'#2caffe'");
        builder.append(",");
        builder.append("dataLabels:");
        builder.append("{");
        builder.append("enabled:");
        builder.append("true");
        builder.append(",");
        builder.append("distance:");
        builder.append("-50");
        builder.append(",");
        builder.append("format:");
        builder.append("'{point.total} M'");
        builder.append(",");
        builder.append("style:");
        builder.append("{");
        builder.append("fontSize:");
        builder.append("'15px'");
        builder.append("}");
        builder.append("}");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'2021'");
        builder.append(",");
        builder.append("y:");
        builder.append("586");
        builder.append(",");
        builder.append("color:");
        builder.append("'#544fc5'");
        builder.append("}");
        builder.append(",");
        builder.append("{");
        builder.append("name:");
        builder.append("'2022'");
        builder.append(",");
        builder.append("y:");
        builder.append("647");
        builder.append(",");
        builder.append("color:");
        builder.append("'#00e272'");
        builder.append("}");
        builder.append("]");
        builder.append(",");
        builder.append("center:");
        builder.append("[");
        builder.append("75");
        builder.append(",");
        builder.append("65");
        builder.append("]");
        builder.append(",");
        builder.append("size:");
        builder.append("100");
        builder.append(",");
        builder.append("innerSize:");
        builder.append("'70%'");
        builder.append(",");
        builder.append("showInLegend:");
        builder.append("false");
        builder.append(",");
        builder.append("dataLabels:");
        builder.append("{");
        builder.append("enabled:");
        builder.append("false");
        builder.append("}");
        builder.append("}");
        builder.append("]");

        String data = builder.toString();
        logger.debug("data"+data);

        builder = new StringBuilder();

        builder.append("generatepieWithLineChart(");
        builder.append(category);
        builder.append(",");
        builder.append(data);
        builder.append(");");

        PrimeFaces.current().executeScript(builder.toString());
    }
}
