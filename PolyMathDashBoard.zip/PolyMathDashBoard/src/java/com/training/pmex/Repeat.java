/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.util.Date;

/**
 *
 * @author promoth
 */
public class Repeat
{

    private int id;
    private String carname;
    private String color;

    /**
     * @return the id
     */
    public int getId()
    {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id)
    {
        this.id = id;
    }

    /**
     * @return the carname
     */
    public String getCarname()
    {
        return carname;
    }

    /**
     * @param carname the carname to set
     */
    public void setCarname(String carname)
    {
        this.carname = carname;
    }

    /**
     * @return the color
     */
    public String getColor()
    {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color)
    {
        this.color = color;
    }

   

}
