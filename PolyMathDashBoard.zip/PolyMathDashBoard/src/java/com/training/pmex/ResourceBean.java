
package com.training.pmex;


public class ResourceBean
{
    
     private String resource;
    private int ticket;
    private int sla;
    private int noMet;
    
    private String number;
    private String opened;
    private String shortDescription;
    private String caller;
    private String country;
    private String priority;
    private String state;
    private String group;
    private String assignedTo;
    private String updated;
    private String description;
    private String created;
    /**
     * @return the resource
     */
    public String getResource()
    {
        return resource;
    }

    /**
     * @param resource the resource to set
     */
    public void setResource(String resource)
    {
        this.resource = resource;
    }

    /**
     * @return the ticket
     */
    public int getTicket()
    {
        return ticket;
    }

    /**
     * @param ticket the ticket to set
     */
    public void setTicket(int ticket)
    {
        this.ticket = ticket;
    }

    /**
     * @return the sla
     */
    public int getSla()
    {
        return sla;
    }

    /**
     * @param sla the sla to set
     */
    public void setSla(int sla)
    {
        this.sla = sla;
    }

    /**
     * @return the noMet
     */
    public int getNoMet()
    {
        return noMet;
    }

    /**
     * @param noMet the noMet to set
     */
    public void setNoMet(int noMet)
    {
        this.noMet = noMet;
    }

    /**
     * @return the number
     */
    public String getNumber()
    {
        return number;
    }

    /**
     * @param number the number to set
     */
    public void setNumber(String number)
    {
        this.number = number;
    }

    /**
     * @return the opened
     */
    public String getOpened()
    {
        return opened;
    }

    /**
     * @param opened the opened to set
     */
    public void setOpened(String opened)
    {
        this.opened = opened;
    }

    /**
     * @return the shortDescription
     */
    public String getShortDescription()
    {
        return shortDescription;
    }

    /**
     * @param shortDescription the shortDescription to set
     */
    public void setShortDescription(String shortDescription)
    {
        this.shortDescription = shortDescription;
    }

    /**
     * @return the country
     */
    public String getCountry()
    {
        return country;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country)
    {
        this.country = country;
    }

    /**
     * @return the state
     */
    public String getState()
    {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(String state)
    {
        this.state = state;
    }

    /**
     * @return the group
     */
    public String getGroup()
    {
        return group;
    }

    /**
     * @param group the group to set
     */
    public void setGroup(String group)
    {
        this.group = group;
    }

    /**
     * @return the assignedTo
     */
    public String getAssignedTo()
    {
        return assignedTo;
    }

    /**
     * @param assignedTo the assignedTo to set
     */
    public void setAssignedTo(String assignedTo)
    {
        this.assignedTo = assignedTo;
    }

    /**
     * @return the updated
     */
    public String getUpdated()
    {
        return updated;
    }

    /**
     * @param updated the updated to set
     */
    public void setUpdated(String updated)
    {
        this.updated = updated;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return the created
     */
    public String getCreated()
    {
        return created;
    }

    /**
     * @param created the created to set
     */
    public void setCreated(String created)
    {
        this.created = created;
    }

    /**
     * @return the caller
     */
    public String getCaller()
    {
        return caller;
    }

    /**
     * @param caller the caller to set
     */
    public void setCaller(String caller)
    {
        this.caller = caller;
    }

    /**
     * @return the priority
     */
    public String getPriority() {
        return priority;
    }

    /**
     * @param priority the priority to set
     */
    public void setPriority(String priority) {
        this.priority = priority;
    }
   
}
