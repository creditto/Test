/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.primefaces.event.FileUploadEvent;

/**
 *
 * @author promoth
 */
@Named("SiteBean")
@SessionScoped
public class SiteBean implements Serializable
{

    private String firstname;
    private String lastname;
    private String password;
    private String repassword;
    private String movie;
    private Date date1;
    private String display;
    private String seat;
    private String beverages;
    private String phone;
    private String rows;
    private int seatselect;
    private int seattemp;
    private String description;
    private boolean termndcond;
    private boolean headset;

    private String Fnameerror;
    private String lnameerror;
    private String passworderror;
    private String repassworderror;
    private String beverageerror;

    private Date date2;

    private boolean pageShowRendered;
    private boolean pageHideRendered;
    private boolean buttonShowRendered;

    private List<String> movielist = new ArrayList<>();
    private List<String> seatlist = new ArrayList<>();
    private List<String> beaveragelist = new ArrayList<>();
    private List<String> rowlist = new ArrayList<>();
    private List<String> food = new ArrayList<>();
    private List<String> foodlist = new ArrayList<>();
    private List<String> foodcombo = new ArrayList<>();
    private List<String> foodcomboList = new ArrayList<>();
    private Double rupees = new Double(0);

    private List<Employee> employeelist = new ArrayList<>();
    private List<HomeDecor> decorlist = new ArrayList<>();
    private List<Repeat> repeatlist = new ArrayList<>();

    private Logger log = Logger.getLogger(SiteBean.class.getSimpleName());

    public SiteBean()
    {

    }

    public void initial_page()
    {
        String temp = "24";

        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
        log.info("listener is call here");
        password = "";
        onemenulist();
        hide = true;
        date1 = new Date();
        decorTheater();
        seattemp = Integer.parseInt(temp);
        seatTheater();
        carTheater();
        seat = seatlist.get(1);
        display = "2";
        beverageTheater();
        rowTheater();
        termndcond = true;
        headset = true;
        foodTheater();
        food.add("popcorn");
        foodcomboTheater();
        rupees = 0d;
        employeelist1();
        beverages = beaveragelist.get(0);
        hiding();
        seat = seatlist.get(0);
        hiding1();
        Fnameerror = null;
        lastname = null;
        passworderror = null;
        repassworderror = null;
        beverageerror = null;
        date2 = new Date();
        pageShowRendered = true;
        pageHideRendered = false;
        buttonShowRendered = true;

    }

    public void show()
    {

        log.info("after button is clicked");

        log.info("" + firstname);
        log.info(lastname);
        log.info(password);
        log.info(movie);
        log.info(date1);
        log.info("display" + display);
        log.info(seat);
        log.info(beverages);
        log.info(phone);
        log.info(rows);
        log.info(seatselect);
        log.info(seattemp);
        log.info(description);
        log.info(termndcond);
        log.info(headset);
        log.info(food);
        log.info(foodcombo);
        log.info(rupees);
        date1 = new Date();
        Fnameerror = null;
        lnameerror = null;
        passworderror = null;
        repassworderror = null;
        beverageerror = null;

        if (StringUtils.isEmpty(firstname))
        {
            Fnameerror = "First should not empty";
        } else if (!StringUtils.isAlpha(firstname))
        {
            Fnameerror = "It should other than alphabets";
        } else if (StringUtils.length(firstname) >= 10)
        {
            Fnameerror = "Name is invalid";
        } else if (StringUtils.length(firstname) <= 4)
        {
            Fnameerror = "Name is not minimum";
        }
        log.info("ref1" + Fnameerror);

        if (StringUtils.isEmpty(lastname))
        {
            lnameerror = "Last name should not empty";

        }

        if (StringUtils.isEmpty(password))
        {
            passworderror = "Password should not empty";
        }

        if (StringUtils.isEmpty(repassword))
        {
            repassworderror = "Re password should not empty";

        } else if (!StringUtils.equalsIgnoreCase(password, repassword))
        {
            repassworderror = "It is mismatch";
        }

        if (StringUtils.equalsAnyIgnoreCase(beverages, "chocky"))
        {
            beverageerror = "chocky is empty";
        }

    }

    /**
     *
     */
    private void onemenulist()
    {
        movielist.add("Kaithi");
        movielist.add("kong vs godzilla");
        movielist.add("Sardar");
        movielist.add("Dangal");
    }

    private void seatTheater()
    {
        seatlist.add("Chair Type");
        seatlist.add("Flat Type");
        seatlist.add("Bed Type");

    }

    private void beverageTheater()
    {
        beaveragelist.add("coke");
        beaveragelist.add("chocky");
        beaveragelist.add("pisty");
    }

    private void rowTheater()
    {
        rowlist.add("Front");
        rowlist.add("Bolcony");
        rowlist.add("Back");
    }

    private void foodTheater()
    {
        foodlist.add("popcorn");
        foodlist.add("chocolate");
        foodlist.add("chicken Burger");
    }

    private void foodcomboTheater()
    {
        foodcomboList.add("Pop corn+french fries+coke");
        foodcomboList.add("Burger+french fries+coke");
        foodcomboList.add("Pizza+french fries+coke");
    }

    private void employeelist1()
    {
        Employee employee = new Employee();
        employee.setId(1);
        employee.setName("promo");
        employee.setAge(21);
        employee.setSalery(1000.00);
        employee.setDesignation("public department");
        employeelist.add(employee);

        employee = new Employee();
        employee.setId(2);
        employee.setName("manoj");
        employee.setAge(22);
        employee.setSalery(50000.00);
        employee.setDesignation("Food customs");
        employeelist.add(employee);
    }

    private void decorTheater()
    {
        HomeDecor decor = new HomeDecor();
        decor.setName("Grandy");
        decorlist.add(decor);

        decor = new HomeDecor();
        decor.setName1("lighty");
        decorlist.add(decor);
    }

    private void carTheater()
    {
        Repeat repeat = new Repeat();
        repeat.setId(324232);
        repeat.setCarname("Audi");
        repeat.setColor("Black");
        repeatlist.add(repeat);
    }

    public void uploadEvent(FileUploadEvent event)
    {
        log.info("Selected File :" + event.getFile().getFileName());
    }

    public void hiding()
    {
        System.out.println("beverages" + beverages);
        boolean s = beverages.equalsIgnoreCase("coke") || beverages.equalsIgnoreCase("chocky");

        log.info("hide" + hide);
        log.info("beverages" + beverages);
        if (s)
        {
            hide = true;
        } else
        {
            hide = false;
        }

    }

    public void hiding1()
    {
        boolean s3 = StringUtils.equalsIgnoreCase(seat, "chair type");
        boolean s4 = StringUtils.equalsIgnoreCase(seat, "flat type");
        if (s3 || s4)
        {
            beverages = beaveragelist.get(0);
        } else
        {
            beverages = beaveragelist.get(2);
        }

    }

    public void resetbutton()
    {
        log.info("enter in reset");
        firstname = "";
        lastname = "";
        password = "";
        movie = movielist.get(0);
        date1 = null;
        display = "0";
        seat = null;
        beverages = beaveragelist.get(0);
        phone = "";
        rows = "";
        seatselect = 0;
        seattemp = 0;
        description = "";
        termndcond = false;
        foodlist.clear();
        foodcombo.clear();
        rupees = 0d;
        log.info(movie);
    }

    public void addButton()
    {
        pageHideRendered = true;
        buttonShowRendered = false;
    }

    public void hideButton()
    {
        pageHideRendered = false;
        buttonShowRendered = true;
    }

    /**
     * @return the first_name
     */
    public String getFirstname()
    {
        return firstname;

    }

    /**
     * @param firstname the first_name to set
     */
    public void setFirstname(String firstname)
    {
        this.firstname = firstname;
    }

    /**
     * @return the last_name
     */
    public String getLastname()
    {
        return lastname;
    }

    /**
     * @param lastname the last_name to set
     */
    public void setLastname(String lastname)
    {
        this.lastname = lastname;
    }

    /**
     * @return the password
     */
    public String getPassword()
    {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getRepassword()
    {
        return repassword;
    }

    public void setRepassword(String repassword)
    {
        this.repassword = repassword;
    }

    /**
     * @return the movie
     */
    public String getMovie()
    {
        return movie;
    }

    /**
     * @param movie the movie to set
     */
    public void setMovie(String movie)
    {
        this.movie = movie;
    }

    /**
     * @return the movie_list
     */
    public List<String> getMovielist()
    {
        return movielist;
    }

    /**
     * @param movie_list the movie_list to set
     */
    public void setMovielist(List<String> movielist)
    {
        this.movielist = movielist;
    }

    /**
     * @return the date1
     */
    public Date getDate1()
    {
        return date1;
    }

    /**
     * @param date1 the date1 to set
     */
    public void setDate1(Date date1)
    {
        this.date1 = date1;
    }

    /**
     * @return the display
     */
    public String getDisplay()
    {
        return display;
    }

    /**
     * @param display the display to set
     */
    public void setDisplay(String display)
    {
        this.display = display;
    }

    /**
     * @return the seat
     */
    public String getSeat()
    {
        return seat;
    }

    /**
     * @param seat the seat to set
     */
    public void setSeat(String seat)
    {
        this.seat = seat;
    }

    /**
     * @return the seat_list
     */
    public List<String> getSeatlist()
    {
        return seatlist;
    }

    /**
     * @param seat_list the seat_list to set
     */
    public void setSeatlist(List<String> seatlist)
    {
        this.seatlist = seatlist;
    }

    /**
     * @return the beverages
     */
    public String getBeverages()
    {
        return beverages;
    }

    /**
     * @param beverages the beverages to set
     */
    public void setBeverages(String beverages)
    {
        this.beverages = beverages;
    }

    /**
     * @return the beaverage_list
     */
    public List<String> getBeaveragelist()
    {
        return beaveragelist;
    }

    /**
     * @param beaveragelist the beaverage_list to set
     */
    public void setBeaveragelist(List<String> beaveragelist)
    {
        this.beaveragelist = beaveragelist;
    }

    /**
     * @return the phone
     */
    public String getPhone()
    {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    /**
     * @return the rows
     */
    public String getRows()
    {
        return rows;
    }

    /**
     * @param rows the rows to set
     */
    public void setRows(String rows)
    {
        this.rows = rows;
    }

    /**
     * @return the row_list
     */
    public List<String> getRowlist()
    {
        return rowlist;
    }

    /**
     * @param row_list the row_list to set
     */
    public void setRowlist(List<String> rowlist)
    {
        this.rowlist = rowlist;
    }

    /**
     * @return the seat_select
     */
    public int getSeatselect()
    {
        return seatselect;
    }

    /**
     * @param seat_select the seat_select to set
     */
    public void setSeatselect(int seatselect)
    {
        this.seatselect = seatselect;
    }

    /**
     * @return the seat_temp
     */
    public int getSeattemp()
    {
        return seattemp;
    }

    /**
     * @param seat_temp the seat_temp to set
     */
    public void setSeattemp(int seattemp)
    {
        this.seattemp = seattemp;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return the termndcond
     */
    public boolean isTermndcond()
    {
        return termndcond;
    }

    /**
     * @param termndcond the termndcond to set
     */
    public void setTermndcond(boolean termndcond)
    {
        this.termndcond = termndcond;
    }

    /**
     * @return the headset
     */
    public boolean isHeadset()
    {
        return headset;
    }

    /**
     * @param headset the headset to set
     */
    public void setHeadset(boolean headset)
    {
        this.headset = headset;
    }

    /**
     * @return the food
     */
    public List<String> getFood()
    {
        return food;
    }

    /**
     * @param food the food to set
     */
    public void setFood(List<String> food)
    {
        this.food = food;
    }

    /**
     * @return the food_list
     */
    public List<String> getFoodlist()
    {
        return foodlist;
    }

    /**
     * @param food_list the food_list to set
     */
    public void setFoodlist(List<String> foodlist)
    {
        this.foodlist = foodlist;
    }

    /**
     * @return the food_combo
     */
    public List<String> getFoodcombo()
    {
        return foodcombo;
    }

    /**
     * @param food_combo the food_combo to set
     */
    public void setFoodcombo(List<String> foodcombo)
    {
        this.foodcombo = foodcombo;
    }

    /**
     * @return the foodcombo_list
     */
    public List<String> getFoodcomboList()
    {
        return foodcomboList;
    }

    /**
     * @param foodcombolist the foodcombolist to set
     */
    public void setFoodcomboList(List<String> foodcomboList)
    {
        this.foodcomboList = foodcomboList;
    }

    public Double getRupees()
    {
        return rupees;
    }

    /**
     * @param rupees the rupees to set
     */
    public void setRupees(Double rupees)
    {
        this.rupees = rupees;
    }

    /**
     * @return the employee_list
     */
    public List<Employee> getEmployeelist()
    {
        return employeelist;
    }

    /**
     * @param employee_list the employee_list to set
     */
    public void setEmployeelist(List<Employee> employeelist)
    {
        this.employeelist = employeelist;
    }

//    /**
//     * @return the decor_list
//     */
//    public List<HomeDecor> getDecor_list()
//    {
//        return decor_list;
//    }
//
//    /**
//     * @param decor_list the decor_list to set
//     */
//    public void setDecor_list(List<HomeDecor> decor_list)
//    {
//        this.decor_list = decor_list;
//    }
    /**
     * @return the repeat_list
     */
    public List<Repeat> getRepeatlist()
    {
        return repeatlist;
    }

    /**
     * @param repeat_list the repeat_list to set
     */
    public void setRepeatlist(List<Repeat> repeatlist)
    {
        this.repeatlist = repeatlist;
    }

    public List<HomeDecor> getDecorlist()
    {
        return decorlist;
    }

    public void setDecorlist(List<HomeDecor> decorlist)
    {
        this.decorlist = decorlist;
    }
    private boolean hide;

    public boolean isHide()
    {
        return hide;
    }

    public void setHide(boolean hide)
    {
        this.hide = hide;
    }

    public Logger getLog()
    {
        return log;
    }

    public void setLog(Logger log)
    {
        this.log = log;
    }

    public String getFnameerror()
    {
        return Fnameerror;
    }

    public void setFnameerror(String Fnameerror)
    {
        this.Fnameerror = Fnameerror;
    }

    public String getLnameerror()
    {
        return lnameerror;
    }

    public void setLnameerror(String lnameerror)
    {
        this.lnameerror = lnameerror;
    }

    public String getPassworderror()
    {
        return passworderror;
    }

    public void setPassworderror(String passworderror)
    {
        this.passworderror = passworderror;
    }

    public String getRepassworderror()
    {
        return repassworderror;
    }

    public void setRepassworderror(String repassworderror)
    {
        this.repassworderror = repassworderror;
    }

    public String getBeverageerror()
    {
        return beverageerror;
    }

    public void setBeverageerror(String beverageerror)
    {
        this.beverageerror = beverageerror;
    }

    public Date getDate2()
    {
        return date2;
    }

    public void setDate2(Date date2)
    {
        this.date2 = date2;
    }

    /**
     * @return the pageShowRendered
     */
    public boolean isPageShowRendered()
    {
        return pageShowRendered;
    }

    /**
     * @param pageShowRendered the pageShowRendered to set
     */
    public void setPageShowRendered(boolean pageShowRendered)
    {
        this.pageShowRendered = pageShowRendered;
    }

    /**
     * @return the pageHideRendered
     */
    public boolean isPageHideRendered()
    {
        return pageHideRendered;
    }

    /**
     * @param pageHideRendered the pageHideRendered to set
     */
    public void setPageHideRendered(boolean pageHideRendered)
    {
        this.pageHideRendered = pageHideRendered;
    }

    /**
     * @return the buttonShowRendered
     */
    public boolean isButtonShowRendered()
    {
        return buttonShowRendered;
    }

    /**
     * @param buttonShowRendered the buttonShowRendered to set
     */
    public void setButtonShowRendered(boolean buttonShowRendered)
    {
        this.buttonShowRendered = buttonShowRendered;
    }

}
