/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.util.Date;

/**
 *
 * @author promoth
 */
public class TableBean
{
    
    private String firstName;
    private String lastName;
    private String organization;
    private String region;
    private String branch;
    private String department;
    private String designation;
    
    

    
    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    /**
     * @return the organization
     */
    public String getOrganization()
    {
        return organization;
    }

    /**
     * @param organization the organization to set
     */
    public void setOrganization(String organization)
    {
        this.organization = organization;
    }

    /**
     * @return the region
     */
    public String getRegion()
    {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(String region)
    {
        this.region = region;
    }

    /**
     * @return the branch
     */
    public String getBranch()
    {
        return branch;
    }

    /**
     * @param branch the branch to set
     */
    public void setBranch(String branch)
    {
        this.branch = branch;
    }

    /**
     * @return the department
     */
    public String getDepartment()
    {
        return department;
    }

    /**
     * @param department the department to set
     */
    public void setDepartment(String department)
    {
        this.department = department;
    }

    /**
     * @return the designation
     */
    public String getDesignation()
    {
        return designation;
    }

    /**
     * @param designation the designation to set
     */
    public void setDesignation(String designation)
    {
        this.designation = designation;
    }

    
}
