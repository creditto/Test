/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.primefaces.PrimeFaces;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 *
 * @author promoth
 */
@Named("UserDetail")
@SessionScoped
public class UserDetail implements Serializable
{

    private String userId;
    private String firstName;
    private String lastName;
    private String password;
    private String rePassword;
    private String gender;
    private String organization;
    private String region;
    private String branch;
    private String department;
    private String designation;
    private String emailID;
    private String address;
    //
    private String successMessage;
    private String failedMessage;
    private String fileUpload;
    private String userIdError;
    private String firstNameError;
    private String lastNameError;
    private String passwordError;
    private String rePasswordError;
    private String referenceIdError;
    private String emailError;
    private String dateOfBirthError;
    private String addressError;
    private String docxError;
    //
    private String experienceError;
    private String phoneNoError;
    private String userIdSearch;
    private String regionInputSearch;
    private String firsNameSearch;
    private String lastNameSearch;
    private String organizationInput;
    private String branchInputSearch;
    private String departmentInputSearch;
    private String designationInputSearch;
    private String UserIdSearchError;
    private String firstNameSearchError;
    private String lastNameSearchError;

    private List<String> genderList = null;
    private List<String> orgList = null;
    private List<String> regionList = null;
    private List<String> branchList = null;
    private List<String> departmentList = null;
    private List<String> designationList = null;
    private List<String> experienceResult = null;
    private List<String> experienceList = null;
    private List<String> searchResult = null;
    private List<String> searchOrganizationSearch = null;
    private List<String> searchRegionList = null;
    private List<String> searchBranchList = null;
    private List<String> searchDepartmentList = null;
    private List<String> searchDesignationList = null;
    //
    private Date dob2;
    private Date dateOfBirth;
    //
    private boolean userIdRender;
    private boolean userIdRenderSelect;
    private boolean userIdSearch1;
    private boolean firstNameRender;
    private boolean firstNameSearch1;
    private boolean lastNameRender;
    private boolean lastNameSearch1;
    private boolean organizationRender;
    private boolean organizationInput1;
    private boolean roleRender;
    private boolean regionInputSearch1;
    private boolean accoumtStatusRender;
    private boolean branchInputSearch1;
    private boolean departmentRender;
    private boolean departmentInputSearch1;
    private boolean designationender;
    private boolean designationInputSearch1;
    private boolean componentsDisable;
    private boolean martialStaus;
    private boolean documentType;
    private boolean searchPanelRender;
    private boolean addPanelRender;
    private boolean childrenHideRender;
    private boolean regionAjax;
    private boolean messageInSave;
    //
    private StreamedContent file;
    //
    private int datatableIndex;
    private int datatableIndex1;
    private Integer referenceId;
    private Integer numberOfChildren;
    private Integer phoneNo;
    //
    private List<TableBean> tableBeanList = null;
    //
    private List<AccountBean> accountBeanList = null;
    //
    private final XSSFCellStyle commonTableHeader = null;
    private final String newExcel = "/home/promoth/Desktop/ResumeList.xlsx";
    //
    private Double totalAmount;
    //
    private final Logger log = Logger.getLogger(UserDetail.class.getSimpleName());

    /**
     * Constructor
     */
    public UserDetail()
    {
        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/PmTraining/web/config/log4j.properties");
    }

    /*
       Initial page load
     */
    public void pageLoad()
    {
        log.info("pageLoad ******************************");
        populateGender();
        populateOrganizaitonList();
        organization = orgList.get(0);
        populateRegionList();
        region = regionList.get(0);
        selectBranch();
        branch = branchList.get(0);
        selectDepartment();
        department = departmentList.get(0);
        selectDesignation();
        designation = designationList.get(0);
        selectExperience();

        searchPanelRender = true;
        addPanelRender = false;
        childrenHideRender = true;
        gender = "male";

        regionAjax = false;

        userIdError = null;
        firstNameError = null;
        lastNameError = null;
        passwordError = null;
        rePasswordError = null;
        referenceIdError = null;
        emailError = null;
        dateOfBirthError = null;
        addressError = null;
        docxError = null;
        experienceError = null;
        phoneNoError = null;

        userIdRender = false;
        organizationRender = false;
        firstNameRender = false;
        departmentRender = false;
        designationender = false;
        lastNameRender = false;
        roleRender = false;
        accoumtStatusRender = false;

        userId = "";
        firstName = "";
        lastName = "";
        password = "";
        rePassword = "";
        referenceId = null;
        dateOfBirth = null;
        numberOfChildren = null;
        emailID = "";
        phoneNo = null;
        documentType = false;
        fileUpload = "";

        address = "";

        dob2 = new Date();

        if (CollectionUtils.isNotEmpty(searchResult))
        {
            searchResult.clear();
        }

        orgSearch();
        regSearch();
        branchSearch();
        departmentSearch();
        designationSearch();

        UserIdSearchError = null;
        firstNameSearchError = null;
        lastNameSearchError = null;

        userIdSearch1 = false;
        firstNameSearch1 = false;
        lastNameSearch1 = false;
        organizationInput1 = false;
        regionInputSearch1 = false;
        branchInputSearch1 = false;
        departmentInputSearch1 = false;
        setDesignationInputSearch1(false);

        list();

        addList();

    }

    /**
     * Save button action
     */
    public void save()
    {
        successMessage = null;
        failedMessage = null;

        log.info("save");
        log.info("User Id:" + userId);
        log.info("First Name:" + firstName);
        log.info("Last Name" + lastName);
        log.info("Password" + password);
        log.info("Re-password" + rePassword);
        log.info("Reference-ID" + referenceId);
        log.info("Date of Birth" + dateOfBirth);
        log.info("Gender" + gender);
        log.info("Martial Status" + martialStaus);
        log.info("Number of Children" + numberOfChildren);
        log.info("Organizaiton" + organization);
        log.info("Region" + region);
        log.info("Branch" + branch);
        log.info("Department" + department);
        log.info("Designation" + designation);
        log.info("Email ID" + emailID);
        log.info("Phone No" + phoneNo);
        log.info("Document Type" + documentType);
        log.info("Experience List" + experienceResult);
        log.info("Address" + address);

        userIdError = null;
        firstNameError = null;
        lastNameError = null;
        passwordError = null;
        rePasswordError = null;
        referenceIdError = null;
        emailError = null;
        dateOfBirthError = null;
        addressError = null;
        docxError = null;
        experienceError = null;
        phoneNoError = null;

        log.info(userId);

        log.info("Before if" + successMessage);

        userId = StringUtils.trim(userId);
        firstName = StringUtils.trim(firstName);
        lastName = StringUtils.trim(lastName);
        password = StringUtils.trim(password);
        rePassword = StringUtils.trim(rePassword);
        emailID = StringUtils.trim(emailID);
        address = StringUtils.trim(address);

        if (StringUtils.isEmpty(userId))
        {
            userIdError = "User Id should not empty";
        }
        else if (!StringUtils.isAlphanumeric(userId))
        {
            userIdError = "User Id should not other than Alphabets and Numbers";
        }
        else if (StringUtils.length(userId) <= 5)
        {
            userIdError = "User Id must contain atleast 5";
        }
        else if (StringUtils.length(userId) >= 15)
        {
            userIdError = "User Id must contain less than 15";
        }
        log.info("inside loop" + userId);
        log.info("inside loop" + userIdError);

        if (StringUtils.isEmpty(firstName))
        {
            firstNameError = "First Name should not empty";
        }
        else if (!StringUtils.isAlphaSpace(firstName))
        {
            firstNameError = "First Name should only Alphabets and Space";
        }
        else if (StringUtils.length(firstName) <= 5)
        {
            firstNameError = "First Name must contain atleast 5";
        }
        else if (StringUtils.length(firstName) >= 25)
        {
            firstNameError = "First Name must contain less than 25";
        }

        if (StringUtils.isEmpty(lastName))
        {
            lastNameError = "Last Name should not empty";
        }
        else if (!StringUtils.isAlphaSpace(lastName))
        {
            lastNameError = "Last Name should only Alphabets and Space";
        }
        else if (StringUtils.length(lastName) <= 5)
        {
            lastNameError = "Last Name must contain atleast 5";
        }
        else if (StringUtils.length(lastName) >= 25)
        {
            lastNameError = "Last Name must contain less than 25";
        }

        if (StringUtils.isEmpty(password))
        {
            passwordError = "Password should not empty";
        }
        else if (!StringUtils.isAlphanumeric(password))
        {
            passwordError = "Password should only Alphabets and Numbers";
        }
        else if (StringUtils.length(password) <= 6)
        {
            passwordError = "Password Minimum 6 letters";
        }
        else if (StringUtils.length(password) >= 10)
        {
            passwordError = "Password Maximum 10letters allowed";
        }

        if (StringUtils.isEmpty(rePassword))
        {
            rePasswordError = "Re-Password should not empty";
        }
        else if (!StringUtils.isAlphanumeric(rePassword))
        {
            rePasswordError = "Re-password  should only Alphabets and Numbers";
        }
        else if (StringUtils.length(rePassword) <= 6)
        {
            rePasswordError = "Re-password Minimum 6 letters";
        }
        else if (StringUtils.length(rePassword) >= 10)
        {
            rePasswordError = "Re-password Maximum 10letters allowed";
        }
        else if (!StringUtils.equalsIgnoreCase(password, rePassword))
        {
            rePasswordError = "Password Mis-Match";
        }

        if (referenceId == null)
        {
            referenceIdError = "ReferenceId should not empty";
        }

        log.info("log dob" + dateOfBirth);

        if (dateOfBirth == null)
        {
            dateOfBirthError = "DOB should not Empty";
        }

        String emailRegax = "^(.+)@(.+)$";
        if (StringUtils.isEmpty(emailID))
        {
            emailError = "Email should not Empty";
        }
        else if (!emailID.matches(emailRegax))
        {
            emailError = "Email address is invalid";
        }

        if (phoneNo == null)
        {
            phoneNoError = "Phone no should not Empty";
        }

        if (StringUtils.isEmpty(address))
        {
            addressError = "Address should not empty";
        }

        log.info("result" + experienceResult);
        log.info("list" + experienceList);
        if (experienceResult.isEmpty())
        {
            log.info("3333333333" + experienceResult);
            experienceError = "should select 1";
        }
        if (experienceResult.contains("Fresher") && experienceResult.contains("Greater than 1yr"))
        {
            experienceError = "should select any 1";
        }
        if (experienceResult.contains("Fresher") && experienceResult.contains("Greater than 5yr"))
        {
            experienceError = "should select any 1";
        }
        if (experienceResult.contains("Greater than 5yr") && experienceResult.contains("Greater than 1yr"))
        {
            experienceError = "should select any 1";
        }
        if (experienceResult.contains("Fresher")
                && experienceResult.contains("Greater than 5yr")
                && experienceResult.contains("Greater than 1yr"))
        {
            experienceError = "should select any 1";
        }

        if (!StringUtils.isEmpty(fileUpload))
        {
            docxError = "Select Photo or Document";
        }

        log.info("after if" + successMessage);
        componentsDisable = false;

        if (StringUtils.isEmpty(userIdError) && StringUtils.isEmpty(firstNameError)
                && StringUtils.isEmpty(passwordError)
                && StringUtils.isEmpty(rePasswordError) && StringUtils.isEmpty((referenceIdError))
                && StringUtils.isEmpty(dateOfBirthError) && StringUtils.isEmpty(emailError)
                && StringUtils.isEmpty(docxError) && CollectionUtils.isEmpty(experienceResult)
                && StringUtils.isEmpty(addressError))
        {
            log.info("Inside If Condition");
            successMessage = "Success";
            componentsDisable = true;
        }
        else
        {
            failedMessage = "Invalid Input";
        }

        PrimeFaces.current().executeScript("openNotification();");

        accountBeanList.stream().map(bean3 ->
        {
            log.info("Size of add list" + accountBeanList.size());
            return bean3;
        }).map(bean3 ->
        {
            log.info("Save button insde account no" + bean3.getAmount());
            return bean3;
        }).forEachOrdered(bean3 ->
        {
            if (bean3.getAmount() == null)
            {
                bean3.setAmountError("Table should not empty");
            }
            else
            {
                bean3.setAmountError(null);
            }
        });

    }

    /**
     * command link edit button action
     */
    public void editListenerAction()
    {

        searchPanelRender = false;
        addPanelRender = true;

        userIdError = null;
        firstNameError = null;
        lastNameError = null;
        passwordError = null;
        rePasswordError = null;
        referenceIdError = null;
        dateOfBirthError = null;
        emailError = null;
        phoneNoError = null;
        docxError = null;
        experienceError = null;
        addressError = null;

        userId = "";
        firstName = "";
        lastName = "";
        password = "";
        rePassword = "";
        referenceId = null;
        dateOfBirth = null;
        gender = "Male";
        martialStaus = false;
        childrenHideRender = true;
        numberOfChildren = null;
        organization = "";
        populateRegionList();
        branch = "";
        department = "";
        designation = "";
        emailID = "";
        phoneNo = null;
        documentType = false;
        fileUpload = "";
        if (CollectionUtils.isNotEmpty(experienceResult))
        {
            experienceResult.clear();
        }
        address = "";

        componentsDisable = false;

        log.info("Inside actionlisterner :" + datatableIndex);

        log.info("insidelistenerAxtion1111111111111" + searchPanelRender);
        log.info("insidelistenerAxtion2222222222222" + addPanelRender);
    }

    /**
     * list populate in bootstrap table
     */
    public void list()
    {
        tableBeanList = new ArrayList<>();

        TableBean bean = new TableBean();
        bean.setFirstName("Promoth");
        bean.setLastName("Kumar");
        bean.setOrganization("ICICI");
        bean.setRegion("Coimbatore");
        bean.setBranch("Thudiyulur");
        bean.setDepartment("IT");
        bean.setDesignation("Developer");
        tableBeanList.add(bean);

        bean = new TableBean();
        bean.setFirstName("Joel");
        bean.setLastName("saju");
        bean.setOrganization("Axis");
        bean.setRegion("Tirupur");
        bean.setBranch("New Bus-Stand");
        bean.setDepartment("HR");
        bean.setDesignation("Juniour Developer");
        tableBeanList.add(bean);

        bean = new TableBean();
        bean.setFirstName("Eva");
        bean.setLastName("flora");
        bean.setOrganization("Canara");
        bean.setRegion("Ooty");
        bean.setBranch("Baraligad");
        bean.setDepartment("Testing");
        bean.setDesignation("Seniour Development");
        tableBeanList.add(bean);

        bean = new TableBean();
        bean.setFirstName("Sherin");
        bean.setLastName("roy");
        bean.setOrganization("Indian");
        bean.setRegion("PN Palayam");
        bean.setBranch("H Town");
        bean.setDepartment("Voice output");
        bean.setDesignation("Developer");
        tableBeanList.add(bean);

    }

    /**
     * Inside add table
     */
    public void addList()
    {
        accountBeanList = new ArrayList<>();
        AccountBean bean2 = new AccountBean();
        accountBeanList.add(bean2);

    }

    /**
     * Inside add button populate
     */
    public void addButton()
    {

        AccountBean bean2 = new AccountBean();
        accountBeanList.add(bean2);

    }

    /**
     * To delete inside bootstrap table
     */
    public void deleteRow1()
    {
        totalAmount = 0.0;
        log.info("########" + accountBeanList.size());
        accountBeanList.remove(datatableIndex1);
        log.info("^^^^^^^" + accountBeanList.size());

        for (AccountBean bean3 : accountBeanList)
        {
            totalAmount += bean3.getAmount();
        }
        log.info("total amount deduction:" + totalAmount);
    }

    /**
     * Add or edit button action
     */
    public void addorEdit()
    {
        log.info("Enter into add or edit button action");
        searchPanelRender = false;
        addPanelRender = true;

        userId = "promo";
        userIdError = null;
        firstNameError = null;
        lastNameError = null;
        passwordError = null;
        rePasswordError = null;
        referenceIdError = null;
        dateOfBirthError = null;
        emailError = null;
        phoneNoError = null;
        docxError = null;
        experienceError = null;
        addressError = null;

        userId = "";
        firstName = "";
        lastName = "";
        password = "";
        rePassword = "";
        referenceId = null;
        dateOfBirth = null;
        gender = "Female";
        martialStaus = false;
        childrenHideRender = true;
        numberOfChildren = null;
        organization = "";
        populateRegionList();
        branch = "";
        department = "";
        designation = "";
        emailID = "";
        phoneNo = null;
        documentType = false;
        fileUpload = "";
        if (CollectionUtils.isNotEmpty(experienceResult))
        {
            experienceResult.clear();
        }
        address = "";

        componentsDisable = false;

        accountBeanList.clear();
        totalAmount = null;
    }

    /**
     * Cancel button
     */
    public void hideButton()
    {
        searchPanelRender = true;
        addPanelRender = false;
        componentsDisable = false;
    }

    /**
     * Reset button
     */
    public void resetButton()
    {
        userId = "";
        firstName = "";
        lastName = "";
        password = "";

        rePassword = "";
        referenceId = null;
        dateOfBirth = null;
        gender = "Male";
        martialStaus = false;
        childrenHideRender = true;
        numberOfChildren = null;
        organization = "ICICI";
        populateRegionList();
        branch = "Thduiyulur";
        department = "IT";
        designation = "Developers";
        emailID = "";
        phoneNo = null;
        documentType = false;

        if (CollectionUtils.isNotEmpty(experienceResult))
        {
            experienceResult.clear();
        }
        address = "";

        userIdError = null;
        firstNameError = null;
        lastNameError = null;
        passwordError = null;
        rePasswordError = null;
        referenceIdError = null;
        dateOfBirthError = null;
        emailError = null;
        firstNameError = null;
        phoneNoError = null;
        addressError = null;
        experienceError = null;
        firstNameError = null;
        docxError = null;

        componentsDisable = false;

        accountBeanList.clear();
        totalAmount = null;

    }

    /**
     * populate Gender
     */
    private void populateGender()
    {
        genderList = new ArrayList<>();
        genderList.add("Male");
        genderList.add("Female");

    }

    /**
     * populate organization
     */
    private void populateOrganizaitonList()
    {
        orgList = new ArrayList<>();
        orgList.add("ICICI");
        orgList.add("SBI");
        orgList.add("HDFC");
    }

    /**
     * populate RegionList
     */
    private void populateRegionList()
    {
        regionList = new ArrayList<>();
        regionList.add("Coimbatore");
        regionList.add("Chennai");
        regionList.add("Kannyakumarai");
    }

    /**
     * populate Branch
     *
     */
    private void selectBranch()
    {
        branchList = new ArrayList<>();
        branchList.add("Thduiyulur");
        branchList.add("peenang");
        branchList.add("Mannarkad");
    }

    /**
     * populate Department
     */
    private void selectDepartment()
    {
        departmentList = new ArrayList<>();
        departmentList.add("IT");
        departmentList.add("Testing");
        departmentList.add("HR");
    }

    /**
     * populate Designation
     */
    private void selectDesignation()
    {
        designationList = new ArrayList<>();
        designationList.add("Developers");
        designationList.add("Junior Devops");
        designationList.add("Seniour Devops");
    }

    /**
     * populate Experience
     */
    private void selectExperience()
    {
        experienceList = new ArrayList<>();
        experienceList.add("Fresher");
        experienceList.add("Greater than 1yr");
        experienceList.add("Greater than 5yr");
    }

    /**
     * populate OrganizationSearch List
     */
    private void orgSearch()
    {
        searchOrganizationSearch = new ArrayList<>();
        searchOrganizationSearch.add("May Bank");
        searchOrganizationSearch.add("Affin Bank");
        searchOrganizationSearch.add("RHB Bank");
    }

    /**
     * populate regionSearch list
     */
    private void regSearch()
    {
        searchRegionList = new ArrayList<>();
        searchRegionList.add("PutraJaya");
        searchRegionList.add("Selongar");
        searchRegionList.add("Penang");
    }

    /**
     * populate branch search list
     */
    private void branchSearch()
    {
        searchBranchList = new ArrayList<>();
        searchBranchList.add("CyberJaya");
        searchBranchList.add("Dhoa");
        searchBranchList.add("Masjid");
    }

    /**
     * populate department list
     */
    private void departmentSearch()
    {
        searchDepartmentList = new ArrayList<>();
        searchDepartmentList.add("IT");
        searchDepartmentList.add("Testing");
        searchDepartmentList.add("HR");
    }

    /**
     * populate designation search list
     */
    private void designationSearch()
    {
        searchDesignationList = new ArrayList<>();
        searchDesignationList.add("Developer");
        searchDesignationList.add("Juniour Developer");
        searchDesignationList.add("Seniour Developer");
    }

    /**
     * Hiding No of children function
     */
    public void hideChildren()
    {
        childrenHideRender = !martialStaus;
    }

    /**
     * File upload event
     *
     * @param event
     */
    public void uploadEvent(FileUploadEvent event)
    {
        log.info("Selected File :" + event.getFile().getFileName());
        fileUpload = event.getFile().getFileName();
    }

    /**
     * Organization action
     */
    public void organizationAction()
    {
        if (CollectionUtils.isNotEmpty(regionList))
        {
            regionList.clear();
        }
        if (StringUtils.equalsIgnoreCase(organization, "sbi"))
        {
            regionList.add("Madurai");
            regionList.add("Tiruchy");
            regionList.add("Tirunelvei");
        }
        else if (StringUtils.equalsIgnoreCase(organization, "hdfc"))
        {
            regionList.add("Rameswaram");
            regionList.add("Pollachi");
            regionList.add("Karur");
        }
        else if (StringUtils.equalsIgnoreCase(organization, "icici"))
        {
            regionList.add("Coimbatore");
            regionList.add("Chennai");
            regionList.add("Kannyakumari");
        }

    }

    /**
     * search button action listener
     */
    public void searchListener()
    {
        if (userIdSearch1)
        {
            userIdRender = true;
            userIdSearch = "";
        }
        else
        {
            userIdRender = false;
        }

        if (firstNameSearch1)
        {
            firstNameRender = true;
            firsNameSearch = "";

        }
        else
        {
            firstNameRender = false;
        }

        if (lastNameSearch1)
        {
            lastNameRender = true;
            lastNameSearch = "";
        }
        else
        {
            lastNameRender = false;
        }

        organizationRender = organizationInput1;

        roleRender = regionInputSearch1;

        accoumtStatusRender = branchInputSearch1;

        designationender = branchInputSearch1;
        departmentRender = branchInputSearch1;
        //designationender = departmentInputSearch1;

        // designationender = designationInputSearch1;
    }

    /**
     * File download Excel
     *
     * @throws FileNotFoundException
     * @throws IOException
     */
    public void fileDownloadView() throws FileNotFoundException, IOException
    {

        tableBeanList = new ArrayList<>();

        TableBean bean = new TableBean();
        bean.setFirstName("Promoth");
        bean.setLastName("kumar");
        bean.setOrganization("Axis");
        bean.setRegion("Ooty");
        bean.setBranch("kalhatty");
        bean.setDepartment("IT");
        bean.setDesignation("Developer");
        tableBeanList.add(bean);

        bean = new TableBean();
        bean.setFirstName("shilpa");
        bean.setLastName("mon");
        bean.setOrganization("Axis");
        bean.setRegion("Kerala");
        bean.setBranch("Mannarkad");
        bean.setDepartment("IT");
        bean.setDesignation("Developer");
        tableBeanList.add(bean);

        log.info("Inside file down in cell" + tableBeanList.size());

        XSSFWorkbook workbook = new XSSFWorkbook();

        XSSFSheet sheet = workbook.createSheet("characters");

        int rowIndex = 0;

        int cellIndex1 = 0;
        XSSFRow rowhead = sheet.createRow((short) rowIndex);

        Style(workbook);

        sheet.setColumnWidth(0, 3000);
        sheet.setColumnWidth(1, 3000);
        sheet.setColumnWidth(2, 4000);
        sheet.setColumnWidth(3, 4000);
        sheet.setColumnWidth(4, 4000);
        sheet.setColumnWidth(5, 4000);
        sheet.setColumnWidth(6, 4000);

        sheet.setDefaultRowHeight((short) 300);
        rowhead.setHeight((short) 500);

        XSSFCell tableHeaderCell1 = rowhead.createCell(0);
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("First Name"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Last Name"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Organization"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Region"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Branch"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Department"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Designation"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        log.info("%%%%%%%%%%%%%%%%%%%%%" + rowIndex);
        rowIndex++;
        for (TableBean tableBean : tableBeanList)
        {
            log.info("---------" + tableBeanList.size());

            log.info("^^^^^^^^^^^^^^^^" + rowIndex);

            XSSFRow row = sheet.createRow(rowIndex);

            int cellIndex = 0;
            XSSFCell cell = row.createCell(cellIndex++);

            cell.setCellValue(tableBean.getFirstName());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getLastName());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getOrganization());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getRegion());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getBranch());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getDepartment());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getDesignation());
            cell = row.createCell(cellIndex++);

            rowIndex++;
        }
        try (FileOutputStream fileOut = new FileOutputStream(newExcel))
        {
            workbook.write(fileOut);
        }

    }

    public void Style(XSSFWorkbook workBook)
    {
        XSSFCellStyle commonTableHeaders = null;
        XSSFFont tableHeaderFont = (XSSFFont) workBook.createFont();
        tableHeaderFont.setFontHeightInPoints((short) 11);
        tableHeaderFont.setFontName("Calibri");
        tableHeaderFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        tableHeaderFont.setColor(IndexedColors.BLACK.getIndex());

        commonTableHeaders = (XSSFCellStyle) workBook.createCellStyle();
        commonTableHeaders.setAlignment(XSSFCellStyle.ALIGN_CENTER);
        commonTableHeaders.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        commonTableHeaders.setFillForegroundColor(new XSSFColor(new java.awt.Color(181, 223, 217)));
        commonTableHeaders.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
        commonTableHeaders.setBorderRight(XSSFCellStyle.BORDER_THIN);
        commonTableHeaders.setRightBorderColor(IndexedColors.BLACK.getIndex());
        commonTableHeaders.setBorderLeft(XSSFCellStyle.BORDER_THIN);
        commonTableHeaders.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        commonTableHeaders.setBorderTop(XSSFCellStyle.BORDER_THIN);
        commonTableHeaders.setTopBorderColor(IndexedColors.BLACK.getIndex());
        commonTableHeaders.setBorderBottom(XSSFCellStyle.BORDER_THIN);
        commonTableHeaders.setTopBorderColor(IndexedColors.BLACK.getIndex());
        commonTableHeaders.setFont(tableHeaderFont);
        commonTableHeaders.setWrapText(true);
        commonTableHeaders.setHidden(true);

        XSSFFont ordinryFont = workBook.createFont();
        ordinryFont.setFontHeightInPoints((short) 11);
        ordinryFont.setFontName("Calibri");
        ordinryFont.setColor(IndexedColors.BLACK.getIndex());

        log.info("enter into FileDownloadView");
        try
        {
            InputStream inputStream = new FileInputStream("/home/promoth/Desktop/ResumeList.xlsx");
            file = new DefaultStreamedContent(inputStream, "application/xlsx", "ResumeList.xlsx");
            log.info("inside file download view" + file);
        }
        catch (FileNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(UserDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Search button error
     *
     */
    public void searchError()
    {
        UserIdSearchError = null;
        firstNameSearchError = null;
        lastNameSearchError = null;

        if (userIdRender)
        {
            if (StringUtils.isEmpty(userIdSearch))
            {
                log.info("!!!!!!!!" + userIdSearch);
                UserIdSearchError = "User Id should not Empty";
            }

        }

        if (firstNameRender)
        {
            if (StringUtils.isEmpty(firsNameSearch))
            {
                firstNameSearchError = "First Name should not empty";
            }
        }

        if (lastNameRender)
        {
            if (StringUtils.isEmpty(lastNameSearch))
            {
                lastNameSearchError = "Last Name should not empty";
            }
        }

    }

    /**
     * Bootstrap table deletion
     */
    public void deleteRow()
    {
        log.info("inside delte" + tableBeanList.size());

        tableBeanList.remove(datatableIndex);

        log.info("inside delte" + tableBeanList.size());

    }

    public void blurPrint()
    {
        totalAmount = 0.0;
        accountBeanList.forEach(bean3 ->
        {
            totalAmount += bean3.getAmount();
        });
        log.info("Total amount" + totalAmount);
    }
    

    /**
     * @return the userId
     */
    public String getUserId()
    {
        return userId;
    }

    /*
     * @param userId the userId to set
     */
    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    /**
     * @return the firstName
     */
    public String getFirstName()
    {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName()
    {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    /**
     * @return the password
     */
    public String getPassword()
    {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * @return the rePassword
     */
    public String getRePassword()
    {
        return rePassword;
    }

    /**
     * @param rePassword the rePassword to set
     */
    public void setRePassword(String rePassword)
    {
        this.rePassword = rePassword;
    }

    /**
     * @return the referenceId
     */
    public Integer getReferenceId()
    {
        return referenceId;
    }

    /**
     * @param referenceId the referenceId to set
     */
    public void setReferenceId(Integer referenceId)
    {
        this.referenceId = referenceId;
    }

    /**
     * @return the dateOfBirth
     */
    public Date getDateOfBirth()
    {
        return dateOfBirth;
    }

    /**
     * @param dateOfBirth the dateOfBirth to set
     */
    public void setDateOfBirth(Date dateOfBirth)
    {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * @return the gender
     */
    public String getGender()
    {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(String gender)
    {
        this.gender = gender;
    }

    /**
     * @return the martialStaus
     */
    public boolean isMartialStaus()
    {
        return martialStaus;
    }

    /**
     * @param martialStaus the martialStaus to set
     */
    public void setMartialStaus(boolean martialStaus)
    {
        this.martialStaus = martialStaus;
    }

    /**
     * @return the numberOfChildren
     */
    public Integer getNumberOfChildren()
    {
        return numberOfChildren;
    }

    /**
     * @param numberOfChildren the numberOfChildren to set
     */
    public void setNumberOfChildren(Integer numberOfChildren)
    {
        this.numberOfChildren = numberOfChildren;
    }

    /**
     * @return the organization
     */
    public String getOrganization()
    {
        return organization;
    }

    /**
     * @param organization the organization to set
     */
    public void setOrganization(String organization)
    {
        this.organization = organization;
    }

    /**
     * @return the orgList
     */
    public List<String> getOrgList()
    {
        return orgList;
    }

    /**
     * @param orgList the orgList to set
     */
    public void setOrgList(List<String> orgList)
    {
        this.orgList = orgList;
    }

    /**
     * @return the region
     */
    public String getRegion()
    {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(String region)
    {
        this.region = region;
    }

    /**
     * @return the regionList
     */
    public List<String> getRegionList()
    {
        return regionList;
    }

    /**
     * @param regionList the regionList to set
     */
    public void setRegionList(List<String> regionList)
    {
        this.regionList = regionList;
    }

    /**
     * @return the branch
     */
    public String getBranch()
    {
        return branch;
    }

    /**
     * @param branch the branch to set
     */
    public void setBranch(String branch)
    {
        this.branch = branch;
    }

    /**
     * @return the branchList
     */
    public List<String> getBranchList()
    {
        return branchList;
    }

    /**
     * @param branchList the branchList to set
     */
    public void setBranchList(List<String> branchList)
    {
        this.branchList = branchList;
    }

    /**
     * @return the department
     */
    public String getDepartment()
    {
        return department;
    }

    /**
     * @param department the department to set
     */
    public void setDepartment(String department)
    {
        this.department = department;
    }

    /**
     * @return the designation
     */
    public String getDesignation()
    {
        return designation;
    }

    /**
     * @param designation the designation to set
     */
    public void setDesignation(String designation)
    {
        this.designation = designation;
    }

    /**
     * @return the departmentList
     */
    public List<String> getDepartmentList()
    {
        return departmentList;
    }

    /**
     * @param departmentList the departmentList to set
     */
    public void setDepartmentList(List<String> departmentList)
    {
        this.departmentList = departmentList;
    }

    /**
     * @return the designationList
     */
    public List<String> getDesignationList()
    {
        return designationList;
    }

    /**
     * @param designationList the designationList to set
     */
    public void setDesignationList(List<String> designationList)
    {
        this.designationList = designationList;
    }

    /**
     * @return the emailID
     */
    public String getEmailID()
    {
        return emailID;
    }

    /**
     * @param emailID the emailID to set
     */
    public void setEmailID(String emailID)
    {
        this.emailID = emailID;
    }

    /**
     * @return the phoneNo
     */
    public Integer getPhoneNo()
    {
        return phoneNo;
    }

    /**
     * @param phoneNo the phoneNo to set
     */
    public void setPhoneNo(Integer phoneNo)
    {
        this.phoneNo = phoneNo;
    }

    /**
     * @return the documentType
     */
    public boolean isDocumentType()
    {
        return documentType;
    }

    /**
     * @param documentType the documentType to set
     */
    public void setDocumentType(boolean documentType)
    {
        this.documentType = documentType;
    }

    public List<String> getExperienceList()
    {
        return experienceList;
    }

    /**
     * @param experienceList the experienceList to set
     */
    public void setExperienceList(List<String> experienceList)
    {
        this.experienceList = experienceList;
    }

    /**
     * @return the experienceResult
     */
    public List<String> getExperienceResult()
    {
        return experienceResult;
    }

    /**
     * @param experienceResult the experienceResult to set
     */
    public void setExperienceResult(List<String> experienceResult)
    {
        this.experienceResult = experienceResult;
    }

    /**
     * @return the searchPanelRender
     */
    public boolean isSearchPanelRender()
    {
        return searchPanelRender;
    }

    /**
     * @param searchPanelRender the searchPanelRender to set
     */
    public void setSearchPanelRender(boolean searchPanelRender)
    {
        this.searchPanelRender = searchPanelRender;
    }

    /**
     * @return the addPanelRender
     */
    public boolean isAddPanelRender()
    {
        return addPanelRender;
    }

    /**
     * @param addPanelRender the addPanelRender to set
     */
    public void setAddPanelRender(boolean addPanelRender)
    {
        this.addPanelRender = addPanelRender;
    }

    /**
     * @return the address
     */
    public String getAddress()
    {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address)
    {
        this.address = address;
    }

    /**
     * @return the genderList
     */
    public List<String> getGenderList()
    {
        return genderList;
    }

    /**
     * @param genderList the genderList to set
     */
    public void setGenderList(List<String> genderList)
    {
        this.genderList = genderList;
    }

    /**
     * @return the childrenHideRender
     */
    public boolean isChildrenHideRender()
    {
        return childrenHideRender;
    }

    /**
     * @param childrenHideRender the childrenHideRender to set
     */
    public void setChildrenHideRender(boolean childrenHideRender)
    {
        this.childrenHideRender = childrenHideRender;
    }

    /**
     * @return the userIdError
     */
    public String getUserIdError()
    {
        return userIdError;
    }

    /**
     * @param userIdError the userIdError to set
     */
    public void setUserIdError(String userIdError)
    {
        this.userIdError = userIdError;
    }

    /**
     * @return the firstNameError
     */
    public String getFirstNameError()
    {
        return firstNameError;
    }

    /**
     * @param firstNameError the firstNameError to set
     */
    public void setFirstNameError(String firstNameError)
    {
        this.firstNameError = firstNameError;
    }

    /**
     * @return the lastNameError
     */
    public String getLastNameError()
    {
        return lastNameError;
    }

    /**
     * @param lastNameError the lastNameError to set
     */
    public void setLastNameError(String lastNameError)
    {
        this.lastNameError = lastNameError;
    }

    /**
     * @return the passwordError
     */
    public String getPasswordError()
    {
        return passwordError;
    }

    /**
     * @param passwordError the passwordError to set
     */
    public void setPasswordError(String passwordError)
    {
        this.passwordError = passwordError;
    }

    /**
     * @return the rePasswordError
     */
    public String getRePasswordError()
    {
        return rePasswordError;
    }

    /**
     * @param rePasswordError the rePasswordError to set
     */
    public void setRePasswordError(String rePasswordError)
    {
        this.rePasswordError = rePasswordError;
    }

    /**
     * @return the referenceIdError
     */
    public String getReferenceIdError()
    {
        return referenceIdError;
    }

    /**
     * @param referenceIdError the referenceIdError to set
     */
    public void setReferenceIdError(String referenceIdError)
    {
        this.referenceIdError = referenceIdError;
    }

    /**
     * @return the emailError
     */
    public String getEmailError()
    {
        return emailError;
    }

    /**
     * @param emailError the emailError to set
     */
    public void setEmailError(String emailError)
    {
        this.emailError = emailError;
    }

    /**
     * @return the dateOfBirthError
     */
    public String getDateOfBirthError()
    {
        return dateOfBirthError;
    }

    /**
     * @param dateOfBirthError the dateOfBirthError to set
     */
    public void setDateOfBirthError(String dateOfBirthError)
    {
        this.dateOfBirthError = dateOfBirthError;
    }

    /**
     * @return the addressError
     */
    public String getAddressError()
    {
        return addressError;
    }

    /**
     * @param addressError the addressError to set
     */
    public void setAddressError(String addressError)
    {
        this.addressError = addressError;
    }

    /**
     * @return the docxError
     */
    public String getDocxError()
    {
        return docxError;
    }

    /**
     * @param docxError the docxError to set
     */
    public void setDocxError(String docxError)
    {
        this.docxError = docxError;
    }

    /**
     * @return the fileUpload
     */
    public String getFileUpload()
    {
        return fileUpload;
    }

    /**
     * @param fileUpload the fileUpload to set
     */
    public void setFileUpload(String fileUpload)
    {
        this.fileUpload = fileUpload;
    }

    /**
     * @return the regionAjax
     */
    public boolean isRegionAjax()
    {
        return regionAjax;
    }

    /**
     * @param regionAjax the regionAjax to set
     */
    public void setRegionAjax(boolean regionAjax)
    {
        this.regionAjax = regionAjax;
    }

    /**
     * @return the successMessage
     */
    public String getSuccessMessage()
    {
        return successMessage;
    }

    /**
     * @param successMessage the successMessage to set
     */
    public void setSuccessMessage(String successMessage)
    {
        this.successMessage = successMessage;
    }

    /**
     * @return the failedMessage
     */
    public String getFailedMessage()
    {
        return failedMessage;
    }

    /**
     * @param failedMessage the failedMessage to set
     */
    public void setFailedMessage(String failedMessage)
    {
        this.failedMessage = failedMessage;
    }

    /**
     * @return the messageInSave
     */
    public boolean isMessageInSave()
    {
        return messageInSave;
    }

    /**
     * @param messageInSave the messageInSave to set
     */
    public void setMessageInSave(boolean messageInSave)
    {
        this.messageInSave = messageInSave;
    }

    /**
     * @return the searchResult
     */
    public List<String> getSearchResult()
    {
        return searchResult;
    }

    /**
     * @param searchResult the searchResult to set
     */
    public void setSearchResult(List<String> searchResult)
    {
        this.searchResult = searchResult;
    }

    /**
     * @return the userIdSearch
     */
    public String getUserIdSearch()
    {
        return userIdSearch;
    }

    /**
     * @param userIdSearch the userIdSearch to set
     */
    public void setUserIdSearch(String userIdSearch)
    {
        this.userIdSearch = userIdSearch;
    }

    /**
     * @return the userIdRender
     */
    public boolean isUserIdRender()
    {
        return userIdRender;
    }

    /**
     * @param userIdRender the userIdRender to set
     */
    public void setUserIdRender(boolean userIdRender)
    {
        this.userIdRender = userIdRender;
    }

    /**
     * @return the userIdRenderSelect
     */
    public boolean isUserIdRenderSelect()
    {
        return userIdRenderSelect;
    }

    /**
     * @param userIdRenderSelect the userIdRenderSelect to set
     */
    public void setUserIdRenderSelect(boolean userIdRenderSelect)
    {
        this.userIdRenderSelect = userIdRenderSelect;
    }

    /**
     * @return the organizationInput
     */
    public String getOrganizationInput()
    {
        return organizationInput;
    }

    /**
     * @param organizationInput the organizationInput to set
     */
    public void setOrganizationInput(String organizationInput)
    {
        this.organizationInput = organizationInput;
    }

    /**
     * @return the organizationRender
     */
    public boolean isOrganizationRender()
    {
        return organizationRender;
    }

    /**
     * @param organizationRender the organizationRender to set
     */
    public void setOrganizationRender(boolean organizationRender)
    {
        this.organizationRender = organizationRender;
    }

    /**
     * @return the regionInputSearch
     */
    public String getRegionInputSearch()
    {
        return regionInputSearch;
    }

    /**
     * @param regionInputSearch the regionInputSearch to set
     */
    public void setRegionInputSearch(String regionInputSearch)
    {
        this.regionInputSearch = regionInputSearch;
    }

    /**
     * @return the roleRender
     */
    public boolean isRoleRender()
    {
        return roleRender;
    }

    /**
     * @param roleRender the roleRender to set
     */
    public void setRoleRender(boolean roleRender)
    {
        this.roleRender = roleRender;
    }

    /**
     * @return the branchInputSearch
     */
    public String getBranchInputSearch()
    {
        return branchInputSearch;
    }

    /**
     * @param branchInputSearch the branchInputSearch to set
     */
    public void setBranchInputSearch(String branchInputSearch)
    {
        this.branchInputSearch = branchInputSearch;
    }

    /**
     * @return the accoumtStatusRender
     */
    public boolean isAccoumtStatusRender()
    {
        return accoumtStatusRender;
    }

    /**
     * @param accoumtStatusRender the accoumtStatusRender to set
     */
    public void setAccoumtStatusRender(boolean accoumtStatusRender)
    {
        this.accoumtStatusRender = accoumtStatusRender;
    }

    /**
     * @return the departmentInputSearch
     */
    public String getDepartmentInputSearch()
    {
        return departmentInputSearch;
    }

    /**
     * @param departmentInputSearch the departmentInputSearch to set
     */
    public void setDepartmentInputSearch(String departmentInputSearch)
    {
        this.departmentInputSearch = departmentInputSearch;
    }

    /**
     * @return the departmentRender
     */
    public boolean isDepartmentRender()
    {
        return departmentRender;
    }

    /**
     * @param departmentRender the departmentRender to set
     */
    public void setDepartmentRender(boolean departmentRender)
    {
        this.departmentRender = departmentRender;
    }

    /**
     * @return the designationInputSearch
     */
    public String getDesignationInputSearch()
    {
        return designationInputSearch;
    }

    /**
     * @param designationInputSearch the designationInputSearch to set
     */
    public void setDesignationInputSearch(String designationInputSearch)
    {
        this.designationInputSearch = designationInputSearch;
    }

    /**
     * @return the designationender
     */
    public boolean isDesignationender()
    {
        return designationender;
    }

    /**
     * @param designationender the designationender to set
     */
    public void setDesignationender(boolean designationender)
    {
        this.designationender = designationender;
    }

    /**
     * @return the firsNameSearch
     */
    public String getFirsNameSearch()
    {
        return firsNameSearch;
    }

    /**
     * @param firsNameSearch the firsNameSearch to set
     */
    public void setFirsNameSearch(String firsNameSearch)
    {
        this.firsNameSearch = firsNameSearch;
    }

    /**
     * @return the firstNameRender
     */
    public boolean isFirstNameRender()
    {
        return firstNameRender;
    }

    /**
     * @param firstNameRender the firstNameRender to set
     */
    public void setFirstNameRender(boolean firstNameRender)
    {
        this.firstNameRender = firstNameRender;
    }

    /**
     * @return the dob2
     */
    public Date getDob2()
    {
        return dob2;
    }

    /**
     * @param dob2 the dob2 to set
     */
    public void setDob2(Date dob2)
    {
        this.dob2 = dob2;
    }

    /**
     * @return the experienceError
     */
    public String getExperienceError()
    {
        return experienceError;
    }

    /**
     * @param experienceError the experienceError to set
     */
    public void setExperienceError(String experienceError)
    {
        this.experienceError = experienceError;
    }

    /**
     * @return the phoneNoError
     */
    public String getPhoneNoError()
    {
        return phoneNoError;
    }

    /**
     * @param phoneNoError the phoneNoError to set
     */
    public void setPhoneNoError(String phoneNoError)
    {
        this.phoneNoError = phoneNoError;
    }

    /**
     * @return the componentsDisable
     */
    public boolean isComponentsDisable()
    {
        return componentsDisable;
    }

    /**
     * @param componentsDisable the componentsDisable to set
     */
    public void setComponentsDisable(boolean componentsDisable)
    {
        this.componentsDisable = componentsDisable;
    }

    /**
     * @return the lastNameSearch
     */
    public String getLastNameSearch()
    {
        return lastNameSearch;
    }

    /**
     * @param lastNameSearch the lastNameSearch to set
     */
    public void setLastNameSearch(String lastNameSearch)
    {
        this.lastNameSearch = lastNameSearch;
    }

    /**
     * @return the lastNameRender
     */
    public boolean isLastNameRender()
    {
        return lastNameRender;
    }

    /**
     * @param lastNameRender the lastNameRender to set
     */
    public void setLastNameRender(boolean lastNameRender)
    {
        this.lastNameRender = lastNameRender;
    }

    /**
     * @return the searchOrganizationSearch
     */
    public List<String> getSearchOrganizationSearch()
    {
        return searchOrganizationSearch;
    }

    /**
     * @param searchOrganizationSearch the searchOrganizationSearch to set
     */
    public void setSearchOrganizationSearch(List<String> searchOrganizationSearch)
    {
        this.searchOrganizationSearch = searchOrganizationSearch;
    }

    /**
     * @return the searchRegionList
     */
    public List<String> getSearchRegionList()
    {
        return searchRegionList;
    }

    /**
     * @param searchRegionList the searchRegionList to set
     */
    public void setSearchRegionList(List<String> searchRegionList)
    {
        this.searchRegionList = searchRegionList;
    }

    /**
     * @return the searchBranchList
     */
    public List<String> getSearchBranchList()
    {
        return searchBranchList;
    }

    /**
     * @param searchBranchList the searchBranchList to set
     */
    public void setSearchBranchList(List<String> searchBranchList)
    {
        this.searchBranchList = searchBranchList;
    }

    /**
     * @return the searchDepartmentList
     */
    public List<String> getSearchDepartmentList()
    {
        return searchDepartmentList;
    }

    /**
     * @param searchDepartmentList the searchDepartmentList to set
     */
    public void setSearchDepartmentList(List<String> searchDepartmentList)
    {
        this.searchDepartmentList = searchDepartmentList;
    }

    /**
     * @return the searchDesignationList
     */
    public List<String> getSearchDesignationList()
    {
        return searchDesignationList;
    }

    /**
     * @param searchDesignationList the searchDesignationList to set
     */
    public void setSearchDesignationList(List<String> searchDesignationList)
    {
        this.searchDesignationList = searchDesignationList;
    }

    /**
     * @return the UserIdSearchError
     */
    public String getUserIdSearchError()
    {
        return UserIdSearchError;
    }

    /**
     * @param UserIdSearchError the UserIdSearchError to set
     */
    public void setUserIdSearchError(String UserIdSearchError)
    {
        this.UserIdSearchError = UserIdSearchError;
    }

    /**
     * @return the userIdSearch1
     */
    public boolean isUserIdSearch1()
    {
        return userIdSearch1;
    }

    /**
     * @param userIdSearch1 the userIdSearch1 to set
     */
    public void setUserIdSearch1(boolean userIdSearch1)
    {
        this.userIdSearch1 = userIdSearch1;
    }

    /**
     * @return the firstNameSearch1
     */
    public boolean isFirstNameSearch1()
    {
        return firstNameSearch1;
    }

    /**
     * @param firstNameSearch1 the firstNameSearch1 to set
     */
    public void setFirstNameSearch1(boolean firstNameSearch1)
    {
        this.firstNameSearch1 = firstNameSearch1;
    }

    /**
     * @return the lastNameSearch1
     */
    public boolean isLastNameSearch1()
    {
        return lastNameSearch1;
    }

    /**
     * @param lastNameSearch1 the lastNameSearch1 to set
     */
    public void setLastNameSearch1(boolean lastNameSearch1)
    {
        this.lastNameSearch1 = lastNameSearch1;
    }

    /**
     * @return the firstNameSearchError
     */
    public String getFirstNameSearchError()
    {
        return firstNameSearchError;
    }

    /**
     * @param firstNameSearchError the firstNameSearchError to set
     */
    public void setFirstNameSearchError(String firstNameSearchError)
    {
        this.firstNameSearchError = firstNameSearchError;
    }

    /**
     * @return the lastNameSearchError
     */
    public String getLastNameSearchError()
    {
        return lastNameSearchError;
    }

    /**
     * @param lastNameSearchError the lastNameSearchError to set
     */
    public void setLastNameSearchError(String lastNameSearchError)
    {
        this.lastNameSearchError = lastNameSearchError;
    }

    /**
     * @return the organizationInput1
     */
    public boolean isOrganizationInput1()
    {
        return organizationInput1;
    }

    /**
     * @param organizationInput1 the organizationInput1 to set
     */
    public void setOrganizationInput1(boolean organizationInput1)
    {
        this.organizationInput1 = organizationInput1;
    }

    /**
     * @return the regionInputSearch1
     */
    public boolean isRegionInputSearch1()
    {
        return regionInputSearch1;
    }

    /**
     * @param regionInputSearch1 the regionInputSearch1 to set
     */
    public void setRegionInputSearch1(boolean regionInputSearch1)
    {
        this.regionInputSearch1 = regionInputSearch1;
    }

    /**
     * @return the branchInputSearch1
     */
    public boolean isBranchInputSearch1()
    {
        return branchInputSearch1;
    }

    /**
     * @param branchInputSearch1 the branchInputSearch1 to set
     */
    public void setBranchInputSearch1(boolean branchInputSearch1)
    {
        this.branchInputSearch1 = branchInputSearch1;
    }

    /**
     * @return the departmentInputSearch1
     */
    public boolean isDepartmentInputSearch1()
    {
        return departmentInputSearch1;
    }

    /**
     * @param departmentInputSearch1 the departmentInputSearch1 to set
     */
    public void setDepartmentInputSearch1(boolean departmentInputSearch1)
    {
        this.departmentInputSearch1 = departmentInputSearch1;
    }

    /**
     * @return the tableBeanList
     */
    public List<TableBean> getTableBeanList()
    {
        return tableBeanList;
    }

    /**
     * @param tableBeanList the tableBeanList to set
     */
    public void setTableBeanList(List<TableBean> tableBeanList)
    {
        this.tableBeanList = tableBeanList;
    }

    /**
     * @return the designationInputSearch1
     */
    public boolean isDesignationInputSearch1()
    {
        return designationInputSearch1;
    }

    /**
     * @param designationInputSearch1 the designationInputSearch1 to set
     */
    public void setDesignationInputSearch1(boolean designationInputSearch1)
    {
        this.designationInputSearch1 = designationInputSearch1;
    }

    /**
     * @param file the file to set
     */
    public void setFile(StreamedContent file)
    {
        this.file = file;
    }

    /**
     * @return the file
     */
    public StreamedContent getFile()
    {
        return file;
    }

    /**
     * @return the datatableIndex
     */
    public int getDatatableIndex()
    {
        return datatableIndex;
    }

    /**
     * @param datatableIndex the datatableIndex to set
     */
    public void setDatatableIndex(int datatableIndex)
    {
        this.datatableIndex = datatableIndex;
    }

    /**
     * @return the accountBeanList
     */
    public List<AccountBean> getAccountBeanList()
    {
        return accountBeanList;
    }

    /**
     * @param accountBeanList the accountBeanList to set
     */
    public void setAccountBeanList(List<AccountBean> accountBeanList)
    {
        this.accountBeanList = accountBeanList;
    }

    /**
     * @return the datatableIndex1
     */
    public int getDatatableIndex1()
    {
        return datatableIndex1;
    }

    /**
     * @param datatableIndex1 the datatableIndex1 to set
     */
    public void setDatatableIndex1(int datatableIndex1)
    {
        this.datatableIndex1 = datatableIndex1;
    }

    /**
     * @return the totalAmount
     */
    public Double getTotalAmount()
    {
        return totalAmount;
    }

    /**
     * @param totalAmount the totalAmount to set
     */
    public void setTotalAmount(Double totalAmount)
    {
        this.totalAmount = totalAmount;
    }
}
