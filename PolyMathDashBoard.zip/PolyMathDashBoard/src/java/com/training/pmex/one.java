/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;

/**
 *
 * @author promoth
 */
public class one
{

    private Logger log = Logger.getLogger(one.class.getSimpleName());

    private XSSFCellStyle commonTableHeader;
    List<TableBean> tableBeanList = new ArrayList<>();
    String newExcel = "/home/promoth/Desktop/ResumeList.xlsx";

    private void populateResumeDetails()
    {
        TableBean bean = new TableBean();
        bean.setFirstName("Promoth");
        bean.setLastName("kumar");
        bean.setOrganization("Axis");
        bean.setRegion("Ooty");
        bean.setBranch("kallar");
        bean.setDepartment("IT");
        bean.setDesignation("Developer");
        tableBeanList.add(bean);

        bean = new TableBean();
        bean.setFirstName("shilpa");
        bean.setLastName("mon");
        bean.setOrganization("Axis");
        bean.setRegion("Ooty");
        bean.setBranch("kallar");
        bean.setDepartment("IT");
        bean.setDesignation("Developer");
        tableBeanList.add(bean);

    }

    private void createCells() throws FileNotFoundException, IOException
    {
        populateResumeDetails();

        log.info("########" + tableBeanList.size());
        XSSFWorkbook workbook = new XSSFWorkbook();

        XSSFSheet sheet = workbook.createSheet("characters");

        int rowIndex = 0;

        int cellIndex1 = 0;
        XSSFRow rowhead = sheet.createRow((short) rowIndex);

        Style(workbook);

        sheet.setColumnWidth(0, 3000);
        sheet.setColumnWidth(1, 3000);
        sheet.setColumnWidth(2, 4000);
        sheet.setColumnWidth(3, 4000);
        sheet.setColumnWidth(4, 4000);
        sheet.setColumnWidth(5, 4000);
        sheet.setColumnWidth(6, 4000);

        sheet.setDefaultRowHeight((short) 300);
        rowhead.setHeight((short) 500);

        XSSFCell tableHeaderCell1 = rowhead.createCell(0);
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("First Name"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Last Name"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Organization"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Region"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Branch"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Department"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        tableHeaderCell1 = rowhead.createCell(cellIndex1++);
        tableHeaderCell1.setCellValue(new XSSFRichTextString("Designation"));
        tableHeaderCell1.setCellStyle(commonTableHeader);

        log.info("%%%%%%%%%%%%%%%%%%%%%" + rowIndex);
        rowIndex++;
        for (TableBean tableBean : tableBeanList)
        {
            log.info("---------" + tableBeanList.size());

            log.info("^^^^^^^^^^^^^^^^" + rowIndex);

            XSSFRow row = sheet.createRow(rowIndex);

            int cellIndex = 0;
            XSSFCell cell = row.createCell(cellIndex++);

            cell.setCellValue(tableBean.getFirstName());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getLastName());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getOrganization());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getRegion());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getBranch());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getDepartment());
            cell = row.createCell(cellIndex++);
            cell.setCellValue(tableBean.getDesignation());
            cell = row.createCell(cellIndex++);

            rowIndex++;
        }
        FileOutputStream fileOut = new FileOutputStream(newExcel);
        workbook.write(fileOut);

        fileOut.close();

    }

    private void Style(XSSFWorkbook workBook)
    {
        XSSFFont tableHeaderFont = (XSSFFont) workBook.createFont();
        tableHeaderFont.setFontHeightInPoints((short) 11);
        tableHeaderFont.setFontName("Calibri");
        tableHeaderFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        tableHeaderFont.setColor(IndexedColors.BLACK.getIndex());

        commonTableHeader = (XSSFCellStyle) workBook.createCellStyle();
        commonTableHeader.setAlignment(XSSFCellStyle.ALIGN_CENTER);
        commonTableHeader.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
        commonTableHeader.setFillForegroundColor(new XSSFColor(new java.awt.Color(181, 223, 217)));
        commonTableHeader.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
        commonTableHeader.setBorderRight(XSSFCellStyle.BORDER_THIN);
        commonTableHeader.setRightBorderColor(IndexedColors.BLACK.getIndex());
        commonTableHeader.setBorderLeft(XSSFCellStyle.BORDER_THIN);
        commonTableHeader.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        commonTableHeader.setBorderTop(XSSFCellStyle.BORDER_THIN);
        commonTableHeader.setTopBorderColor(IndexedColors.BLACK.getIndex());
        commonTableHeader.setBorderBottom(XSSFCellStyle.BORDER_THIN);
        commonTableHeader.setTopBorderColor(IndexedColors.BLACK.getIndex());
        commonTableHeader.setFont(tableHeaderFont);
        commonTableHeader.setWrapText(true);
        commonTableHeader.setHidden(true);

        XSSFFont ordinryFont = workBook.createFont();
        ordinryFont.setFontHeightInPoints((short) 11);
        ordinryFont.setFontName("Calibri");
        ordinryFont.setColor(IndexedColors.BLACK.getIndex());

    }

    public static void main(String[] args) throws IOException
    {
        PropertyConfigurator.configure("/home/promoth/NetBeansProjects/Com.Training/src/com/training/collectionExcel/log4j.properties");

        one von = new one();
        von.createCells();
    }

}
