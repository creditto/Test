/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.training.pmex;

import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author promoth
 */
public class sampleTwo
{

    String s = " ";
    String s1 = "promoth";

    public void examp()
    {
        System.out.println("blank" + StringUtils.isBlank(s));
    }

    public static void main(String[] args)
    {
        sampleTwo two = new sampleTwo();
        two.examp();
    }
}
